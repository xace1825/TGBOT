#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import logging
import random
import json
import os
from typing import List, Dict, Any
from datetime import datetime

import telegram
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, LabeledPrice
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, filters, CallbackContext, PreCheckoutQueryHandler
from telegram.constants import ParseMode

# Константы ролей
ROLE_MAFIA_DON = "Дон Мафии"
ROLE_MAFIA = "Мафиози"  
ROLE_DOCTOR = "Доктор"
ROLE_COMMISSIONER = "Комиссар"
ROLE_MANIAC = "Маньяк"
ROLE_PROSTITUTE = "Путана"
ROLE_PEACEFUL = "Мирный житель"

# Константы состояний игры
STATE_NIGHT = "night"
STATE_DAY = "day"
STATE_FINISHED = "finished"
STATE_ROLES_DISTRIBUTED = "roles_distributed"
STATE_TIMER_WAITING = "timer_waiting"

# Константы статусов игроков
STATUS_ACTIVE = "active"
STATUS_ELIMINATED = "eliminated"
STATUS_LEFT = "left"

# Константы ключей
STATE_KEY = "state"
STATUS_KEY = "status"
HOST_ID_KEY = "host_id"
USER_ID_KEY = "user_id"
ROLE_KEY = "role"

# Все роли, доступные для ручной настройки
ALL_CONFIGURABLE_ROLES = [
    "Мирный житель", 
    "Мафиози", 
    "Дон Мафии", 
    "Комиссар", 
    "Доктор", 
    "Маньяк", 
    "Путана"
]

# Роли, способные действовать ночью
NIGHT_ROLES = [ROLE_MAFIA_DON, ROLE_MAFIA, ROLE_DOCTOR, ROLE_COMMISSIONER, ROLE_MANIAC, ROLE_PROSTITUTE]

# Пассивные роли (без ночных способностей)
PASSIVE_ROLES = [ROLE_PEACEFUL]

def get_minute_word(minutes: int) -> str:
    """Возвращает правильную форму слова 'минута' в зависимости от числа"""
    if minutes % 10 == 1 and minutes % 100 != 11:
        return "минута"
    elif minutes % 10 in [2, 3, 4] and minutes % 100 not in [12, 13, 14]:
        return "минуты"
    else:
        return "минут"

# Глобальные переменные
TOKEN = "7639730661:AAEUaFtNCjbZAA4AzT6Vm8pqmjYuL2TRBG0"

# Глобальное хранилище игр
games = {}

# Хранилище математических примеров для пользователей
user_math_state = {}

# Константы для платежей
PREMIUM_PRICE_RUBLES = 299  # Цена в рублях
PREMIUM_PRICE_KOPECKS = PREMIUM_PRICE_RUBLES * 100  # Telegram требует цену в копейках

# Токен провайдера ЮKassa (получите в @BotFather)
PAYMENT_PROVIDER_TOKEN = "390540012:LIVE:71581"  # Боевой токен ЮKassa

# Данные ролей с подробным описанием
ROLES_DATA = {
    "Мирный житель": {
        "description": "Обычный житель города. Не имеет специальных способностей.",
        "goal": "Найти и исключить всех мафиози путем голосования днем.",
        "actions": "Участвует в дневных обсуждениях и голосованиях."
    },
    "Мафиози": {
        "description": "Член мафии. Знает всех членов своей команды.",
        "goal": "Захватить город, уничтожив всех мирных жителей.",
        "actions": "Ночью совещается с другими мафиози и выбирает жертву для убийства."
    },
    "Дон Мафии": {
        "description": "Глава мафии. Имеет решающий голос при разногласиях в мафии.",
        "goal": "Захватить город, руководя мафией.",
        "actions": "Ночью руководит выбором жертвы, может проверять игроков на роль Комиссара."
    },
    "Комиссар": {
        "description": "Следователь полиции. Может проверять игроков на принадлежность к мафии.",
        "goal": "Найти и вывести на чистую воду всех мафиози.",
        "actions": "Каждую ночь может проверить одного игрока - мафиози или нет."
    },
    "Доктор": {
        "description": "Врач. Может спасать игроков от смерти.",
        "goal": "Защитить мирных жителей от мафии.",
        "actions": "Каждую ночь может спасти одного игрока от убийства (включая себя)."
    },
    "Маньяк": {
        "description": "Одинокий убийца. Играет сам за себя против всех.",
        "goal": "Остаться последним выжившим в городе.",
        "actions": "Каждую ночь убивает одного игрока. Побеждает, если остается один."
    },
    "Путана": {
        "description": "Блокирует действия других игроков.",
        "goal": "Помочь мирным жителям победить мафию.",
        "actions": "Каждую ночь блокирует способности одного игрока."
    }
}

# Список крутых вымышленных имен из поп-культуры (150+ имен)
fictional_names_list = [
    # Из видеоигр
    "Геральт Ривийский", "Лара Крофт", "Мастер Чиф", "Алекс Вэнс", "Джон-117",
    "Элли Уильямс", "Аэрис Гейнсборо", "Клауд Страйф", "Сэм Фишер", "Джилл Валентайн",
    "Крейтос", "Алой", "Артур Морган", "Сара Керриган", "Гордон Фримен",
    "Дум Слейер", "Данте Спарда", "Вергилий", "Нико Робин", "Соник Хеджхог",
    "Марио Марио", "Принцесса Пич", "Линк Хайрул", "Зельда", "Гандорф",
    "Кратос Спартан", "Атрей", "Нейтан Дрейк", "Елена Фишер", "Виктор Салливан",
    "Касс Кэйн", "Эцио Аудиторе", "Альтаир Ибн-Ла'Ахад", "Коннор Кенуэй", "Арно Дориан",
    "Эвие Фрай", "Джейкоб Фрай", "Баек Сива", "Айя Александрия", "Кассандра",
    "Алексиос", "Рэйден", "Скорпион", "Саб-Зиро", "Соня Блейд", "Лю Кан",
    
    # Из Marvel/DC
    "Тони Старк", "Наташа Романофф", "Стив Роджерс", "Брюс Уэйн", "Диана Принс",
    "Питер Паркер", "Ванда Максимофф", "Скотт Лэнг", "Кэрол Дэнверс", "Стивен Стрэндж",
    "Барри Аллен", "Хэл Джордан", "Кларк Кент", "Лоис Лейн", "Селина Кайл",
    "Харли Квинн", "Дэдпул", "Росомаха", "Шторм", "Джин Грей", "Скотт Саммерс",
    "Курт Вагнер", "Логан Хоулетт", "Рейвен Дарк", "Мистик", "Магнето",
    "Профессор Икс", "Ночной Змей", "Красная Ведьма", "Соколиный Глаз", "Черная Пантера",
    
    # Из фильмов и сериалов
    "Джон Уик", "Сара Коннор", "Эллен Рипли", "Хан Соло", "Лея Органа",
    "Нео Андерсон", "Тринити", "Джеймс Бонд", "Итан Хант", "Беатрикс Кидо",
    "Доминик Торетто", "Летти Ортиз", "Хоббс", "Шоу", "Рэмзи",
    "Джон Сноу", "Дейенерис Таргариен", "Арья Старк", "Тирион Ланнистер", "Серсея Ланнистер",
    "Джейме Ланнистер", "Санса Старк", "Бран Старк", "Джон Коннор", "Кайл Риз",
    "Рик Граймс", "Дэрил Диксон", "Мишон", "Кэрол Пелетьер", "Гленн Ри",
    "Магги Грин", "Неган", "Эйбрахам Форд", "Юджин Портер", "Розита Эспиноза",
    
    # Музыканты и знаменитости
    "Фредди Меркьюри", "Дэвид Боуи", "Майкл Джексон", "Мадонна", "Принс Роджерс",
    "Джон Леннон", "Пол Маккартни", "Адель Аткинс", "Бейонсе Ноулз", "Эминем",
    "Ариана Гранде", "Тейлор Свифт", "Леди Гага", "Бруно Марс", "Эд Ширан",
    "Билли Айлиш", "Джастин Тимберлейк", "Риана", "Канье Уэст", "Дрейк",
    "Джей-Зи", "Натали Портман", "Леонардо ДиКаприо", "Брэд Питт", "Анджелина Джоли",
    
    # Из популярных фильмов и сериалов
    "Джек Спэрроу", "Элизабет Суонн", "Уилл Тернер", "Капитан Барбосса", "Дэви Джонс",
    "Индиана Джонс", "Мэрион Рэйвенвуд", "Генри Джонс", "Короткий Раунд", "Вилли Скотт",
    "Форест Гамп", "Дженни Каррен", "Лейтенант Дэн", "Бубба Блю", "Мама Гамп",
    "Вуди", "Базз Лайтер", "Джесси", "Бо Пип", "Рекс Динозавр",
    "Шрек", "Фиона", "Осел", "Кот в Сапогах", "Лорд Фаркуад",
    "Эльза", "Анна", "Олаф", "Кристофф", "Свен Олень",
    "Моана", "Мауи", "Бабушка Тала", "Хей-Хей", "Пуа",
    
    # Из литературы и мифологии
    "Шерлок Холмс", "Джон Ватсон", "Гарри Поттер", "Хермиона Грейнджер", "Рон Уизли",
    "Гэндальф Серый", "Арагорн", "Леголас", "Гимли", "Фродо Бэггинс",
    "Сэм Гэмджи", "Боромир", "Фарамир", "Галадриэль", "Элронд",
    "Артемида", "Аполлон", "Афина", "Арес", "Гермес", "Посейдон", "Гера",
    "Тор Одинсон", "Локи Лафейсон", "Фрейя", "Один", "Бальдр", "Хеймдалль",
    
    # Из классических фильмов и историческая классика
    "Рокки Бальбоа", "Эдриан Пеннино", "Аполло Крид", "Иван Драго", "Клабер Лэнг",
    "Рэмбо", "Джон Маклейн", "Холли Дженнаро", "Хансы Грубер", "Эл Пауэлл",
    "Терминатор", "Кайл Риз", "Сара Коннор", "Джон Коннор", "Т-1000",
    "Коломбо", "Шерлок Холмс", "Доктор Ватсон", "Эркюль Пуаро", "Мисс Марпл",
    "Джеймс Бонд", "М", "Кью", "Мани Пенни", "Феликс Лейтер",
    "Индиана Джонс", "Мэрион Рэйвенвуд", "Генри Джонс", "Салла", "Брэди",
    
    # Звездные войны (простые имена)
    "Люк Скайуокер", "Лея Органа", "Хан Соло", "Чубакка", "Лэндо Калриссиан",
    "Оби-Ван Кеноби", "Йода", "Дарт Вейдер", "Палпатин", "Джабба Хатт"
]

# Список личных дел (250+ дел)
personal_cases = [
    # Профессии и работа
    "Я работаю учителем в местной школе и очень люблю детей.",
    "Владею небольшим магазином на центральной улице города.",
    "Работаю врачом в городской больнице уже 15 лет.",
    "Я механик в автосервисе и знаю все о машинах.",
    "Работаю библиотекарем и читаю по три книги в неделю.",
    "Я повар в ресторане и готовлю лучшую пиццу в городе.",
    "Работаю таксистом и знаю каждую улочку нашего города.",
    "Я парикмахер и делаю самые модные стрижки.",
    "Работаю почтальоном и разношу письма по всему району.",
    "Я продавец в супермаркете и всегда улыбаюсь покупателям.",
    "Работаю строителем и строю дома для людей.",
    "Я художник и рисую портреты на заказ.",
    "Работаю в банке кассиром уже 10 лет.",
    "Я ветеринар и лечу животных в нашем городе.",
    "Работаю пожарным и спасаю людей от огня.",
    "Я фермер и выращиваю экологически чистые овощи.",
    "Работаю журналистом в местной газете.",
    "Я музыкант и играю в городском оркестре.",
    "Работаю охранником в торговом центре.",
    "Я швея и шью красивую одежду на заказ.",
    "Работаю электриком и чиню проводку в домах.",
    "Я садовник и ухаживаю за городским парком.",
    "Работаю в театре актером уже 8 лет.",
    "Я фотограф и снимаю свадьбы и праздники.",
    "Работаю слесарем и ремонтирую трубы.",
    "Я кондитер и пеку торты на день рождения.",
    "Работаю дворником и убираю наш район.",
    "Я программист и создаю компьютерные программы.",
    "Работаю в детском саду воспитателем.",
    "Я столяр и делаю мебель из дерева.",
    
    # Дополнительные профессии
    "Я архитектор и проектирую красивые здания для нашего города.",
    "Работаю массажистом в спа-салоне и помогаю людям расслабиться.",
    "Я дизайнер интерьеров и делаю дома уютными.",
    "Работаю звукорежиссером на радиостанции.",
    "Я переводчик и знаю 5 иностранных языков.",
    "Работаю тренером в фитнес-центре и помогаю людям быть здоровыми.",
    "Я психолог и консультирую людей в трудных ситуациях.",
    "Работаю геологом и изучаю минералы в горах.",
    "Я астроном и наблюдаю за звездами каждую ночь.",
    "Работаю археологом и раскапываю древние артефакты.",
    "Я химик и работаю в научной лаборатории.",
    "Работаю инженером и конструирую мосты.",
    "Я зоолог и изучаю поведение диких животных.",
    "Работаю дайвером и исследую морские глубины.",
    "Я пилот и летаю на самолетах по всему миру.",
    "Работаю капитаном корабля и бороздю моря.",
    "Я альпинист и покоряю высочайшие вершины гор.",
    "Работаю спасателем на пляже и слежу за безопасностью.",
    "Я метеоролог и предсказываю погоду.",
    "Работаю картографом и составляю точные карты.",
    
    # Хобби и увлечения
    "В свободное время я коллекционирую редкие монеты со всего мира.",
    "Увлекаюсь выращиванием орхидей и у меня дома настоящие джунгли.",
    "Занимаюсь йогой каждый день уже 5 лет подряд.",
    "Играю в шахматы и участвую в турнирах каждые выходные.",
    "Коллекционирую винтажные автомобили и реставрирую их.",
    "Увлекаюсь астрофотографией и фотографирую созвездия.",
    "Занимаюсь скалолазанием и покорил уже 20 вершин.",
    "Изучаю иностранные языки и уже знаю 7 языков.",
    "Пишу стихи и уже опубликовал сборник своих работ.",
    "Увлекаюсь кулинарией и готовлю блюда разных стран мира.",
    "Занимаюсь танцами и участвую в соревнованиях по бальным танцам.",
    "Коллекционирую бабочек и знаю более 200 видов.",
    "Увлекаюсь моделированием самолетов и создаю точные копии.",
    "Занимаюсь каллиграфией и пишу красивые открытки друзьям.",
    "Изучаю историю древних цивилизаций и читаю археологические книги.",
    "Увлекаюсь оригами и могу сложить любую фигуру из бумаги.",
    "Занимаюсь пчеловодством и произвожу натуральный мед.",
    "Коллекционирую старинные книги и у меня библиотека из 3000 томов.",
    "Увлекаюсь гончарным делом и создаю уникальную керамику.",
    "Занимаюсь выжиганием по дереву и делаю художественные панно.",
    
    # Семья и личная жизнь
    "Я недавно стал отцом и учусь менять подгузники.",
    "Воспитываю троих детей одна и горжусь ими.",
    "Недавно отпраздновал серебряную свадьбу с любимой женой.",
    "Планирую свадьбу на следующий месяц и очень волнуюсь.",
    "Недавно переехал в новый дом и обустраиваю его.",
    "Ухаживаю за пожилой мамой и очень ее люблю.",
    "Жду рождения первого ребенка через два месяца.",
    "Только что закончил университет и ищу работу мечты.",
    "Планирую кругосветное путешествие на следующий год.",
    "Недавно купил первую машину и учусь водить.",
    "Переехал из деревни в город месяц назад.",
    "Живу с тремя соседями в общежитии и мы лучшие друзья.",
    "Недавно развелся и начинаю новую жизнь.",
    "Усыновил щенка из приюта и теперь мы неразлучны.",
    "Планирую открыть собственный бизнес в следующем году.",
    "Только что вернулся из армии и привыкаю к гражданской жизни.",
    "Учусь в вечерней школе и получаю второе образование.",
    "Недавно переехал к бабушке и помогаю ей по хозяйству.",
    "Живу в коммунальной квартире с пятью соседями.",
    "Планирую эмигрировать в другую страну через год.",
    
    # Увлекательные факты
    "Я умею играть на семи музыкальных инструментах одновременно.",
    "Выиграл в лотерею крупную сумму, но никому об этом не рассказываю.",
    "Умею читать по губам и часто подслушиваю чужие разговоры.",
    "Участвовал в съемках фильма в роли статиста.",
    "Могу запомнить и воспроизвести любую мелодию с первого прослушивания.",
    "Однажды спас человека из горящего здания.",
    "Нашел клад в старом доме своей бабушки.",
    "Умею жонглировать пятью мячами одновременно.",
    "Побывал во всех странах Европы за один год.",
    "Могу решить кубик Рубика за 30 секунд.",
    "Участвовал в марафоне и финишировал в первой сотне.",
    "Умею имитировать голоса 20 разных животных.",
    "Однажды встретил знаменитость в случайном месте.",
    "Могу приготовить 50 разных видов кофе.",
    "Выучил китайский язык за полгода.",
    "Участвовал в телевизионной викторине и выиграл главный приз.",
    "Умею рисовать портреты людей по памяти.",
    "Однажды заблудился в лесу на три дня.",
    "Могу определить породу собаки по одному лаю.",
    "Участвовал в создании мирового рекорда Гиннесса.",
    
    # Необычные профессии
    "Работаю дегустатором мороженого и пробую новые вкусы.",
    "Я профессиональный обнимальщик панд в зоопарке.",
    "Работаю тестировщиком водных горок в аквапарках.",
    "Я островной смотритель на тропическом острове.",
    "Работаю охотником за привидениями в старинных замках.",
    "Я профессиональный соня и тестирую матрасы.",
    "Работаю дегустатором шоколада в кондитерской фабрике.",
    "Я тренер для ленивцев в зоопарке.",
    "Работаю создателем LEGO-моделей в игрушечной компании.",
    "Я профессиональный нюхач духов и создаю новые ароматы.",
    "Работаю смотрителем маяка на морском берегу.",
    "Я тестировщик американских горок в парках развлечений.",
    "Работаю переворачивателем пингвинов в Антарктиде.",
    "Я профессиональный плакальщик на похоронах.",
    "Работаю дегустатором собачьего корма.",
    "Я охранник Форт-Нокса и стерегу золото.",
    "Работаю выгульщиком жирафов в сафари-парке.",
    "Я дегустатор мороженого для космонавтов.",
    "Работаю профессиональным стояльщиком в очередях.",
    "Я смотритель за единорогами в секретном заповеднике.",
    
    # Странные привычки и черты
    "Я каждый день ем ровно 33 изюминки на завтрак.",
    "Всегда ношу с собой резиновую уточку для удачи.",
    "Могу спать только под звуки дождя или океана.",
    "Коллекционирую билеты от всех поездок в транспорте.",
    "Никогда не выхожу из дома без фиолетового носка на левой ноге.",
    "Разговариваю с растениями и они растут лучше других.",
    "Всегда считаю ступеньки при подъеме по лестнице.",
    "Могу определить время с точностью до минуты без часов.",
    "Ем пиццу только вилкой и ножом.",
    "Никогда не наступаю на трещины в асфальте.",
    "Запоминаю номерные знаки всех машин на моей улице.",
    "Всегда мою посуду в строго определенном порядке.",
    "Могу узнать человека по запаху его духов.",
    "Читаю книги только при свете свечей.",
    "Никогда не покупаю четное количество бананов.",
    "Могу предсказать погоду по поведению своего кота.",
    "Всегда засыпаю лицом к северу.",
    "Ем суп только серебряной ложкой.",
    "Никогда не ношу одинаковые носки.",
    "Могу определить настроение человека по его походке.",
    
    # Профессиональные навыки
    "Умею взламывать любые замки за 30 секунд.",
    "Могу приготовить 200 различных коктейлей по памяти.",
    "Владею техниками 15 видов боевых искусств.",
    "Умею водить все виды транспорта от велосипеда до вертолета.",
    "Могу имитировать почерк любого человека.",
    "Владею искусством гипноза и могу усыпить словом.",
    "Умею читать мысли по мимике лица.",
    "Могу приготовить яд из обычных растений.",
    "Владею искусством маскировки и могу стать невидимым.",
    "Умею взрывать сейфы без динамита.",
    "Могу проследить любого человека незаметно.",
    "Владею техниками допроса и выведывания секретов.",
    "Умею подделывать документы любой сложности.",
    "Могу вскрыть любой компьютер за 5 минут.",
    "Владею искусством отравления через прикосновение.",
    "Умею изготавливать взрывчатку из бытовых предметов.",
    "Могу убить человека одним пальцем.",
    "Владею техниками промывания мозгов.",
    "Умею становиться невидимым в толпе.",
    "Могу подслушивать разговоры на расстоянии километра."
]

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def generate_id(length=6):
    """Генерирует уникальный ID игры"""
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return "".join(random.choice(chars) for _ in range(length))

def get_player_display_name(slot: dict, context=None) -> str:
    """Возвращает полное отображаемое имя игрока: Вымышленное имя (ТГ ник)"""
    fictional_name = slot.get("fictional_name", "Неизвестный")
    
    # Используем сохранённое ТГ имя из слота (записывается при присоединении)
    real_name = slot.get("real_name", "Игрок")
    
    return f"{fictional_name} ({real_name})"



def generate_math_problem(num_active_players: int):
    """Генерирует математический пример с вариантами ответов (количество вариантов = количеству живых игроков)"""
    operation_type = random.choice(['add', 'subtract', 'multiply'])
    
    if operation_type == 'add':
        a = random.randint(1, 50)
        b = random.randint(1, 50)
        question = f"{a} + {b}"
        correct_answer = a + b
    elif operation_type == 'subtract':
        a = random.randint(20, 100)
        b = random.randint(1, a - 1)  # Гарантируем положительный результат
        question = f"{a} - {b}"
        correct_answer = a - b
    else:  # multiply
        a = random.randint(2, 12)
        b = random.randint(2, 8)
        question = f"{a} × {b}"
        correct_answer = a * b
    
    # Генерируем неправильные варианты ответов
    wrong_answers = set()
    while len(wrong_answers) < min(num_active_players - 1, 5):  # Максимум 5 неправильных вариантов
        # Генерируем близкие к правильному ответу значения
        wrong_answer = correct_answer + random.randint(-10, 10)
        if wrong_answer != correct_answer and wrong_answer > 0:
            wrong_answers.add(wrong_answer)
    
    # Если недостаточно вариантов, добавляем еще
    while len(wrong_answers) < num_active_players - 1:
        wrong_answer = random.randint(max(1, correct_answer - 20), correct_answer + 20)
        if wrong_answer != correct_answer:
            wrong_answers.add(wrong_answer)
    
    # Создаем список всех вариантов и перемешиваем
    all_answers = [correct_answer] + list(wrong_answers)[:num_active_players - 1]
    random.shuffle(all_answers)
    
    return question, correct_answer, all_answers

def get_passive_role_players(game_data: dict):
    """Возвращает список игроков с пассивными ролями (без ночных способностей)"""
    passive_players = []
    for slot in game_data.get("players_slots", []):
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("user_id") and 
            slot.get("role") in PASSIVE_ROLES):
            passive_players.append(slot)
    return passive_players

async def send_math_problems_to_passive_players(game_id: str, game_data: dict, context: CallbackContext):
    """Отправляет математические примеры ТОЛЬКО мирным жителям (роли без ночных действий)"""
    
    # Получаем список игроков БЕЗ ночных ролей - только они решают математику для права голоса
    players_for_math = []
    for slot in game_data.get("players_slots", []):
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("user_id") and 
            slot.get("role") not in NIGHT_ROLES):  # ТОЛЬКО мирные жители решают математику
            players_for_math.append(slot)
    
    if not players_for_math:
        logger.info(f"No passive players found for math problems in game {game_id}")
        return
    
    # Подсчитываем количество активных игроков для генерации вариантов ответов
    num_active_players = len([slot for slot in game_data.get("players_slots", []) if slot.get("status") == STATUS_ACTIVE])
    
    logger.info(f"Sending math problems to {len(players_for_math)} players in game {game_id}")
    
    for slot in players_for_math:
        user_id = slot["user_id"]
        question, correct_answer, answer_options = generate_math_problem(num_active_players)
        
        # Создаем клавиатуру с вариантами ответов
        keyboard = []
        for answer in answer_options:
            keyboard.append([InlineKeyboardButton(str(answer), callback_data=f"math_answer_{game_id}_{user_id}_{answer}")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Сохраняем состояние математического примера для пользователя
        user_math_state[user_id] = {
            "game_id": game_id,
            "question": question,
            "correct_answer": correct_answer,
            "answer_options": answer_options,
            "attempts": 0,
            "max_attempts": 2,
            "has_voting_rights": True,
            "waiting_for_answer": True
        }
        
        try:
            await context.bot.send_message(
                user_id,
                f"🧮 **Ночное задание**\n\n"
                f"Пока активные роли действуют, решите пример:\n\n"
                f"**{question} = ?**\n\n"
                f"👆 Выберите правильный ответ из предложенных вариантов.\n"
                f"⚠️ При неправильном ответе вы потеряете право голоса на следующем дневном голосовании!",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            logger.info(f"Math problem sent to user {user_id}: {question}")
        except Exception as e:
            logger.error(f"Error sending math problem to user {user_id}: {e}")

async def handle_math_button_answer(query, context: CallbackContext, game_id: str, user_id: int, selected_answer: int):
    """Обрабатывает ответы на математические примеры через кнопки"""
    
    # Проверяем, есть ли у пользователя активный математический пример
    if user_id not in user_math_state:
        await query.answer("❌ У вас нет активного математического примера", show_alert=True)
        return
    
    math_state = user_math_state[user_id]
    
    if not math_state.get("waiting_for_answer"):
        await query.answer("❌ Пример уже решен", show_alert=True)
        return
    
    if math_state.get("game_id") != game_id:
        await query.answer("❌ Неверная игра", show_alert=True)
        return
    
    correct_answer = math_state["correct_answer"]
    attempts = math_state["attempts"] + 1
    
    math_state["attempts"] = attempts
    
    if selected_answer == correct_answer:
        # Правильный ответ
        math_state["waiting_for_answer"] = False
        math_state["has_voting_rights"] = True
        
        await query.edit_message_text(
            f"✅ **Правильно!** {math_state['question']} = {correct_answer}\n\n"
                            f"🗳️ Вы сохраняете право голоса на дневном голосовании.",
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Обновляем права голосования в игре
        await update_voting_rights(game_id, user_id, True)
        
        logger.info(f"User {user_id} answered math problem correctly on attempt {attempts}")
        
    else:
        # Неправильный ответ
        if attempts >= math_state["max_attempts"]:
            # Исчерпаны все попытки
            math_state["waiting_for_answer"] = False
            math_state["has_voting_rights"] = False
            
            await query.edit_message_text(
                f"❌ **Неправильно!** {math_state['question']} = {correct_answer}\n\n"
                f"😔 Вы исчерпали все попытки и теряете право голоса на следующем дневном голосовании.\n"
                f"💡 В следующую ночь у вас будет новая возможность восстановить право голоса.",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Обновляем права голосования в игре
            await update_voting_rights(game_id, user_id, False)
            
            logger.info(f"User {user_id} failed math problem after {attempts} attempts, lost voting rights")
            
        else:
            # Даем вторую попытку
            game_data = games.get(game_id)
            if game_data:
                num_active_players = len([slot for slot in game_data.get("players_slots", []) if slot.get("status") == STATUS_ACTIVE])
                new_question, new_correct_answer, new_answer_options = generate_math_problem(num_active_players)
                
                math_state["question"] = new_question
                math_state["correct_answer"] = new_correct_answer
                math_state["answer_options"] = new_answer_options
                
                # Создаем новую клавиатуру
                keyboard = []
                for answer in new_answer_options:
                    keyboard.append([InlineKeyboardButton(str(answer), callback_data=f"math_answer_{game_id}_{user_id}_{answer}")])
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await query.edit_message_text(
                    f"❌ **Неправильно!** Правильный ответ: {correct_answer}\n\n"
                    f"🔄 **У вас есть еще одна попытка:**\n\n"
                    f"**{new_question} = ?**\n\n"
                    f"⚠️ При неправильном ответе вы потеряете право голоса!",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=reply_markup
                )
                
                logger.info(f"User {user_id} failed math problem on attempt {attempts}, giving second chance: {new_question}")
    
    # Проверяем, завершили ли все игроки математические примеры
    await check_all_math_completed(game_id, context)

async def handle_math_answer(update: Update, context: CallbackContext):
    """Обрабатывает ответы на математические примеры (устаревшая текстовая версия)"""
    user_id = update.effective_user.id
    
    # Проверяем, есть ли у пользователя активный математический пример
    if user_id not in user_math_state:
        return False  # Не математический ответ
    
    math_state = user_math_state[user_id]
    
    if not math_state.get("waiting_for_answer"):
        return False  # Пример уже решен или не активен
    
    # Если у пользователя активный математический пример, но это текстовое сообщение
    # Направляем его к использованию кнопок
    await update.message.reply_text(
        "🔘 Пожалуйста, используйте кнопки выше для ответа на математический пример.\n"
        f"Пример: **{math_state['question']} = ?**",
        parse_mode=ParseMode.MARKDOWN
    )
    
    return True  # Это попытка ответа на математический пример

async def check_all_math_completed(game_id: str, context: CallbackContext):
    """Проверяет, завершили ли все игроки математические примеры, и переходит к дню если да"""
    if game_id not in games:
        return
    
    game_data = games[game_id]
    
    # Проверяем только в режиме бот-ведущего (включая таймер) и состоянии ночи
    game_mode = game_data.get("game_mode", "")
    if not ("bot_host" in game_mode) or game_data.get("state") != STATE_NIGHT:
        return
    
    # Собираем всех игроков, которые должны были получить математические примеры
    players_with_math = []
    for user_id, math_state in user_math_state.items():
        if math_state.get("game_id") == game_id:
            players_with_math.append(user_id)
    
    if not players_with_math:
        return  # Нет игроков с математическими примерами
    
    # Проверяем, все ли завершили решение примеров
    all_completed = True
    for user_id in players_with_math:
        math_state = user_math_state.get(user_id, {})
        if math_state.get("waiting_for_answer", False):
            all_completed = False
            break
    
    if all_completed:
        logger.info(f"All math problems completed in game {game_id}, checking if all night actions are also complete")
        
        # Проверяем, завершены ли ВСЕ ночные действия (не только математика)
        await check_all_night_actions_completed(game_id, context)

async def check_all_night_actions_completed(game_id: str, context: CallbackContext):
    """Проверяет, завершены ли ВСЕ ночные действия (математика + роли)"""
    if game_id not in games:
        return
    
    game_data = games[game_id]
    
    # Проверяем только в режиме бот-ведущего (включая таймер) и состоянии ночи
    game_mode = game_data.get("game_mode", "")
    if not ("bot_host" in game_mode) or game_data.get("state") != STATE_NIGHT:
        return
    
    # Защита от повторного выполнения - проверяем флаг
    if game_data.get("night_completion_processing", False):
        return  # Уже выполняется обработка завершения ночи
    
    # Устанавливаем флаг обработки
    game_data["night_completion_processing"] = True
    games[game_id] = game_data
    
    # 1. Проверяем математические примеры
    players_with_math = []
    for user_id, math_state in user_math_state.items():
        if math_state.get("game_id") == game_id:
            players_with_math.append(user_id)
    
    math_completed = True
    for user_id in players_with_math:
        math_state = user_math_state.get(user_id, {})
        if math_state.get("waiting_for_answer", False):
            math_completed = False
            break
    
    # 2. Проверяем действия ночных ролей
    night_roles_completed = True
    
    # Проверяем мафию
    mafia_count = len([slot for slot in game_data["players_slots"] 
                      if slot.get("status") == STATUS_ACTIVE and 
                         slot.get("role") in ["Мафиози", "Дон Мафии"]])
    
    if mafia_count > 0:
        # Проверяем, выбрана ли цель мафии (кто-то помечен как targeted_by_mafia)
        mafia_target_chosen = False
        for slot in game_data["players_slots"]:
            if slot.get("targeted_by_mafia"):
                mafia_target_chosen = True
                break
        
        if not mafia_target_chosen:
            night_roles_completed = False
            logger.info(f"Waiting for mafia to choose target")
    
    # Проверяем доктора
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") == "Доктор"):
            # Проверяем, завершил ли доктор свое действие (вылечил кого-то ИЛИ пропустил ход)
            doctor_acted = False
            if slot.get("doctor_action_complete", False):
                doctor_acted = True
            else:
                # Проверяем, помечен ли кто-то как спасенный доктором
                for check_slot in game_data["players_slots"]:
                    if check_slot.get("saved_by_doctor"):
                        doctor_acted = True
                        break
            
            if not doctor_acted:
                night_roles_completed = False
                logger.info(f"Waiting for doctor action")
            break
    
    # Проверяем комиссара  
    commissioner_acted = True  # По умолчанию считаем что комиссар не нужен
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") == "Комиссар"):
            # Если комиссар есть в игре, проверяем завершил ли он действие
            if not slot.get("commissioner_action_complete", False):
                commissioner_acted = False
                logger.info(f"Waiting for commissioner action")
            break
    
    # Проверяем маньяка
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") == "Маньяк"):
            # Проверяем, завершил ли маньяк свое действие (убил кого-то ИЛИ пропустил ход)
            maniac_acted = False
            if slot.get("maniac_action_complete", False):
                maniac_acted = True
            else:
                # Проверяем, помечен ли кто-то как цель маньяка
                for check_slot in game_data["players_slots"]:
                    if check_slot.get("targeted_by_maniac"):
                        maniac_acted = True
                        break
            
            if not maniac_acted:
                night_roles_completed = False
                logger.info(f"Waiting for maniac action")
            break
    
    # Проверяем путану
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") == "Путана"):
            # Проверяем, завершила ли путана свое действие (заблокировала кого-то ИЛИ пропустила ход)
            prostitute_acted = False
            if slot.get("prostitute_action_complete", False):
                prostitute_acted = True
            else:
                # Проверяем, заблокирован ли кто-то путаной
                for check_slot in game_data["players_slots"]:
                    if check_slot.get("blocked_by_prostitute"):
                        prostitute_acted = True
                        break
            
            if not prostitute_acted:
                night_roles_completed = False
                logger.info(f"Waiting for prostitute action")
            break
    
    logger.info(f"Night actions status for game {game_id}: math={math_completed}, roles={night_roles_completed}")
    
    # Если ВСЕ действия завершены - переходим к дню
    if math_completed and night_roles_completed:
        logger.info(f"All night actions completed in game {game_id}, starting day early")
        
        # Отправляем уведомление всем игрокам
        for slot in game_data["players_slots"]:
            if slot.get("status") == STATUS_ACTIVE and slot.get("user_id"):
                try:
                    await context.bot.send_message(
                        slot["user_id"],
                        "✅ **Все ночные действия завершены!**\n\n"
                        "🌅 Город просыпается...",
                        parse_mode=ParseMode.MARKDOWN
                    )
                except Exception as e:
                    logger.error(f"Error sending early day message to player {slot.get('user_id')}: {e}")
        
        # Переходим к дню с небольшой задержкой
        import asyncio
        asyncio.create_task(start_day_after_math_completion(game_id, context))
    else:
        # Снимаем флаг обработки если действия еще не завершены
        game_data["night_completion_processing"] = False
        games[game_id] = game_data

async def start_day_after_math_completion(game_id: str, context: CallbackContext):
    """Начинает день после завершения всех математических примеров"""
    # Небольшая задержка перед переходом к дню
    try:
        await asyncio.sleep(3)  # 3 секунды задержки
    except Exception as e:
        logger.error(f"Error during sleep in start_day_after_math_completion: {e}")
        return
    
    # Получаем актуальные данные игры
    game_data = games.get(game_id)
    if not game_data or game_data.get("state") != STATE_NIGHT:
        return
    
    # Снимаем флаг обработки ночных действий
    game_data["night_completion_processing"] = False
    games[game_id] = game_data
    
    # Переходим к дню
    await start_day_after_night(game_id, game_data, context)

async def update_voting_rights(game_id: str, user_id: int, has_rights: bool):
    """Обновляет права голосования игрока в игре"""
    if game_id not in games:
        return
    
    game_data = games[game_id]
    
    # Находим игрока и обновляем его права голосования
    for i, slot in enumerate(game_data.get("players_slots", [])):
        if slot.get("user_id") == user_id:
            player_key = f"player_{i}"
            if "day_voting_rights" not in game_data:
                game_data["day_voting_rights"] = {}
            game_data["day_voting_rights"][player_key] = has_rights
            break
    
    games[game_id] = game_data
    logger.info(f"Updated voting rights for user {user_id} in game {game_id}: {has_rights}")

def get_start_message_text_and_keyboard():
    """Возвращает текст и клавиатуру для стартового сообщения"""
    text = (
        "🎭 *Добро пожаловать в МАФИЮ!*\n\n"
        "Классическая психологическая игра теперь в Telegram!\n"
        "Создавайте игры, приглашайте друзей и наслаждайтесь атмосферой детектива.\n\n"
        
        "*Доступно 2 режима игры:*\n\n"
        
        "🆓 *БЕСПЛАТНЫЙ РЕЖИМ:*\n"
        "• До 8 игроков\n"
        "• Ведущий - вы или бот\n"
        "• Базовые роли (Мафиози, Комиссар, Доктор, Мирный житель)\n"
        "• Автоматическое распределение ролей\n\n"
        
        "💎 *ПРЕМИУМ РЕЖИМ:*\n"
        "• До 20 игроков\n"
        "• Ведущий - вы ИЛИ умный бот\n"
        "• ВСЕ роли (Дон Мафии, Маньяк, Путана и др.)\n"
        "• Ручная настройка ролей\n"
        "• Расширенная статистика\n\n"
        
        "🚀 Начните играть прямо сейчас!"
    )
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🎮 Создать игру", callback_data="create_game")],
        [InlineKeyboardButton("📖 Правила игры", callback_data="rules")],
        [InlineKeyboardButton("🎯 Попробовать демо (14 дней)", callback_data="activate_demo")],
        [InlineKeyboardButton("💎 О Премиум", callback_data="get_premium")]
    ])
    
    return text, keyboard



async def assign_roles_standard(num_players: int):
    """Распределяет роли для стандартной игры"""
    if num_players < 4:
        return None
    
    # Базовая раскладка
    roles = []
    
    if num_players == 4:
        roles = ["Мафиози", "Комиссар", "Мирный житель", "Мирный житель"]
    elif num_players == 5:
        roles = ["Мафиози", "Комиссар", "Доктор", "Мирный житель", "Мирный житель"]
    elif num_players == 6:
        roles = ["Мафиози", "Мафиози", "Комиссар", "Доктор", "Мирный житель", "Мирный житель"]
    elif num_players == 7:
        roles = ["Мафиози", "Мафиози", "Комиссар", "Доктор", "Мирный житель", "Мирный житель", "Мирный житель"]
    elif num_players == 8:
        roles = ["Дон Мафии", "Мафиози", "Комиссар", "Доктор", "Мирный житель", "Мирный житель", "Мирный житель", "Мирный житель"]
    elif num_players >= 9:
        # Для большего количества игроков
        mafia_count = max(2, num_players // 3)
        roles = ["Дон Мафии"] + ["Мафиози"] * (mafia_count - 1)
        roles.extend(["Комиссар", "Доктор"])
        
        if num_players >= 10:
            roles.append("Маньяк")
        if num_players >= 12:
            roles.append("Путана")
            
        # Заполняем оставшиеся места мирными жителями
        while len(roles) < num_players:
            roles.append("Мирный житель")
    
    # Улучшенная рандомизация
    for _ in range(3):
        random.shuffle(roles)
    
    # Дополнительная рандомизация
    roles = random.sample(roles, len(roles))
    
    return roles

async def assign_roles_free(num_players: int):
    """Распределяет роли для бесплатной игры (4-8 игроков)"""
    if num_players < 4 or num_players > 8:
        return None
    
    # Упрощенная раскладка для бесплатной версии - только базовые роли
    roles = []
    
    if num_players == 4:
        roles = ["Мафиози", "Комиссар", "Мирный житель", "Мирный житель"]
    elif num_players == 5:
        roles = ["Мафиози", "Комиссар", "Доктор", "Мирный житель", "Мирный житель"]
    elif num_players == 6:
        roles = ["Мафиози", "Мафиози", "Комиссар", "Доктор", "Мирный житель", "Мирный житель"]
    elif num_players == 7:
        roles = ["Мафиози", "Мафиози", "Комиссар", "Доктор", "Мирный житель", "Мирный житель", "Мирный житель"]
    elif num_players == 8:
        roles = ["Мафиози", "Мафиози", "Комиссар", "Доктор", "Мирный житель", "Мирный житель", "Мирный житель", "Мирный житель"]
    
    # Улучшенная рандомизация
    for _ in range(3):
        random.shuffle(roles)
    
    # Дополнительная рандомизация
    roles = random.sample(roles, len(roles))
    
    return roles

async def start(update: Update, context: CallbackContext):
    """Обработчик команды /start"""
    user = update.effective_user
    args = context.args

    # Если есть аргументы, это попытка присоединиться к игре
    if args:
        game_id = args[0]
        if game_id.startswith("join_"):
            game_id = game_id[5:]
        
        if game_id not in games:
            await update.message.reply_text("❌ Игра не найдена.")
            return
        
        await join_game(update, context, game_id)
        return

    # Проверяем, не участвует ли пользователь в активной игре
    active_sessions = await find_all_player_game_sessions(user.id)
    
    if active_sessions:
        # Пользователь уже в игре
        current_game_id = active_sessions[0][0]  # Берем первую игру
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🎮 Создать игру", callback_data="create_game")],
            [InlineKeyboardButton("🚪 Покинуть текущую игру", callback_data=f"leave_game_{current_game_id}")],
            [InlineKeyboardButton("📖 Правила игры", callback_data="rules")],
            [InlineKeyboardButton("💎 О Премиум", callback_data="get_premium")]
        ])
        
        text = (
            "🎭 *Добро пожаловать в МАФИЮ!*\n\n"
            f"⚠️ *Вы сейчас участвуете в игре: {current_game_id}*\n\n"
            "🔄 Создать новую игру или покинуть текущую?"
        )
        
        await update.message.reply_text(text, parse_mode=None, reply_markup=keyboard)
    else:
        # Показываем обычное стартовое меню
        text, keyboard = get_start_message_text_and_keyboard()
        await update.message.reply_text(text, parse_mode=None, reply_markup=keyboard)

async def update_game_status_for_all_players(game_id: str, context: CallbackContext):
    """Обновляет статус игры для всех участников"""
    game_data = games.get(game_id)
    if not game_data:
        return
    
    filled_slots = sum(1 for s in game_data['players_slots'] if s.get('user_id'))
    total_slots = game_data.get('num_players', 6)
    
    status_message = (
        f"👥 Статус игры {game_id}\n\n"
        f"Присоединилось: {filled_slots}/{total_slots} игроков\n"
        f"🕐 Ожидаем остальных участников..."
    )
    
    # Отправляем обновление всем присоединившимся игрокам
    for slot in game_data['players_slots']:
        if slot.get('user_id'):
            try:
                await context.bot.send_message(
                    slot['user_id'],
                    status_message,
                    parse_mode=None  # Убираем markdown парсинг для избежания ошибок
                )
            except Exception as e:
                print(f"❌ Ошибка отправки обновления статуса игроку {slot['user_id']}: {e}")

async def join_game(update: Update, context: CallbackContext, game_id: str):
    """Присоединение игрока к игре"""
    user = update.effective_user
    
    # Проверяем, что игра существует
    if game_id not in games:
        await update.message.reply_text("❌ Игра не найдена. Возможно, она уже завершена.")
        return

    game = games[game_id]
    
    # В режиме human_host хост не может присоединиться как игрок
    if (game.get('game_mode') == 'human_host' and 
        game.get('host_id') == user.id):
        await update.message.reply_text(
            "❌ Вы являетесь ведущим этой игры и не можете присоединиться как игрок.\n"
            "💡 Используйте команду /manage для управления игрой."
        )
        return
    
    # Проверяем, не присоединился ли игрок уже к ЭТОЙ игре
    for slot in game.get('players_slots', []):
        if slot.get('user_id') == user.id:
            await update.message.reply_text("✅ Вы уже присоединились к этой игре!")
            return
    
    # НОВАЯ ПРОВЕРКА: Проверяем, не участвует ли пользователь в других активных играх
    active_sessions = await find_all_player_game_sessions(user.id)
    if active_sessions:
        # Пользователь уже участвует в других играх
        other_games = [session[0] for session in active_sessions if session[0] != game_id]
        
        if other_games:
            # Обычно должна быть только одна игра, но для надежности обрабатываем множественный случай
            current_game = other_games[0]  # Берем первую игру
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("🚪 Покинуть текущую игру", 
                                    callback_data=f"leave_games_and_join_{game_id}")],
                [InlineKeyboardButton("❌ Остаться в текущей игре", 
                                    callback_data="cancel_join")]
            ])
            
            await update.message.reply_text(
                f"⚠️ Конфликт игр!\n\n"
                f"Вы уже участвуете в активной игре: {current_game}\n\n"
                f"🎭 Нельзя участвовать в двух играх одновременно.\n\n"
                f"Выберите действие:",
                reply_markup=keyboard,
                parse_mode=None
            )
            return
    
    # Ищем свободный слот
    for i, slot in enumerate(game.get('players_slots', [])):
        if not slot.get('user_id'):
            # Назначаем игрока в этот слот
            slot['user_id'] = user.id
            slot['_user_first_name'] = user.first_name
            slot['player_number_for_host'] = i + 1
            
            # Сохраняем ТГ имя для отображения
            real_name = user.first_name or "Игрок"
            if user.last_name:
                real_name += f" {user.last_name}"
            slot['real_name'] = real_name
            
            # Проверяем союзников мафии
            mafia_allies_text = ""
            if slot['role'] in ["Мафиози", "Дон Мафии"]:
                allies = []
                for other_slot in game['players_slots']:
                    if (other_slot.get('user_id') and 
                        other_slot.get('user_id') != user.id and
                        other_slot.get('role') in ["Мафиози", "Дон Мафии"]):
                        allies.append(f"{other_slot['fictional_name']} ({other_slot.get('real_name', 'Неизвестно')})")
                
                if allies:
                    mafia_allies_text = f"\n🤝 Ваши союзники в мафии:\n• " + "\n• ".join(allies) + "\n"
                else:
                    mafia_allies_text = "\n👤 Вы единственная мафия в этой игре.\n"

            # Для таймер-игр отправляем простое сообщение без роли
            if game.get('state') == STATE_TIMER_WAITING:
                filled_slots = sum(1 for s in game['players_slots'] if s.get('user_id'))
                total_slots = game.get('max_players', 20)
                
                # Получаем время до старта
                timer_started = game.get('timer_started_at')
                if timer_started:
                    from datetime import datetime
                    # Преобразуем строку в datetime объект
                    if isinstance(timer_started, str):
                        timer_started = datetime.strptime(timer_started, "%Y-%m-%d %H:%M:%S")
                    elapsed = datetime.now() - timer_started
                    remaining_time = max(0, 180 - int(elapsed.total_seconds()))
                    remaining_minutes = remaining_time // 60
                    remaining_seconds = remaining_time % 60
                    time_text = f"{remaining_minutes}:{remaining_seconds:02d}"
                else:
                    time_text = "3:00"
                
                message_text = (
                    f"🎯 Добро пожаловать в игру!\n\n"
                    f"Ваше имя: {slot['fictional_name']}\n"
                    f"Ваша история: {slot['description']}\n\n"
                    f"⏰ Режим времени: Через 3 минуты игра начнется автоматически с теми, кто успел присоединиться!\n"
                    f"⏱️ Оставшееся время: {time_text}\n"
                    f"👥 Присоединилось игроков: {filled_slots}/{total_slots}\n"
                    f"🎯 Минимум для старта: 4 игрока\n\n"
                    f"🎭 Ваша роль будет назначена после истечения времени!\n\n"
                    f"💬 Система чата: После начала игры вы сможете общаться с другими игроками, просто написав сообщение боту."
                )
            else:
                # Обычные игры - отправляем полную информацию с ролью
                message_text = (
                    f"🎭 Добро пожаловать в игру!\n\n"
                    f"Ваше имя: {slot['fictional_name']}\n"
                    f"Ваша история: {slot['description']}\n"
                    f"**Ваша роль: {slot['role']}**\n\n"
                    f"{get_role_description(slot['role'])}"
                    f"{mafia_allies_text}\n"
                    f"💬 Система чата: После начала игры вы сможете общаться с другими игроками, просто написав сообщение боту.\n\n"
                    f"⏳ Ожидаем остальных игроков..."
                )
            
            await update.message.reply_text(message_text)
            
            # Уведомляем ведущего ТОЛЬКО в режиме human_host (где хост = ведущий, не игрок)
            game_mode = game.get('game_mode', 'human_host')
            if game_mode == 'human_host':
                # В режиме с человеком-ведущим - показываем роли хосту (он ведущий)
                try:
                    await context.bot.send_message(
                        game['host_id'],
                        f"✅ Игрок присоединился!\n"
                        f"Слот {i + 1}: {user.first_name} ({slot['fictional_name']})\n"
                        f"Роль: {slot['role']}",
                        parse_mode=None
                    )
                except:
                    pass
            # В режиме bot_host НЕ отправляем индивидуальные уведомления о присоединении
            # (хост тоже игрок и получит общее уведомление только когда все присоединятся)
            
            # Проверяем, все ли игроки присоединились
            filled_slots = sum(1 for s in game['players_slots'] if s.get('user_id'))
            
            # Специальная обработка для режима таймера
            if game.get('state') == STATE_TIMER_WAITING:
                # Для таймер-игр используем max_players
                total_slots = game.get('max_players', 20)
                
                # ЗАПУСКАЕМ ТАЙМЕР ПРИ ПРИСОЕДИНЕНИИ ПЕРВОГО ИГРОКА
                if filled_slots == 1 and not game.get('timer_started', False):
                    # Устанавливаем время начала таймера
                    from datetime import datetime
                    game['timer_started_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    game['timer_started'] = True
                    
                    # Запускаем 3-минутный таймер и автообновление
                    import asyncio
                    asyncio.create_task(start_timer_game_after_delay(game_id, context))
                    asyncio.create_task(auto_update_timer_status(game_id, context))
                    
                    # Уведомляем первого игрока о запуске таймера
                    try:
                        await context.bot.send_message(
                            user.id,
                            f"⏰ Таймер запущен! Игра начнется через 3 минуты.\n"
                            f"👥 Игроков: {filled_slots}/{total_slots}\n"
                            f"🎯 Минимум для старта: 4 игрока\n\n"
                            f"📢 Приглашайте друзей по ссылке!"
                        )
                    except:
                        pass
                else:
                    # Уведомляем всех остальных игроков о присоединении нового
                    remaining_time_msg = ""
                    if game.get('timer_started_at'):
                        try:
                            from datetime import datetime, timedelta
                            start_time = datetime.strptime(game['timer_started_at'], "%Y-%m-%d %H:%M:%S")
                            elapsed = datetime.now() - start_time
                            remaining = timedelta(minutes=3) - elapsed
                            if remaining.total_seconds() > 0:
                                minutes = int(remaining.total_seconds() // 60)
                                seconds = int(remaining.total_seconds() % 60)
                                remaining_time_msg = f"⏰ До старта: {minutes}:{seconds:02d}\n"
                        except:
                            remaining_time_msg = "⏰ Игра скоро начнется!\n"
                    
                    for slot in game['players_slots']:
                        if slot.get('user_id') and slot.get('user_id') != user.id:
                            try:
                                await context.bot.send_message(
                                    slot['user_id'],
                                    f"👥 К игре присоединился новый игрок!\n"
                                    f"Игроков: {filled_slots}/{total_slots}\n"
                                    f"{remaining_time_msg}"
                                    f"🎯 Минимум для старта: 4 игрока"
                                )
                            except:
                                pass
                
                # В режиме таймера НЕ запускаем игру досрочно - только ждем таймер
                return
            
            # Обычная логика для стандартных режимов - используем num_players
            total_slots = game.get('num_players', 6)
            if filled_slots >= total_slots:
                game['state'] = 'ready'
                
                # Уведомления различаются в зависимости от режима игры
                if game_mode == 'human_host':
                    await context.bot.send_message(
                        game['host_id'],
                        f"🎉 Все игроки присоединились!\n"
                        f"Игра готова к запуску.",
                        parse_mode=None
                    )
                else:
                    await context.bot.send_message(
                        game['host_id'],
                        f"🎉 Все игроки присоединились!\n"
                        f"🤖 Бот-ведущий автоматически запускает игру...",
                        parse_mode=None
                    )
                
                # Если это бот-ведущий, запускаем игру автоматически
                if game.get('game_mode') == 'bot_host':
                    await start_bot_hosted_game(game_id, game, context)
                    
            else:
                # Уведомления о статусе ТОЛЬКО в режиме human_host
                if game_mode == 'human_host':
                    await context.bot.send_message(
                        game['host_id'],
                        f"📊 Статус игры:\n"
                        f"Присоединилось: {filled_slots}/{total_slots} игроков",
                        parse_mode=None
                    )
                
                # Обновляем статус для всех игроков в любом режиме
                await update_game_status_for_all_players(game_id, context)
            return
    
    # Если дошли сюда, значит свободных слотов нет
    await update.message.reply_text("❌ В игре нет свободных мест.")

async def start_bot_hosted_game(game_id: str, game_data: dict, context: CallbackContext):
    """Запуск игры с ботом-ведущим - полная реализация"""
    try:
        logger.info(f"Starting bot-hosted game logic for game {game_id}")

        # Получаем актуальные данные игры
        game_data = games.get(game_id, game_data)

        # Уведомляем всех игроков и хоста о начале игры
        host_id = game_data["host_id"]

        # Проверяем, является ли хост игроком
        host_is_player = any(slot.get("status") == STATUS_ACTIVE and slot.get("user_id") == host_id 
                           for slot in game_data["players_slots"])

        # Отправляем сообщение всем игрокам о запуске игры
        for slot in game_data["players_slots"]:
            if slot.get("status") == STATUS_ACTIVE and slot.get("user_id"):
                try:
                    await context.bot.send_message(
                        slot["user_id"],
                        f"✅ Игра {game_id} в режиме 'Ведущий - Бот' запущена! Все игроки присоединились."
                    )
                except Exception as e:
                    logger.error(f"Error sending game start notification to player {slot.get('user_id')}: {e}")

        # Уведомляем хоста ТОЛЬКО если он НЕ игрок (чтобы избежать дублирования)
        if not host_is_player:
            try:
                await context.bot.send_message(
                    host_id,
                    f"✅ Игра {game_id} в режиме 'Ведущий - Бот' запущена! Все игроки присоединились."
                )
            except Exception as e:
                logger.error(f"Error sending game start notification to host: {e}")

        # Подготавливаем игру к старту - начинаем с первого дня
        game_data["state"] = STATE_DAY
        game_data["current_day_number"] = 1
        game_data["current_night_number"] = 0
        game_data["math_examples"] = {}
        game_data["math_answers"] = {}
        game_data["day_voting_rights"] = {}
        game_data["first_day_skip_votes"] = set()  # Для отслеживания голосов за пропуск первого дня
        game_data["night_actions"] = {}
        game_data["day_votes"] = {}

        # Инициализируем права голосования: роли с ночными действиями = автоматические права, мирные = нет
        for i, slot in enumerate(game_data["players_slots"]):
            if slot.get("status") == STATUS_ACTIVE:
                player_key = f"player_{i}"
                # Роли с ночными действиями получают автоматические права голоса
                has_night_role = slot.get("role") in NIGHT_ROLES
                game_data["day_voting_rights"][player_key] = has_night_role

        # Сохраняем обновленные данные игры
        games[game_id] = game_data

        # Отправляем сообщение всем игрокам о начале первого дня
        await announce_first_day(game_id, game_data, context)
        
        logger.info(f"Бот-ведущий: игра {game_id} успешно запущена")
        
    except Exception as e:
        logger.error(f"Ошибка при запуске игры с ботом-ведущим {game_id}: {e}")

async def announce_first_day(game_id: str, game_data: dict, context: CallbackContext):
    """Объявляет о начале первого дня всем игрокам и запускает таймер на 10 минут"""
    logger.info(f"Announcing first day for game {game_id}")

    # Получаем актуальные данные игры
    game_data = games.get(game_id, game_data)

    # Убедимся, что игра в состоянии первого дня
    game_data["state"] = STATE_DAY
    game_data["current_day_number"] = 1
    if "first_day_skip_votes" not in game_data:
        game_data["first_day_skip_votes"] = set()
    games[game_id] = game_data

    # Создаем клавиатуру для пропуска первого дня
    keyboard = [[InlineKeyboardButton("⭕ Пропустить первый день", callback_data=f"skip_first_day_{game_id}")]]
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Сообщение о начале первого дня
    day_message = (
        "🌅 Доброе утро, город! Начинается первый день игры.\n\n"
        "Сейчас у вас есть 10 минут, чтобы познакомиться и обсудить стратегию.\n"
        "Вы можете пропустить первый день, если все игроки готовы начать игру немедленно.\n\n"
        "💬 ЧАТ АКТИВЕН! Просто напишите сообщение боту, и оно будет отправлено всем живым игрокам.\n\n"
        "📊 Статус голосования:\n"
        "🗳️ Проголосовали: 0/N\n"
        "⏳ Ожидаем голосов игроков..."
    )

    # Проверяем, является ли хост участником игры
    host_is_player = False
    for slot in game_data["players_slots"]:
        if slot.get("status") == STATUS_ACTIVE and slot.get("user_id") == game_data["host_id"]:
            host_is_player = True
            break

    # Список для сохранения ID отправленных сообщений
    sent_messages = []
    total_players = len([slot for slot in game_data["players_slots"] if slot.get("status") == STATUS_ACTIVE])

    # Отправляем сообщение всем игрокам
    for slot in game_data["players_slots"]:
        if slot.get("status") == STATUS_ACTIVE and slot.get("user_id"):
            try:
                # Обновляем сообщение с правильным количеством игроков
                player_message = day_message.replace("🗳️ Проголосовали: 0/N", f"🗳️ Проголосовали: 0/{total_players}")
                
                message = await context.bot.send_message(
                    slot["user_id"],
                    player_message,
                    reply_markup=reply_markup,
                    parse_mode=None
                )
                sent_messages.append({
                    "chat_id": message.chat_id,
                    "message_id": message.message_id
                })
            except Exception as e:
                logger.error(f"Error sending first day message to player {slot.get('user_id')}: {e}")

    # Отправляем сообщение хосту ТОЛЬКО если он не является участником игры И не в режиме бот-ведущего
    if not host_is_player and game_data.get("game_mode") != "bot_host":
        try:
            host_message = f"🌅 Первый день начался в игре {game_id}. Игроки имеют 10 минут на обсуждение или могут пропустить его.\n\n📊 Голосование: 0/{total_players}"
            
            message = await context.bot.send_message(
                game_data["host_id"],
                host_message,
                reply_markup=reply_markup,
                parse_mode=None
            )
            sent_messages.append({
                "chat_id": message.chat_id,
                "message_id": message.message_id
            })
        except Exception as e:
            logger.error(f"Error sending first day message to host: {e}")

    # Сохраняем ID сообщений для последующего обновления
    game_data["first_day_messages"] = sent_messages
    games[game_id] = game_data

    # Запускаем таймер на 10 минут для первого дня
    import asyncio
    asyncio.create_task(end_first_day_after_timeout(game_id, context))

async def end_first_day_after_timeout(game_id: str, context: CallbackContext):
    """Завершает первый день после 10-минутного таймаута"""
    # Ждем 10 минут
    try:
        await asyncio.sleep(600)  # 10 минут = 600 секунд
    except Exception as e:
        logger.error(f"Error during sleep in end_first_day_after_timeout: {e}")
        return

    # Получаем актуальные данные игры
    game_data = games.get(game_id)
    if not game_data:
        logger.error(f"Game {game_id} not found when ending first day")
        return

    # Проверяем, что игра все еще в состоянии первого дня
    if game_data.get("state") != STATE_DAY or game_data.get("current_day_number") != 1:
        logger.info(f"Game {game_id} is no longer in first day state, skipping timeout handling")
        return

    # Завершаем первый день и начинаем первую ночь
    await start_first_night(game_id, game_data, context)

async def start_first_night(game_id: str, game_data: dict, context: CallbackContext):
    """Завершает первый день и начинает первую ночь"""
    logger.info(f"Starting first night for game {game_id}")

    # Обновляем состояние игры
    game_data["state"] = STATE_NIGHT
    game_data["current_night_number"] = 1
    
    # Сбрасываем математические состояния для всех игроков этой игры
    # ТОЛЬКО в режиме бот-ведущего (на случай если были предыдущие состояния)
    if game_data.get("game_mode") == "bot_host":
        users_to_reset = []
        for user_id, math_state in user_math_state.items():
            if math_state.get("game_id") == game_id:
                users_to_reset.append(user_id)
        
        for user_id in users_to_reset:
            del user_math_state[user_id]
            logger.info(f"Reset math state for user {user_id} for first night in game {game_id} (bot-host mode)")
    
    games[game_id] = game_data

    # Отправляем сообщение всем игрокам о начале первой ночи
    await announce_night_start(game_id, game_data, context)

    # Запускаем первую ночь
    await start_night_actions(game_id, game_data, context)

async def announce_night_start(game_id: str, game_data: dict, context: CallbackContext):
    """Объявляет о начале ночи всем игрокам"""
    night_number = game_data.get("current_night_number", 1)
    night_message = f"🌙 Наступает ночь #{night_number} в городе. Все жители засыпают..."

    # Отправляем сообщение всем игрокам
    for slot in game_data["players_slots"]:
        if slot.get("status") == STATUS_ACTIVE and slot.get("user_id"):
            try:
                await context.bot.send_message(
                    slot["user_id"],
                    night_message
                )
            except Exception as e:
                logger.error(f"Error sending night message to player {slot.get('user_id')}: {e}")

    # Отправляем сообщение хосту ТОЛЬКО если он не является игроком и игра не в режиме бот-ведущего
    host_is_player = any(
        slot.get("status") == STATUS_ACTIVE and slot.get("user_id") == game_data["host_id"]
        for slot in game_data["players_slots"]
    )
    
    # В режиме бот-ведущего не спамим хосту, если он не участвует
    if not host_is_player and game_data.get("game_mode") != "bot_host":
        await context.bot.send_message(
            game_data["host_id"],
            f"🌙 Ночь #{night_number} началась в игре {game_id}. Бот автоматически проведет все ночные действия."
        )

async def start_night_actions(game_id: str, game_data: dict, context: CallbackContext):
    """Запускает ночные действия для всех ролей"""
    logger.info(f"Starting night actions for game {game_id}")

    # Получаем актуальные данные игры
    game_data = games.get(game_id, game_data)

    # Проверяем, что игра в состоянии ночи
    if game_data.get("state") != STATE_NIGHT:
        logger.info(f"Game {game_id} is not in night state, skipping night actions")
        return

    # Получаем список ролей, которые должны действовать в эту ночь
    roles_to_act = get_roles_to_act_in_night(game_data)

    # Создаем словарь для хранения действий каждой роли
    night_actions = {}

    # Проходим по каждой роли и выполняем ее действие
    for role in roles_to_act:
        role_actions = await perform_role_night_action(role, game_id, game_data, context)
        night_actions[role] = role_actions

    # Сохраняем действия в данных игры
    game_data["night_data"] = {
        "actions_taken_by_role": night_actions,
        "roles_to_act": roles_to_act
    }
    games[game_id] = game_data

    # Отправляем математические примеры игрокам с пассивными ролями
    # В режиме "Бот-Ведущий" (включая таймер-игры)
    game_mode = game_data.get("game_mode", "")
    # Исправленная проверка режима - включает все варианты bot_host
    game_mode_str = str(game_mode)
    if "bot_host" in game_mode_str:  # bot_host, bot_host_timer
        await send_math_problems_to_passive_players(game_id, game_data, context)
        logger.info(f"Math problems sent to passive players in bot-host mode for game {game_id} (mode: {game_mode_str})")
    else:
        logger.info(f"Skipping math problems for game {game_id} - not in bot-host mode (mode: {game_mode_str})")

    # Запускаем таймер на 5 минут для ночи (сократил с 10 для быстрой игры)
    import asyncio
    asyncio.create_task(end_night_after_timeout(game_id, context))

async def perform_role_night_action(role: str, game_id: str, game_data: dict, context: CallbackContext):
    """Выполняет ночное действие для указанной роли - отправляет интерактивные кнопки для выбора"""
    logger.info(f"Performing night action for role {role} in game {game_id}")

    # Получаем актуальные данные игры
    game_data = games.get(game_id, game_data)

    # Проверяем, что игра в состоянии ночи
    if game_data.get("state") != STATE_NIGHT:
        logger.info(f"Game {game_id} is not in night state, skipping night action for role {role}")
        return {}

    # Получаем список активных игроков с данной ролью
    role_players = []
    for slot in game_data["players_slots"]:
        if slot.get("status") == STATUS_ACTIVE and slot.get("role") == role:
            role_players.append(slot)

    if not role_players:
        logger.info(f"No players with role {role} found in game {game_id}")
        return {}

    # Получаем список активных игроков как потенциальных целей
    target_slots = []
    for slot in game_data["players_slots"]:
        if slot.get("status") == STATUS_ACTIVE:
            target_slots.append(slot)

    if not target_slots:
        logger.info(f"No valid targets for role {role} in game {game_id}")
        return {}

    # Отправляем интерактивные кнопки выбора для всех ночных ролей
    if role in ["Мафиози", "Дон Мафии"]:
        # Проверяем, не отправляли ли уже сообщение мафии
        night_data = game_data.get("night_data", {})
        if not night_data.get("mafia_selection_sent", False):
            await send_mafia_target_selection(game_id, game_data, context)
            night_data["mafia_selection_sent"] = True
            game_data["night_data"] = night_data
            games[game_id] = game_data
        return {"status": "interactive_selection_sent"}

    elif role == "Доктор":
        await send_doctor_target_selection(game_id, game_data, context)
        return {"status": "interactive_selection_sent"}

    elif role == "Комиссар":
        await send_commissioner_target_selection(game_id, game_data, context)
        return {"status": "interactive_selection_sent"}

    elif role == "Маньяк":
        await send_maniac_target_selection(game_id, game_data, context)
        return {"status": "interactive_selection_sent"}

    elif role == "Путана":
        await send_prostitute_target_selection(game_id, game_data, context)
        return {"status": "interactive_selection_sent"}

    logger.info(f"Unknown role {role} in game {game_id}, skipping night action")
    return {}

async def create_night_action_timer(game_id: str, role: str, user_ids: list, context: CallbackContext):
    """Создает таймер на 3 минуты для ночных действий с уведомлением за минуту"""
    import asyncio
    
    # Ждем 2 минуты (120 секунд)
    await asyncio.sleep(120)
    
    # Проверяем, что игра еще активна и в ночной фазе
    game_data = games.get(game_id)
    if not game_data or game_data.get("state") != STATE_NIGHT:
        return
    
    # Отправляем уведомление о том, что остается минута
    warning_message = (
        f"⏰ **Внимание!**\n\n"
        f"До окончания времени на ночное действие осталась **1 минута**!\n"
        f"Если вы не успеете сделать выбор, ваш ход будет пропущен автоматически."
    )
    
    # Проверяем, кто еще не сходил
    night_data = game_data.get("night_data", {})
    actions_taken = night_data.get("actions_taken_by_role", {})
    
    # Если роль еще не сходила, отправляем предупреждение
    if role not in actions_taken:
        for user_id in user_ids:
            try:
                await context.bot.send_message(
                    user_id,
                    warning_message,
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending night timer warning to user {user_id}: {e}")
    
    # Ждем еще минуту (60 секунд)
    await asyncio.sleep(60)
    
    # Проверяем финальное состояние игры
    game_data = games.get(game_id)
    if not game_data or game_data.get("state") != STATE_NIGHT:
        return
    
    # Если роль все еще не сходила, пропускаем ход автоматически
    night_data = game_data.get("night_data", {})
    actions_taken = night_data.get("actions_taken_by_role", {})
    
    if role not in actions_taken:
        timeout_message = (
            f"⏱️ **Время истекло!**\n\n"
            f"Ваш ход автоматически пропущен из-за превышения времени."
        )
        
        for user_id in user_ids:
            try:
                await context.bot.send_message(
                    user_id,
                    timeout_message,
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending night timeout message to user {user_id}: {e}")
        
        # Автоматически пропускаем ход для этой роли
        await auto_skip_night_action(game_id, role, context)

async def auto_skip_night_action(game_id: str, role: str, context: CallbackContext):
    """Автоматически пропускает ночное действие для роли при истечении времени"""
    game_data = games.get(game_id)
    if not game_data:
        return
    
    # Для мафии - проверяем, не выбрана ли уже цель
    if role == "Мафия":
        mafia_target_chosen = False
        for slot in game_data["players_slots"]:
            if slot.get("targeted_by_mafia"):
                mafia_target_chosen = True
                break
        
        if mafia_target_chosen:
            logger.info(f"Mafia already chose target in game {game_id}, not auto-skipping")
            return  # Не пропускаем если цель уже выбрана
    
    night_data = game_data.get("night_data", {})
    actions_taken = night_data.get("actions_taken_by_role", {})
    
    # Помечаем действие как выполненное (пропущенное)
    actions_taken[role] = "skipped"
    night_data["actions_taken_by_role"] = actions_taken
    game_data["night_data"] = night_data
    games[game_id] = game_data
    
    logger.info(f"Auto-skipped night action for role {role} in game {game_id} due to timeout")
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

async def send_mafia_target_selection(game_id: str, game_data: dict, context: CallbackContext):
    """Отправляет мафии кнопки для выбора жертвы"""
    # Получаем всех игроков мафии
    mafia_players = []
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") in ["Мафиози", "Дон Мафии"] and
            slot.get("user_id")):
            mafia_players.append(slot)

    if not mafia_players:
        logger.error(f"No mafia players found in game {game_id}")
        return

    # Получаем список потенциальных жертв (все активные игроки кроме мафии)
    potential_targets = []
    for i, slot in enumerate(game_data["players_slots"]):
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") not in ["Мафиози", "Дон Мафии"]):
            potential_targets.append((i, slot))

    if not potential_targets:
        logger.error(f"No potential targets for mafia in game {game_id}")
        return

    # Создаем клавиатуру с выбором жертвы
    keyboard = []
    for target_index, target_slot in potential_targets:
        display_name = get_player_display_name(target_slot, context)
        keyboard.append([InlineKeyboardButton(
            f"🔪 {display_name}", 
            callback_data=f"mafia_target_{game_id}_{target_index}"
        )])

    reply_markup = InlineKeyboardMarkup(keyboard)

    message_text = (
        f"🌙 **Ночь {game_data.get('current_night_number', 1)}**\n\n"
        f"🔪 **Мафия, выберите жертву:**\n\n"
        f"💬 **ЧАТ МАФИИ АКТИВЕН!** Можете обсудить выбор с союзниками.\n"
        f"Просто напишите сообщение боту - оно будет видно только мафии.\n\n"
        f"⏱️ **У вас есть 3 минуты на принятие решения.**\n"
        f"Выберите игрока, которого хотите устранить этой ночью."
    )

    # Отправляем сообщение всем игрокам мафии
    for mafia_slot in mafia_players:
        try:
            await context.bot.send_message(
                mafia_slot["user_id"],
                message_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            logger.info(f"Mafia target selection sent to user {mafia_slot['user_id']} in game {game_id}")
        except Exception as e:
            logger.error(f"Error sending mafia target selection to user {mafia_slot['user_id']}: {e}")
    
    # Запускаем таймер для мафии
    import asyncio
    mafia_user_ids = [slot["user_id"] for slot in mafia_players]
    asyncio.create_task(create_night_action_timer(game_id, "Мафия", mafia_user_ids, context))

async def send_doctor_target_selection(game_id: str, game_data: dict, context: CallbackContext):
    """Отправляет доктору кнопки для выбора кого лечить"""
    # Получаем доктора
    doctor_players = []
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") == "Доктор" and
            slot.get("user_id")):
            doctor_players.append(slot)

    if not doctor_players:
        return

    # Получаем список всех активных игроков как потенциальных пациентов
    potential_targets = []
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("status") == STATUS_ACTIVE:
            potential_targets.append((i, slot))

    if not potential_targets:
        return

    # Создаем клавиатуру с выбором пациента
    keyboard = []
    for target_index, target_slot in potential_targets:
        display_name = get_player_display_name(target_slot, context)
        keyboard.append([InlineKeyboardButton(
            f"🏥 {display_name}", 
            callback_data=f"doctor_target_{game_id}_{target_index}"
        )])
    
    # Добавляем кнопку "Пропустить ход"
    keyboard.append([InlineKeyboardButton(
        "❌ Пропустить ход", 
        callback_data=f"doctor_skip_{game_id}"
    )])

    reply_markup = InlineKeyboardMarkup(keyboard)

    message_text = (
        f"🌙 **Ночь {game_data.get('current_night_number', 1)}**\n\n"
        f"🏥 **Доктор, выберите кого лечить:**\n\n"
        f"⏱️ **У вас есть 3 минуты на принятие решения.**\n\n"
        f"Вы можете спасти одного игрока от смерти этой ночью.\n"
        f"Выберите мудро - ваш выбор может решить исход игры!"
    )

    # Отправляем сообщение доктору
    for doctor_slot in doctor_players:
        try:
            await context.bot.send_message(
                doctor_slot["user_id"],
                message_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            logger.info(f"Doctor target selection sent to user {doctor_slot['user_id']} in game {game_id}")
        except Exception as e:
            logger.error(f"Error sending doctor target selection to user {doctor_slot['user_id']}: {e}")
    
    # Запускаем таймер для доктора
    import asyncio
    doctor_user_ids = [slot["user_id"] for slot in doctor_players]
    asyncio.create_task(create_night_action_timer(game_id, "Доктор", doctor_user_ids, context))

async def send_commissioner_target_selection(game_id: str, game_data: dict, context: CallbackContext):
    """Отправляет комиссару кнопки для выбора кого проверить"""
    # Получаем комиссара
    commissioner_players = []
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") == "Комиссар" and
            slot.get("user_id")):
            commissioner_players.append(slot)

    if not commissioner_players:
        return

    # Получаем список всех активных игроков кроме комиссара
    potential_targets = []
    for i, slot in enumerate(game_data["players_slots"]):
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") != "Комиссар"):
            potential_targets.append((i, slot))

    if not potential_targets:
        return

    keyboard = []
    for target_index, target_slot in potential_targets:
        display_name = get_player_display_name(target_slot, context)
        keyboard.append([InlineKeyboardButton(
            f"🔍 {display_name}", 
            callback_data=f"commissioner_target_{game_id}_{target_index}"
        )])

    reply_markup = InlineKeyboardMarkup(keyboard)

    message_text = (
        f"🌙 **Ночь {game_data.get('current_night_number', 1)}**\n\n"
        f"🔍 **Комиссар, выберите кого проверить:**\n\n"
        f"⏱️ **У вас есть 3 минуты на принятие решения.**\n\n"
        f"Вы можете узнать роль одного игрока.\n"
        f"Используйте эту информацию мудро в дневном голосовании!"
    )

    for commissioner_slot in commissioner_players:
        try:
            await context.bot.send_message(
                commissioner_slot["user_id"],
                message_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            logger.info(f"Commissioner target selection sent to user {commissioner_slot['user_id']} in game {game_id}")
        except Exception as e:
            logger.error(f"Error sending commissioner target selection to user {commissioner_slot['user_id']}: {e}")
    
    # Запускаем таймер для комиссара
    # Не запускаем автоматический таймер для комиссара в режиме бот-ведущего
    # Комиссару дается 3 минуты на выбор цели

async def send_maniac_target_selection(game_id: str, game_data: dict, context: CallbackContext):
    """Отправляет маньяку кнопки для выбора жертвы"""
    # Получаем маньяка
    maniac_players = []
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") == "Маньяк" and
            slot.get("user_id")):
            maniac_players.append(slot)

    if not maniac_players:
        return

    # Получаем список всех активных игроков кроме маньяка
    potential_targets = []
    for i, slot in enumerate(game_data["players_slots"]):
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") != "Маньяк"):
            potential_targets.append((i, slot))

    if not potential_targets:
        return

    keyboard = []
    for target_index, target_slot in potential_targets:
        display_name = get_player_display_name(target_slot, context)
        keyboard.append([InlineKeyboardButton(
            f"💀 {display_name}", 
            callback_data=f"maniac_target_{game_id}_{target_index}"
        )])
    
    # Добавляем кнопку "Пропустить ход"
    keyboard.append([InlineKeyboardButton(
        "❌ Пропустить ход", 
        callback_data=f"maniac_skip_{game_id}"
    )])

    reply_markup = InlineKeyboardMarkup(keyboard)

    message_text = (
        f"🌙 **Ночь {game_data.get('current_night_number', 1)}**\n\n"
        f"💀 **Маньяк, выберите жертву:**\n\n"
        f"Жажда крови зовет... Кого вы выберете этой ночью?\n"
        f"Ваша цель будет устранена независимо от мафии."
    )

    for maniac_slot in maniac_players:
        try:
            await context.bot.send_message(
                maniac_slot["user_id"],
                message_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            logger.info(f"Maniac target selection sent to user {maniac_slot['user_id']} in game {game_id}")
        except Exception as e:
            logger.error(f"Error sending maniac target selection to user {maniac_slot['user_id']}: {e}")

async def send_prostitute_target_selection(game_id: str, game_data: dict, context: CallbackContext):
    """Отправляет путане кнопки для выбора кого блокировать"""
    # Получаем путану
    prostitute_players = []
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") == "Путана" and
            slot.get("user_id")):
            prostitute_players.append(slot)

    if not prostitute_players:
        return

    # Получаем список всех активных игроков кроме путаны
    potential_targets = []
    for i, slot in enumerate(game_data["players_slots"]):
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") != "Путана"):
            potential_targets.append((i, slot))

    if not potential_targets:
        return

    keyboard = []
    for target_index, target_slot in potential_targets:
        display_name = get_player_display_name(target_slot, context)
        keyboard.append([InlineKeyboardButton(
            f"🚫 {display_name}", 
            callback_data=f"prostitute_target_{game_id}_{target_index}"
        )])
    
    # Добавляем кнопку "Пропустить ход"
    keyboard.append([InlineKeyboardButton(
        "❌ Пропустить ход", 
        callback_data=f"prostitute_skip_{game_id}"
    )])

    reply_markup = InlineKeyboardMarkup(keyboard)

    message_text = (
        f"🌙 **Ночь {game_data.get('current_night_number', 1)}**\n\n"
        f"🚫 **Путана, выберите кого заблокировать:**\n\n"
        f"Вы можете помешать одному игроку выполнить ночное действие.\n"
        f"Выберите цель которая может представлять угрозу!"
    )

    for prostitute_slot in prostitute_players:
        try:
            await context.bot.send_message(
                prostitute_slot["user_id"],
                message_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            logger.info(f"Prostitute target selection sent to user {prostitute_slot['user_id']} in game {game_id}")
        except Exception as e:
            logger.error(f"Error sending prostitute target selection to user {prostitute_slot['user_id']}: {e}")

async def handle_mafia_target_selection(query, context: CallbackContext, game_id: str, target_index: int):
    """Обрабатывает выбор жертвы мафией"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("❌ Игра не найдена", show_alert=True)
        return

    if game_data.get("state") != STATE_NIGHT:
        await query.answer("❌ Сейчас не ночь", show_alert=True)
        return

    voter_id = query.from_user.id
    
    # Проверяем, что голосующий - мафия
    is_mafia = False
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == voter_id and 
            slot.get("status") == STATUS_ACTIVE and
            slot.get("role") in ["Мафиози", "Дон Мафии"]):
            is_mafia = True
            break

    if not is_mafia:
        await query.answer("❌ Только мафия может выбирать жертву", show_alert=True)
        return

    # Проверяем, что цель существует и активна
    if target_index >= len(game_data["players_slots"]):
        await query.answer("❌ Неверный игрок", show_alert=True)
        return

    target_slot = game_data["players_slots"][target_index]
    if target_slot.get("status") != STATUS_ACTIVE:
        await query.answer("❌ Этот игрок уже исключен", show_alert=True)
        return

    if target_slot.get("role") in ["Мафиози", "Дон Мафии"]:
        await query.answer("❌ Мафия не может убить мафию", show_alert=True)
        return

    # Проверяем, не было ли уже сделано выбора мафией
    if "mafia_votes" not in game_data:
        game_data["mafia_votes"] = {}

    # Записываем голос мафии
    game_data["mafia_votes"][voter_id] = target_index
    games[game_id] = game_data

    target_name = get_player_display_name(target_slot, context)
    
    # Находим имя голосующего мафиози
    voter_name = "Член мафии"
    for slot in game_data["players_slots"]:
        if slot.get("user_id") == voter_id:
            voter_name = get_player_display_name(slot, context)
            break
    
    await query.edit_message_text(
        f"✅ **Цель выбрана**\n\n"
        f"🔪 Вы выбрали: **{target_name}**\n\n"
        f"Ожидаем выбора других членов мафии или завершения ночи...",
        parse_mode=ParseMode.MARKDOWN
    )

    logger.info(f"Mafia member {voter_id} chose target {target_index} ({target_name}) in game {game_id}")

    # Уведомляем ОСТАЛЬНЫХ членов мафии о выборе товарища
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") in ["Мафиози", "Дон Мафии"] and
            slot.get("user_id") and slot.get("user_id") != voter_id):
            try:
                await context.bot.send_message(
                    slot["user_id"],
                    f"👥 **Обновление от команды мафии**\n\n"
                    f"🗳️ **{voter_name}** проголосовал за: **{target_name}**\n\n"
                    f"💭 Обсудите выбор или сделайте свой голос!",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error notifying other mafia member {slot['user_id']}: {e}")

    # Проверяем, все ли члены мафии сделали выбор
    mafia_count = len([slot for slot in game_data["players_slots"] 
                      if slot.get("status") == STATUS_ACTIVE and 
                         slot.get("role") in ["Мафиози", "Дон Мафии"]])
    
    votes_count = len(game_data["mafia_votes"])
    
    if votes_count >= mafia_count:
        # Все мафия проголосовала, определяем окончательную цель
        await finalize_mafia_target(game_id, game_data, context)

async def handle_doctor_target_selection(query, context: CallbackContext, game_id: str, target_index: int):
    """Обрабатывает выбор пациента доктором с подтверждением"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return

    user_id = query.from_user.id
    doctor_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("role") == "Доктор" and 
            slot.get("status") == STATUS_ACTIVE):
            doctor_slot = slot
            break

    if not doctor_slot:
        await query.answer("У вас нет права выбирать пациента", show_alert=True)
        return

    if target_index < 0 or target_index >= len(game_data["players_slots"]):
        await query.answer("Некорректная цель", show_alert=True)
        return

    target_slot = game_data["players_slots"][target_index]
    if target_slot.get("status") != STATUS_ACTIVE:
        await query.answer("Этот игрок уже не участвует в игре", show_alert=True)
        return

    patient_name = get_player_display_name(target_slot, context)
    
    # Создаём клавиатуру подтверждения
    confirmation_keyboard = [
        [InlineKeyboardButton("✅ Подтвердить лечение", callback_data=f"confirm_doctor_{game_id}_{target_index}")],
        [InlineKeyboardButton("🔙 Выбрать другого", callback_data=f"return_doctor_{game_id}")]
    ]
    reply_markup = InlineKeyboardMarkup(confirmation_keyboard)
    
    confirmation_message = (
        f"🏥 **Подтверждение лечения**\n\n"
        f"🎯 Вы выбрали: **{patient_name}**\n\n"
        f"❓ Подтвердить свой выбор?\n"
        f"⚠️ После подтверждения изменить решение будет нельзя."
    )
    
    try:
        await query.edit_message_text(
            confirmation_message,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error showing doctor confirmation: {e}")

async def handle_confirm_doctor(query, context: CallbackContext, game_id: str, target_index: int):
    """Обрабатывает подтверждённое лечение доктора"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return

    user_id = query.from_user.id
    doctor_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("role") == "Доктор" and 
            slot.get("status") == STATUS_ACTIVE):
            doctor_slot = slot
            break

    if not doctor_slot:
        await query.answer("У вас нет права лечить", show_alert=True)
        return

    target_slot = game_data["players_slots"][target_index]
    target_slot["saved_by_doctor"] = True
    patient_name = get_player_display_name(target_slot, context)
    
    # Помечаем что доктор завершил действие
    doctor_slot["doctor_action_complete"] = True
    
    logger.info(f"Doctor {user_id} selected {patient_name} to heal in game {game_id}")

    try:
        await query.edit_message_text(
            f"🏥 **Ваш выбор зафиксирован**\n\n"
            f"Вы защитили: **{patient_name}**\n"
            f"Этой ночью ваш пациент будет в безопасности.",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating doctor message: {e}")

    games[game_id] = game_data
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

async def handle_return_doctor(query, context: CallbackContext, game_id: str):
    """Возвращает доктора к выбору пациента"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return
    
    # Отправляем заново интерфейс выбора
    await send_doctor_target_selection(game_id, game_data, context)
    await query.answer("Выберите пациента заново")

async def handle_commissioner_target_selection(query, context: CallbackContext, game_id: str, target_index: int):
    """Обрабатывает выбор цели комиссаром"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return

    user_id = query.from_user.id
    commissioner_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("role") == "Комиссар" and 
            slot.get("status") == STATUS_ACTIVE):
            commissioner_slot = slot
            break

    if not commissioner_slot:
        await query.answer("У вас нет права проводить проверку", show_alert=True)
        return

    if target_index < 0 or target_index >= len(game_data["players_slots"]):
        await query.answer("Некорректная цель", show_alert=True)
        return

    target_slot = game_data["players_slots"][target_index]
    if target_slot.get("status") != STATUS_ACTIVE:
        await query.answer("Этот игрок уже не участвует в игре", show_alert=True)
        return

    target_name = get_player_display_name(target_slot, context)
    target_role = target_slot["role"]
    is_mafia = target_role in ["Мафиози", "Дон Мафии"]
    
    result_text = "**МАФИЯ**" if is_mafia else "**НЕ МАФИЯ**"
    
    logger.info(f"Commissioner {user_id} checked {target_name} ({target_role}) in game {game_id}, result: {result_text}")

    await query.answer(f"✅ Результат проверки: {target_name} - {result_text}")
    
    try:
        await query.edit_message_text(
            f"🔍 **Результат проверки**\n\n"
            f"Проверен: **{target_name}**\n"
            f"Результат: {result_text}\n\n"
            f"Используйте эту информацию мудро в дневном голосовании!",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating commissioner message: {e}")
    
    # Помечаем что комиссар завершил действие
    commissioner_slot["commissioner_action_complete"] = True
    games[game_id] = game_data
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

async def handle_maniac_target_selection(query, context: CallbackContext, game_id: str, target_index: int):
    """Обрабатывает выбор жертвы маньяком"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return

    user_id = query.from_user.id
    maniac_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("role") == "Маньяк" and 
            slot.get("status") == STATUS_ACTIVE):
            maniac_slot = slot
            break

    if not maniac_slot:
        await query.answer("У вас нет права убивать", show_alert=True)
        return

    if target_index < 0 or target_index >= len(game_data["players_slots"]):
        await query.answer("Некорректная цель", show_alert=True)
        return

    target_slot = game_data["players_slots"][target_index]
    if target_slot.get("status") != STATUS_ACTIVE:
        await query.answer("Этот игрок уже не участвует в игре", show_alert=True)
        return

    target_slot["targeted_by_maniac"] = True
    victim_name = get_player_display_name(target_slot, context)
    
    # Помечаем что маньяк завершил действие
    maniac_slot["maniac_action_complete"] = True
    
    logger.info(f"Maniac {user_id} targeted {victim_name} in game {game_id}")

    await query.answer(f"✅ Вы выбрали жертву: {victim_name}")
    
    try:
        await query.edit_message_text(
            f"💀 **Жертва выбрана**\n\n"
            f"Цель: **{victim_name}**\n"
            f"Жажда крови будет утолена этой ночью...",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating maniac message: {e}")

    games[game_id] = game_data
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

async def handle_prostitute_target_selection(query, context: CallbackContext, game_id: str, target_index: int):
    """Обрабатывает выбор цели путаной"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return

    user_id = query.from_user.id
    prostitute_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("role") == "Путана" and 
            slot.get("status") == STATUS_ACTIVE):
            prostitute_slot = slot
            break

    if not prostitute_slot:
        await query.answer("У вас нет права блокировать", show_alert=True)
        return

    if target_index < 0 or target_index >= len(game_data["players_slots"]):
        await query.answer("Некорректная цель", show_alert=True)
        return

    target_slot = game_data["players_slots"][target_index]
    if target_slot.get("status") != STATUS_ACTIVE:
        await query.answer("Этот игрок уже не участвует в игре", show_alert=True)
        return

    target_slot["blocked_by_prostitute"] = True
    blocked_name = get_player_display_name(target_slot, context)
    
    # Помечаем что путана завершила действие
    prostitute_slot["prostitute_action_complete"] = True
    
    logger.info(f"Prostitute {user_id} blocked {blocked_name} in game {game_id}")

    await query.answer(f"✅ Вы заблокировали: {blocked_name}")
    
    try:
        await query.edit_message_text(
            f"🚫 **Цель заблокирована**\n\n"
            f"Заблокирован: **{blocked_name}**\n"
            f"Они не смогут выполнить ночное действие.",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating prostitute message: {e}")

    games[game_id] = game_data
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

async def handle_doctor_skip(query, context: CallbackContext, game_id: str):
    """Обрабатывает пропуск хода доктора"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return

    user_id = query.from_user.id
    doctor_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("role") == "Доктор" and 
            slot.get("status") == STATUS_ACTIVE):
            doctor_slot = slot
            break

    if not doctor_slot:
        await query.answer("У вас нет права пропускать ход доктора", show_alert=True)
        return

    # Помечаем что доктор завершил действие (пропустил ход)
    doctor_slot["doctor_action_complete"] = True
    
    logger.info(f"Doctor {user_id} skipped turn in game {game_id}")

    await query.answer("✅ Вы пропустили ход")
    
    try:
        await query.edit_message_text(
            f"🏥 **Ход пропущен**\n\n"
            f"Вы решили никого не лечить этой ночью.\n"
            f"Надеемся, это было мудрое решение...",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating doctor skip message: {e}")

    games[game_id] = game_data
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

async def handle_maniac_skip(query, context: CallbackContext, game_id: str):
    """Обрабатывает пропуск хода маньяка"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return

    user_id = query.from_user.id
    maniac_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("role") == "Маньяк" and 
            slot.get("status") == STATUS_ACTIVE):
            maniac_slot = slot
            break

    if not maniac_slot:
        await query.answer("У вас нет права пропускать ход маньяка", show_alert=True)
        return

    # Помечаем что маньяк завершил действие (пропустил ход)
    maniac_slot["maniac_action_complete"] = True
    
    logger.info(f"Maniac {user_id} skipped turn in game {game_id}")

    await query.answer("✅ Вы пропустили ход")
    
    try:
        await query.edit_message_text(
            f"💀 **Ход пропущен**\n\n"
            f"Жажда крови отступила... На этот раз.\n"
            f"Возможно, это было разумное решение.",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating maniac skip message: {e}")

    games[game_id] = game_data
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

async def handle_prostitute_skip(query, context: CallbackContext, game_id: str):
    """Обрабатывает пропуск хода путаны"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return

    user_id = query.from_user.id
    prostitute_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("role") == "Путана" and 
            slot.get("status") == STATUS_ACTIVE):
            prostitute_slot = slot
            break

    if not prostitute_slot:
        await query.answer("У вас нет права пропускать ход путаны", show_alert=True)
        return

    # Помечаем что путана завершила действие (пропустила ход)
    prostitute_slot["prostitute_action_complete"] = True
    
    logger.info(f"Prostitute {user_id} skipped turn in game {game_id}")

    await query.answer("✅ Вы пропустили ход")
    
    try:
        await query.edit_message_text(
            f"🚫 **Ход пропущен**\n\n"
            f"Вы решили никого не блокировать этой ночью.\n"
            f"Все игроки смогут действовать свободно.",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating prostitute skip message: {e}")

    games[game_id] = game_data
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

async def finalize_mafia_target(game_id: str, game_data: dict, context: CallbackContext):
    """Финализирует выбор цели мафии"""
    mafia_votes = game_data.get("mafia_votes", {})
    
    if not mafia_votes:
        logger.info(f"No mafia votes in game {game_id}, skipping mafia action")
        return

    # Подсчитываем голоса
    vote_counts = {}
    for voter_id, target_index in mafia_votes.items():
        vote_counts[target_index] = vote_counts.get(target_index, 0) + 1

    # Находим цель с наибольшим количеством голосов
    final_target_index = max(vote_counts.keys(), key=lambda x: vote_counts[x])
    final_target_slot = game_data["players_slots"][final_target_index]

    # Помечаем цель как атакованную мафией
    final_target_slot["targeted_by_mafia"] = True
    
    # Помечаем что мафия завершила действие в night_data
    if "night_data" not in game_data:
        game_data["night_data"] = {}
    if "actions_taken_by_role" not in game_data["night_data"]:
        game_data["night_data"]["actions_taken_by_role"] = {}
    
    game_data["night_data"]["actions_taken_by_role"]["Мафия"] = "completed"
    
    # Очищаем голоса мафии
    game_data["mafia_votes"] = {}
    games[game_id] = game_data

    logger.info(f"Mafia finalized target: {final_target_slot['fictional_name']} in game {game_id}")

    # Уведомляем всех членов мафии о финальном решении
    target_name = get_player_display_name(final_target_slot, context)
    for slot in game_data["players_slots"]:
        if (slot.get("status") == STATUS_ACTIVE and 
            slot.get("role") in ["Мафиози", "Дон Мафии"] and
            slot.get("user_id")):
            try:
                await context.bot.send_message(
                    slot["user_id"],
                    f"🎯 **Решение принято**\n\n"
                    f"Цель этой ночи: **{target_name}**\n\n"
                    f"🌙 Ожидайте завершения ночи...",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error notifying mafia member {slot['user_id']}: {e}")
    
    # Проверяем, завершены ли все ночные действия
    await check_all_night_actions_completed(game_id, context)

def get_roles_to_act_in_night(game_data: dict):
    """Возвращает список ролей, которые должны действовать в эту ночь"""
    roles_to_act = []
    for slot in game_data["players_slots"]:
        if slot.get("status") == STATUS_ACTIVE and slot.get("role") in NIGHT_ROLES:
            if slot["role"] not in roles_to_act:  # Избегаем дублирования
                roles_to_act.append(slot["role"])
    return roles_to_act

async def end_night_after_timeout(game_id: str, context: CallbackContext):
    """Завершает ночь после таймаута"""
    # Ждем 5 минут
    try:
        await asyncio.sleep(300)  # 5 минут = 300 секунд
    except Exception as e:
        logger.error(f"Error during sleep in end_night_after_timeout: {e}")
        return

    # Получаем актуальные данные игры
    game_data = games.get(game_id)
    if not game_data:
        logger.error(f"Game {game_id} not found when ending night")
        return

    # Проверяем, что игра все еще в состоянии ночи
    if game_data.get("state") != STATE_NIGHT:
        logger.info(f"Game {game_id} is no longer in night state, skipping timeout handling")
        return

    # Завершаем ночь и начинаем день
    await start_day_after_night(game_id, game_data, context)

async def start_day_after_night(game_id: str, game_data: dict, context: CallbackContext):
    """Завершает ночь и начинает день"""
    logger.info(f"Starting day after night for game {game_id}")

    # Обновляем состояние игры
    game_data["state"] = STATE_DAY
    game_data["current_day_number"] += 1

    # Обрабатываем результаты ночи
    eliminated_players = []
    saved_players = []

    for slot in game_data["players_slots"]:
        if slot.get("targeted_by_mafia") and not slot.get("saved_by_doctor"):
            slot["status"] = STATUS_ELIMINATED
            eliminated_players.append(get_player_display_name(slot, context))
        elif slot.get("targeted_by_maniac") and not slot.get("saved_by_doctor"):
            slot["status"] = STATUS_ELIMINATED
            eliminated_players.append(get_player_display_name(slot, context))
        elif slot.get("saved_by_doctor") and (slot.get("targeted_by_mafia") or slot.get("targeted_by_maniac")):
            saved_players.append(get_player_display_name(slot, context))
        
        # Очищаем ночные метки
        slot.pop("targeted_by_mafia", None)
        slot.pop("targeted_by_maniac", None)
        slot.pop("saved_by_doctor", None)
        slot.pop("blocked_by_prostitute", None)
        slot.pop("commissioner_action_complete", None)
        slot.pop("doctor_action_complete", None)
        slot.pop("maniac_action_complete", None)
        slot.pop("prostitute_action_complete", None)

    # Формируем ЕДИНОЕ сообщение о результатах ночи
    if eliminated_players and saved_players:
        result_message = (
            f"🌅 Наступает день {game_data['current_day_number']}.\n\n"
            f"💀 **Этой ночью погибли:** {', '.join(eliminated_players)}\n"
            f"🏥 **Доктор спас от смерти:** {', '.join(saved_players)}\n\n"
            f"⚰️ Город скорбит по утраченным, но благодарен спасителю..."
        )
    elif eliminated_players:
        death_count = len(eliminated_players)
        if death_count == 1:
            eliminated_name = eliminated_players[0]
            result_message = (
                f"🌅 Наступает день {game_data['current_day_number']}.\n\n"
                f"💀 **Этой ночью кто-то был жестоко убит...**\n\n"
                f"🔍 Жители города обнаружили тело **{eliminated_name}** на рассвете.\n\n"
                f"😢 Город скорбит о потере еще одного жителя."
            )
        else:
            eliminated_names = ", ".join(eliminated_players)
            result_message = (
                f"🌅 Наступает день {game_data['current_day_number']}.\n\n"
                f"💀 **Этой ночью {death_count} человека погибли...**\n\n"
                f"😱 Город обнаружил тела: **{eliminated_names}**\n\n"
                f"🚨 Город охватил ужас от множественных убийств!"
            )
    elif saved_players:
        result_message = (
            f"🌅 Наступает день {game_data['current_day_number']}.\n\n"
            f"🏥 **Доктор спас игрока от верной смерти!**\n\n"
            f"🛡️ Ангел-хранитель был рядом этой ночью..."
        )
    else:
        mysterious_messages = [
            "🌙 Ночь прошла в тревожном молчании...",
            "😴 Город спал беспокойным сном...", 
            "🌫️ В тумане ночи ничего не произошло...",
            "🦉 Только совы были свидетелями тайн этой ночи...",
            "⭐ Звезды хранят секреты прошедшей ночи..."
        ]
        result_message = f"🌅 Наступает день {game_data['current_day_number']}.\n\n" + random.choice(mysterious_messages)

    # Проверяем условия окончания игры
    if await check_game_end_conditions(game_id, game_data, context):
        return

    # Отправляем сообщение всем игрокам
    for slot in game_data["players_slots"]:
        if slot.get("user_id"):
            try:
                await context.bot.send_message(
                    slot["user_id"],
                    result_message
                )
            except Exception as e:
                logger.error(f"Error sending day start message to player {slot.get('user_id')}: {e}")

    # Отправляем убитым игрокам выбор раскрывать роль или нет
    if eliminated_players:
        import asyncio
        asyncio.create_task(send_role_reveal_choice_to_eliminated(game_id, eliminated_players, context))

    # Запускаем дневное голосование через 10 секунд (сократил для тестирования)
    import asyncio
    asyncio.create_task(start_day_voting_after_delay(game_id, context))

    games[game_id] = game_data

async def send_role_reveal_choice_to_eliminated(game_id: str, eliminated_players: list, context: CallbackContext):
    """Отправляет убитым игрокам выбор - раскрывать роль или нет"""
    for eliminated_name in eliminated_players:
        # Находим данные убитого игрока
        eliminated_slot = None
        for slot in games[game_id]["players_slots"]:
            if (slot.get("fictional_name") == eliminated_name and 
                slot.get("status") == STATUS_ELIMINATED and
                slot.get("user_id")):
                eliminated_slot = slot
                break
        
        if not eliminated_slot:
            continue
        
        user_id = eliminated_slot["user_id"]
        role = eliminated_slot["role"]
        
        # Создаем кнопки выбора
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Раскрыть роль", callback_data=f"reveal_role_{game_id}_{user_id}")],
            [InlineKeyboardButton("❌ Скрыть роль", callback_data=f"hide_role_{game_id}_{user_id}")]
        ])
        
        try:
            await context.bot.send_message(
                user_id,
                f"💀 **Вы были убиты этой ночью**\n\n"
                f"Ваша роль: **{role}**\n\n"
                f"📜 **Предсмертная записка:**\n"
                f"Вы можете оставить последнее сообщение для живых игроков. Просто напишите его боту.\n"
                f"После этого вы сможете только наблюдать за игрой.\n\n"
                f"🎭 **Раскрытие роли:**\n"
                f"Хотите ли вы раскрыть свою роль всем игрокам?\n"
                f"Это может помочь вашей команде или сбить с толку противников.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=keyboard
            )
            logger.info(f"Role reveal choice sent to eliminated player {user_id} ({eliminated_name})")
        except Exception as e:
            logger.error(f"Error sending role reveal choice to {user_id}: {e}")

async def handle_role_reveal_choice(query, context: CallbackContext, game_id: str, user_id: int, reveal: bool):
    """Обрабатывает выбор игрока - раскрывать роль или нет"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("❌ Игра не найдена", show_alert=True)
        return

    # Находим данные игрока
    player_slot = None
    for slot in game_data["players_slots"]:
        if (slot.get("user_id") == user_id and 
            slot.get("status") == STATUS_ELIMINATED):
            player_slot = slot
            break

    if not player_slot:
        await query.answer("❌ Игрок не найден", show_alert=True)
        return

    player_name = get_player_display_name(player_slot, context)
    player_role = player_slot["role"]

    if reveal:
        # Игрок решил раскрыть роль
        await query.edit_message_text(
            f"✅ **Роль раскрыта**\n\n"
            f"Вы раскрыли всем игрокам, что были **{player_role}**.",
            parse_mode=ParseMode.MARKDOWN
        )

        # Отправляем всем живым игрокам информацию о раскрытой роли
        reveal_message = (
            f"🎭 **Раскрытие роли**\n\n"
            f"💀 **{player_name}** раскрыл свою роль:\n"
            f"🎯 **{player_role}**\n\n"
            f"Эта информация может быть полезна для расследования!"
        )

        for slot in game_data["players_slots"]:
            if (slot.get("status") == STATUS_ACTIVE and 
                slot.get("user_id") and 
                slot.get("user_id") != user_id):
                try:
                    await context.bot.send_message(
                        slot["user_id"],
                        reveal_message,
                        parse_mode=ParseMode.MARKDOWN
                    )
                except Exception as e:
                    logger.error(f"Error sending role reveal to player {slot['user_id']}: {e}")

        logger.info(f"Player {user_id} ({player_name}) revealed role {player_role} in game {game_id}")

    else:
        # Игрок решил скрыть роль
        await query.edit_message_text(
            f"🤫 **Роль скрыта**\n\n"
            f"Вы решили не раскрывать свою роль (**{player_role}**) другим игрокам.\n"
            f"Это может создать интригу и помочь вашей команде.",
            parse_mode=ParseMode.MARKDOWN
        )

        logger.info(f"Player {user_id} ({player_name}) chose to hide role {player_role} in game {game_id}")

async def start_day_voting_after_delay(game_id: str, context: CallbackContext):
    """Запускает дневное голосование после небольшой задержки"""
    # Ждем на обсуждение (сократил для тестирования)
    try:
        await asyncio.sleep(10)  # 10 секунд для быстрого тестирования
    except Exception as e:
        logger.error(f"Error during sleep in start_day_voting_after_delay: {e}")
        return

    # Получаем актуальные данные игры
    game_data = games.get(game_id)
    if not game_data or game_data.get("state") != STATE_DAY:
        return

    await start_day_voting(game_id, game_data, context)

async def start_day_voting(game_id: str, game_data: dict, context: CallbackContext):
    """Запускает дневное голосование"""
    logger.info(f"Starting day voting for game {game_id}")

    # Инициализируем голосование в начале
    game_data["voting_active"] = True
    game_data["votes"] = {}
    games[game_id] = game_data

    # Получаем список активных игроков для голосования
    active_players = []
    players_with_voting_rights = []
    voting_rights = game_data.get("day_voting_rights", {})
    game_mode = game_data.get("game_mode", "human_host")
    
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("status") == STATUS_ACTIVE:
            player_key = f"player_{i}"
            # Проверяем права голосования только в режиме бот-ведущего
            if game_mode == "bot_host":
                has_voting_rights = voting_rights.get(player_key, True)  # По умолчанию есть права
            else:
                has_voting_rights = True  # В режиме человек-ведущего все имеют право голоса
            
            # Используем новую функцию для отображения имени
            display_name = get_player_display_name(slot, context)
            active_players.append((i, display_name))
            if has_voting_rights:
                players_with_voting_rights.append((i, display_name, slot.get("user_id")))

    if len(active_players) <= 2:
        # Слишком мало игроков для голосования
        await check_game_end_conditions(game_id, game_data, context)
        return

    # Создаем кнопки для голосования (изначально без голосов)
    keyboard = []
    for i, name in active_players:
        button_text = f"🗳️ {name}"
        keyboard.append([InlineKeyboardButton(button_text, callback_data=f"vote_{game_id}_{i}")])
    
    # Добавляем кнопку пропуска
    keyboard.append([InlineKeyboardButton("⭕ Пропустить голосование", callback_data=f"vote_skip_{game_id}")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Создаем детализированное сообщение с именами игроков
    player_list = "\n".join([f"• {name} - 0 голос(ов)" for i, name in active_players])
    
    voting_message = (
        f"🗳️ **Дневное голосование**\n\n"
        f"💬 **ЧАТ АКТИВЕН!** Можете обсуждать кандидатов.\n"
        f"Просто напишите сообщение боту - оно будет видно всем живым игрокам.\n\n"
        f"Время выбрать, кого изгнать из города!\n"
        f"У каждого есть 3 минуты на голосование.\n\n"
        f"👥 **Живые игроки:**\n{player_list}\n"
        f"⭕ Пропустить голосование - 0 голос(ов)\n\n"
        f"📊 **Проголосовало:** 0/{len(players_with_voting_rights)} игроков"
    )

    # Отправляем сообщение всем игрокам, но с разными правами голосования
    for slot in game_data["players_slots"]:
        if slot.get("status") == STATUS_ACTIVE and slot.get("user_id"):
            user_id = slot.get("user_id")
            # Найдем индекс игрока для проверки прав голосования
            slot_index = None
            for i, s in enumerate(game_data["players_slots"]):
                if s.get("user_id") == user_id:
                    slot_index = i
                    break
            
            player_key = f"player_{slot_index}" if slot_index is not None else None
            
            # Проверяем права голосования только в режиме бот-ведущего
            if game_mode == "bot_host" and player_key:
                has_voting_rights = voting_rights.get(player_key, True)
            else:
                has_voting_rights = True  # В режиме человек-ведущего все имеют право голоса
            
            try:
                if has_voting_rights:
                    # Игрок может голосовать
                    await context.bot.send_message(
                        user_id,
                        voting_message,
                        reply_markup=reply_markup,
                        parse_mode=ParseMode.MARKDOWN
                    )
                else:
                    # Игрок лишен права голоса (только в режиме бот-ведущего)
                    no_vote_message = (
                        f"🗳️ **Дневное голосование**\n\n"
                        f"Обсуждение окончено. Время выбрать, кого изгнать из города!\n\n"
                        f"❌ **У вас нет права голоса** из-за неправильного ответа на ночное задание.\n"
                        f"💡 В следующую ночь у вас будет возможность восстановить право голоса."
                    )
                    await context.bot.send_message(
                        user_id,
                        no_vote_message,
                        parse_mode=ParseMode.MARKDOWN
                    )
                    logger.info(f"Player {user_id} cannot vote due to math failure in bot-host mode")
                    
            except Exception as e:
                logger.error(f"Error sending voting message to player {user_id}: {e}")

    # Запускаем таймер на 3 минуты
    import asyncio
    asyncio.create_task(end_voting_after_timeout(game_id, context))

async def end_voting_after_timeout(game_id: str, context: CallbackContext):
    """Завершает голосование после таймаута"""
    # Ждем 3 минуты
    try:
        await asyncio.sleep(180)  # 3 минуты = 180 секунд
    except Exception as e:
        logger.error(f"Error during sleep in end_voting_after_timeout: {e}")
        return

    # Получаем актуальные данные игры
    game_data = games.get(game_id)
    if not game_data or not game_data.get("voting_active"):
        return

    await process_voting_results(game_id, game_data, context)

async def process_voting_results(game_id: str, game_data: dict, context: CallbackContext):
    """Обрабатывает результаты голосования"""
    logger.info(f"Processing voting results for game {game_id}")

    game_data["voting_active"] = False
    votes = game_data.get("votes", {})

    # Подсчитываем голоса и создаем детальную статистику
    vote_counts = {}
    voting_details = []
    
    for voter_id, voted_for in votes.items():
        if voted_for not in vote_counts:
            vote_counts[voted_for] = 0
        vote_counts[voted_for] += 1
        
        # Находим имя голосующего (voter_id это числовой ID пользователя)
        voter_name = "Неизвестный"
        for slot in game_data["players_slots"]:
            if slot.get("user_id") == voter_id:
                voter_name = get_player_display_name(slot, context)
                break
        
        # Находим имя того, за кого голосовали
        if voted_for == "skip":
            voted_for_name = "Пропуск голосования"
        else:
            voted_for_slot = game_data["players_slots"][voted_for]
            voted_for_name = get_player_display_name(voted_for_slot, context)
        
        voting_details.append(f"• {voter_name} → {voted_for_name}")

    # Создаем сводку голосования
    voting_summary = "\n📋 **Детали голосования:**\n" + "\n".join(voting_details) + "\n\n"

    # Находим игрока с наибольшим количеством голосов
    if not vote_counts:
        result_message = "📊 Никто не проголосовал. День заканчивается без изгнания."
    else:
        max_votes = max(vote_counts.values())
        candidates = [player for player, votes in vote_counts.items() if votes == max_votes]

        if len(candidates) > 1:
            if candidates[0] == "skip":
                result_message = f"📊 Голосование не выявило явного лидера. День заканчивается без изгнания.\n\n{voting_summary}"
            else:
                # Равенство голосов между игроками - запускаем дополнительное голосование
                await start_runoff_voting(game_id, game_data, candidates, voting_summary, context)
                return
        elif candidates[0] == "skip":
            result_message = f"📊 Голосование не выявило явного лидера. День заканчивается без изгнания.\n\n{voting_summary}"
        else:
            # Изгоняем игрока
            eliminated_player_index = candidates[0]
            eliminated_slot = game_data["players_slots"][eliminated_player_index]
            eliminated_slot["status"] = STATUS_ELIMINATED
            
            # Используем новую функцию для отображения имени
            eliminated_display_name = get_player_display_name(eliminated_slot, context)
            result_message = f"📊 По результатам голосования изгнан: {eliminated_display_name} (Роль: {eliminated_slot['role']})\n\n{voting_summary}"

    # Отправляем результаты всем игрокам
    for slot in game_data["players_slots"]:
        if slot.get("user_id"):
            try:
                await context.bot.send_message(
                    slot["user_id"],
                    result_message
                )
            except Exception as e:
                logger.error(f"Error sending voting results to player {slot.get('user_id')}: {e}")

    games[game_id] = game_data

    # Проверяем условия окончания игры
    if await check_game_end_conditions(game_id, game_data, context):
        return

    # Запускаем следующую ночь
    await start_next_night(game_id, game_data, context)

async def start_runoff_voting(game_id: str, game_data: dict, tied_candidates: list, voting_summary: str, context: CallbackContext):
    """Запускает дополнительное голосование между игроками с равным количеством голосов"""
    logger.info(f"Starting runoff voting in game {game_id} between candidates: {tied_candidates}")
    
    # Инициализируем дополнительное голосование
    game_data["voting_active"] = True
    game_data["votes"] = {}
    game_data["runoff_voting"] = True
    game_data["runoff_candidates"] = tied_candidates
    games[game_id] = game_data
    
    # Создаем список имен кандидатов
    candidate_names = []
    for candidate_index in tied_candidates:
        candidate_slot = game_data["players_slots"][candidate_index]
        candidate_names.append(get_player_display_name(candidate_slot, context))
    
    # Создаем клавиатуру для дополнительного голосования
    keyboard = []
    for candidate_index in tied_candidates:
        candidate_slot = game_data["players_slots"][candidate_index]
        candidate_name = get_player_display_name(candidate_slot, context)
        keyboard.append([InlineKeyboardButton(f"🗳️ {candidate_name}", callback_data=f"vote_{game_id}_{candidate_index}")])
    
    # Добавляем кнопку пропуска голосования
    keyboard.append([InlineKeyboardButton("⭕ Пропустить голосование", callback_data=f"vote_skip_{game_id}")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Формируем сообщение о дополнительном голосовании
    runoff_message = (
        f"⚖️ **ДОПОЛНИТЕЛЬНОЕ ГОЛОСОВАНИЕ**\n\n"
        f"📊 **Результат основного голосования:**\n{voting_summary}"
        f"🎯 **Равенство голосов между:**\n" + "\n".join([f"• {name}" for name in candidate_names]) + "\n\n"
        f"🗳️ **Выберите, кого изгнать из города:**\n"
        f"⏱️ У вас есть 2 минуты на принятие решения"
    )
    
    # Отправляем сообщение всем игрокам с правом голоса
    game_mode = game_data.get("game_mode", "human_host")
    voting_rights = game_data.get("day_voting_rights", {})
    
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("status") == STATUS_ACTIVE:
            player_key = f"player_{i}"
            # Проверяем права голосования только в режиме бот-ведущего
            if game_mode == "bot_host":
                has_voting_rights = voting_rights.get(player_key, True)
            else:
                has_voting_rights = True
            
            if has_voting_rights and slot.get("user_id"):
                try:
                    await context.bot.send_message(
                        slot["user_id"],
                        runoff_message,
                        reply_markup=reply_markup,
                        parse_mode=ParseMode.MARKDOWN
                    )
                except Exception as e:
                    logger.error(f"Error sending runoff voting message to player {slot['user_id']}: {e}")
    
    # Запускаем таймер на 2 минуты для дополнительного голосования
    import asyncio
    asyncio.create_task(end_voting_after_timeout(game_id, context))

async def start_next_night(game_id: str, game_data: dict, context: CallbackContext):
    """Начинает следующую ночь после завершения дня"""
    logger.info(f"Starting next night for game {game_id}")

    # Обновляем состояние игры
    game_data["state"] = STATE_NIGHT
    game_data["current_night_number"] = game_data.get("current_night_number", 0) + 1
    
    # Сбрасываем права голоса для следующего дня: ночные роли = автоматические права, мирные = нет
    game_data["day_voting_rights"] = {}
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("status") == STATUS_ACTIVE:
            player_key = f"player_{i}"
            # Роли с ночными действиями получают автоматические права голоса
            has_night_role = slot.get("role") in NIGHT_ROLES
            game_data["day_voting_rights"][player_key] = has_night_role
    
    # Сбрасываем математические состояния для всех игроков этой игры
    # ТОЛЬКО в режиме бот-ведущего
    if game_data.get("game_mode") == "bot_host":
        users_to_reset = []
        for user_id, math_state in user_math_state.items():
            if math_state.get("game_id") == game_id:
                users_to_reset.append(user_id)
        
        for user_id in users_to_reset:
            del user_math_state[user_id]
            logger.info(f"Reset math state for user {user_id} for new night in game {game_id} (bot-host mode)")
    
    games[game_id] = game_data

    # Отправляем сообщение о начале ночи
    await announce_night_start(game_id, game_data, context)

    # Запускаем ночные действия
    await start_night_actions(game_id, game_data, context)

async def check_game_end_conditions(game_id: str, game_data: dict, context: CallbackContext):
    """Проверяет условия окончания игры и объявляет победителя"""
    logger.info(f"Checking game end conditions for game {game_id}")

    # Подсчитываем количество активных игроков по ролям
    mafia_count = 0
    civilian_count = 0
    maniac_count = 0

    for slot in game_data["players_slots"]:
        if slot.get("status") == STATUS_ACTIVE:
            role = slot["role"]
            if role in ["Дон Мафии", "Мафиози"]:
                mafia_count += 1
            elif role == "Маньяк":
                maniac_count += 1
            else:
                civilian_count += 1

    # Проверяем условия победы
    game_over = False
    winner = None
    winner_message = ""

    if mafia_count == 0 and maniac_count == 0:
        # Мафия и Маньяк уничтожены - победа мирных
        game_over = True
        winner = "Мирные жители"
        winner_message = "🎉 Победа мирных жителей! Все злодеи были найдены и уничтожены."
    elif mafia_count >= civilian_count and maniac_count == 0:
        # Мафии столько же или больше, чем мирных, и Маньяк уничтожен - победа мафии
        game_over = True
        winner = "Мафия"
        winner_message = "🔪 Победа мафии! Они захватили город и теперь правят безраздельно."
    elif civilian_count == 0 and mafia_count == 0 and maniac_count == 1:
        # Все кроме Маньяка мертвы - победа Маньяка
        game_over = True
        winner = "Маньяк"
        winner_message = "🤯 Победа Маньяка! Город погрузился в хаос и ужас."

    if game_over:
        # Завершаем игру
        game_data["state"] = STATE_FINISHED
        game_data["winner"] = winner
        games[game_id] = game_data

        # Создаём подробную статистику ролей
        role_stats = []
        for slot in game_data["players_slots"]:
            if slot.get("user_id"):
                player_name = get_player_display_name(slot, context)
                role = slot.get("role", "Неизвестно")
                status = "🟢 Выжил" if slot.get("status") == STATUS_ACTIVE else "💀 Погиб"
                role_stats.append(f"• {player_name}: **{role}** - {status}")

        final_message = (
            f"🏁 **ИГРА ЗАВЕРШЕНА!**\n\n"
            f"{winner_message}\n\n"
            f"👥 **Статистика игроков:**\n" + "\n".join(role_stats) + "\n\n"
            f"🎭 Спасибо за игру! Хотите сыграть ещё раз?"
        )

        # Отправляем сообщение о завершении игры всем участникам
        for slot in game_data["players_slots"]:
            if slot.get("user_id"):
                try:
                    await context.bot.send_message(
                        slot["user_id"],
                        final_message,
                        parse_mode=ParseMode.MARKDOWN
                    )
                except Exception as e:
                    logger.error(f"Error sending game end message to player {slot.get('user_id')}: {e}")

        logger.info(f"Game {game_id} ended with winner: {winner}")
        return True

    return False

async def create_game_from_pending_settings(query_or_update, context: CallbackContext, settings: dict):
    """Создает игру из настроек"""
    try:
        logger.info(f"[DEBUG] Начало создания игры с настройками: {settings}")

        if hasattr(query_or_update, 'from_user'):
            user = query_or_update.from_user
        else:
            user = query_or_update.message.from_user
        
        logger.info(f"[DEBUG] Пользователь {user.id} ({user.full_name}) создает игру")

        # Получаем параметры из настроек
        num_players = settings.get('num_players', 6)
        game_mode = settings.get('game_mode', 'human_host')
        version = settings.get('version', 'paid')
        role_setup_method = settings.get('role_setup_method', 'auto')

        logger.info(f"[DEBUG] Параметры игры: {num_players} игроков, режим: {game_mode}, версия: {version}")

        # Проверяем корректность параметров
        if not (4 <= num_players <= 20):
            error_msg = f"Некорректное количество игроков: {num_players}"
            logger.error(error_msg)
            if hasattr(query_or_update, 'edit_message_text'):
                await query_or_update.edit_message_text("❌ Ошибка: Количество игроков должно быть от 4 до 20")
            return None

        logger.info("[DEBUG] Все проверки пройдены успешно")

        # Создаем роли
        if version == 'free':
            assigned_roles_list = await assign_roles_free(num_players)
        else:
            assigned_roles_list = await assign_roles_standard(num_players)

        if not assigned_roles_list:
            if hasattr(query_or_update, 'edit_message_text'):
                await query_or_update.edit_message_text("❌ Ошибка создания ролей")
            return None

        # Генерируем ID игры
        game_id = "mafia_" + generate_id(6)

        # Подготавливаем имена и дела
        available_fictional_names = fictional_names_list.copy()
        random.shuffle(available_fictional_names)
        available_personal_cases = personal_cases.copy()
        random.shuffle(available_personal_cases)

        # Создаем слоты для игроков
        players_slots = []
        for i in range(num_players):
            player_role = assigned_roles_list[i]
            player_name = available_fictional_names[i % len(available_fictional_names)]
            player_case = available_personal_cases[i % len(available_personal_cases)]
            
            slot = {
                "role": player_role,
                "description": player_case,
                "fictional_name": player_name,
                "user_id": None,
                "_user_first_name": None,
                "status": STATUS_ACTIVE,
                "original_slot_index": i
            }
            players_slots.append(slot)

        # Создаем объект игры
        game_data = {
            'host_id': user.id,
            'host_name': user.full_name or "Аноним",
            'state': STATE_ROLES_DISTRIBUTED,
            'players_slots': players_slots,
            'num_players': num_players,
            'game_mode': game_mode,
            'game_version': version,
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'current_night_number': 0,
            'current_day_number': 0
        }

        # Сохраняем игру
        games[game_id] = game_data

        # Получаем имя бота для ссылки
        try:
            bot_info = await context.bot.get_me()
            bot_username = bot_info.username
            logger.info(f"[DEBUG] Получено имя бота из API: @{bot_username}")
        except Exception as e:
            logger.error(f"[ERROR] Ошибка при получении информации о боте: {e}")
            bot_username = "Mafia_IRL_Bot"
            logger.info(f"[DEBUG] Используется резервное имя бота: @{bot_username}")

        # Формируем ссылку для присоединения к обычной игре
        join_game_link = f"https://t.me/{bot_username}?start=join_{game_id}"
        
        logger.info(f"[DEBUG] Используемая ссылка в сообщении: {join_game_link}")
        logger.info(f"[DEBUG] Используемое имя бота в тексте: @{bot_username}")

        # Определяем описание типа игры
        if version == 'free':
            game_type_description = "🆓 Бесплатная игра"
        else:
            if game_mode == 'human_host':
                game_type_description = "💎 Платная игра (Ведущий - Я)"
            else:
                game_type_description = "🤖💎 Платная игра (Ведущий - Бот)"

        # Формируем сообщение для ведущего
        host_display_line = f"Ведущий: {user.first_name}\n"
        if game_mode == 'bot_host':
            host_display_line = f"Создатель игры: {user.first_name}\n"

        message_text = (
            f"🎲 Новая игра в Мафию создана!\n\n"
            f"🆔 ID игры: {game_id}\n"
            f"🎮 Тип игры: {game_type_description}\n"
            f"{host_display_line}"
            f"👥 Количество игроков: {num_players}\n\n"
            f"🔗 ССЫЛКА ДЛЯ ИГРОКОВ:\n"
            f"{join_game_link}\n\n"
            f"📤 Разошлите эту ссылку всем участникам.\n"
            f"🎭 Игроки будут получать роли автоматически."
        )

        # Создаем кнопки
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🎮 Присоединиться", callback_data=f"join_game_{game_id}")],
            [InlineKeyboardButton("📤 Поделиться игрой", callback_data=f"copy_link_{game_id}")]
        ])

        if hasattr(query_or_update, 'edit_message_text'):
            await query_or_update.edit_message_text(
                message_text,
                parse_mode=None,
                reply_markup=keyboard
            )
        else:
            await query_or_update.message.reply_text(
                message_text, 
                parse_mode=None,
                reply_markup=keyboard
            )

        # Отправляем детали ролей ведущему (если не бот-ведущий)
        if game_mode != 'bot_host':
            roles_details = ["🕵️ **Подготовленные роли и персонажи:**"]
            for i, slot in enumerate(players_slots):
                roles_details.append(
                    f"**Слот {i+1}:** {slot['fictional_name']} - {slot['role']} *(Ожидает игрока)*"
                )
            
            await context.bot.send_message(
                user.id,
                "\n".join(roles_details),
                parse_mode=None
            )

        logger.info(f"[DEBUG] Игра успешно создана с ID: {game_id}")
        
        # В режиме human_host сразу отправляем панель управления
        if game_mode == 'human_host':
            # Отправляем панель управления
            await context.bot.send_message(
                chat_id=user.id,
                text=f"🎮 Панель управления игрой {game_id}\n\nВы можете начать управление сразу или дождаться присоединения игроков.",
                reply_markup=get_main_control_keyboard(game_id),
                parse_mode=None
            )
        else:
            return game_id

    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        error_msg = f"Ошибка при создании игры: {str(e)}\n\nДетали:\n{error_details}"
        logger.error(f"[ERROR] {error_msg}")
        if hasattr(query_or_update, 'edit_message_text'):
            try:
                await query_or_update.edit_message_text(
                    f"❌ **Произошла ошибка при создании игры.**\n\n"
                    f"**Тип ошибки:** {type(e).__name__}\n"
                    f"**Сообщение:** {str(e)}",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as send_error:
                logger.error(f"Не удалось отправить сообщение об ошибке: {send_error}")
        return None

async def create_timer_game_from_pending_settings(query_or_update, context: CallbackContext, settings: dict):
    """Создает игру с режимом времени (3 минуты)"""
    try:
        logger.info(f"[DEBUG] Создание игры с таймером: {settings}")

        if hasattr(query_or_update, 'from_user'):
            user = query_or_update.from_user
        else:
            user = query_or_update.message.from_user
        
        # Получаем параметры из настроек
        max_players = settings.get('num_players', 6)
        version = settings.get('version', 'paid')
        
        # Генерируем ID игры
        game_id = "timer_" + generate_id(6)

        # Подготавливаем имена и дела
        available_fictional_names = fictional_names_list.copy()
        random.shuffle(available_fictional_names)
        available_personal_cases = personal_cases.copy()
        random.shuffle(available_personal_cases)

        # Создаем слоты для максимального количества игроков (все пустые пока)
        # Роли будут распределены ТОЛЬКО после истечения 3 минут
        players_slots = []
        for i in range(max_players):
            player_name = available_fictional_names[i % len(available_fictional_names)]
            player_case = available_personal_cases[i % len(available_personal_cases)]
            
            slot = {
                "role": None,  # Роль будет назначена позже
                "fictional_name": player_name,
                "description": player_case,
                "user_id": None,  # Пока не заполнено
                "_user_first_name": None,
                "real_name": None,
                "status": STATUS_ACTIVE,
                "player_number_for_host": i + 1
            }
            players_slots.append(slot)

        # Создаем объект игры
        game_data = {
            'host_id': user.id,
            'host_name': user.full_name or "Аноним",
            'state': STATE_TIMER_WAITING,  # Новое состояние для режима времени
            'players_slots': players_slots,
            'max_players': max_players,
            'current_players': 0,
            'game_mode': 'bot_host_timer',
            'game_version': version,
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'timer_started_at': datetime.now(),
            'current_night_number': 0,
            'current_day_number': 0
        }

        # Сохраняем игру
        games[game_id] = game_data

        # Получаем имя бота для ссылки
        try:
            bot_info = await context.bot.get_me()
            bot_username = bot_info.username
            logger.info(f"[DEBUG] Получено имя бота для таймер-игры: @{bot_username}")
        except Exception as e:
            logger.error(f"[ERROR] Ошибка при получении информации о боте для таймер-игры: {e}")
            bot_username = "Mafia_IRL_Bot"

        join_game_link = f"https://t.me/{bot_username}?start=join_timer_{game_id.replace('timer_', '')}"
        
        logger.info(f"[DEBUG] Используемая ссылка в сообщении: {join_game_link}")
        logger.info(f"[DEBUG] Используемое имя бота в тексте: @{bot_username}")

        # Определяем описание типа игры
        if version == 'free':
            game_type_description = "🆓 Бесплатная игра"
        else:
            game_type_description = "💎 Премиум игра"

        # Формируем сообщение для создателя (убираем markdown чтобы избежать ошибок)
        message_text = (
            f"⏱️ Игра с таймером создана!\n\n"
            f"🆔 ID игры: {game_id}\n"
            f"🎮 Тип игры: {game_type_description} (Режим времени)\n"
            f"Создатель: {user.first_name}\n"
            f"👥 Максимум игроков: {max_players}\n\n"
            f"⏰ Режим времени: Через 3 минуты игра начнется автоматически с теми, кто успел присоединиться!\n"
            f"Минимум для старта: 4 игрока\n\n"
            f"🔗 ССЫЛКА ДЛЯ ИГРОКОВ:\n"
            f"{join_game_link}\n\n"
            f"📤 Разошлите эту ссылку друзьям. Торопитесь - время пошло!"
        )

        # Создаем кнопки управления
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("📋 Поделиться игрой", callback_data=f"copy_link_{game_id}")],
            [InlineKeyboardButton("⏰ Статус таймера", callback_data=f"timer_status_{game_id}")]
        ])

        if hasattr(query_or_update, 'edit_message_text'):
            await query_or_update.edit_message_text(
                message_text,
                reply_markup=keyboard,
                parse_mode=None
            )
        else:
            await context.bot.send_message(
                chat_id=user.id,
                text=message_text,
                reply_markup=keyboard,
                parse_mode=None
            )

        # НЕ запускаем таймер сразу - он запустится при присоединении первого игрока
        # Помечаем что таймер еще не запущен
        game_data['timer_started'] = False

        logger.info(f"[DEBUG] Игра с таймером успешно создана: {game_id}")
        return game_id

    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        error_msg = f"Ошибка при создании игры с таймером: {str(e)}\n\nДетали:\n{error_details}"
        logger.error(f"[ERROR] {error_msg}")
        if hasattr(query_or_update, 'edit_message_text'):
            try:
                await query_or_update.edit_message_text(
                    f"❌ **Произошла ошибка при создании игры.**\n\n"
                    f"**Тип ошибки:** {type(e).__name__}\n"
                    f"**Сообщение:** {str(e)}",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as send_error:
                logger.error(f"Не удалось отправить сообщение об ошибке: {send_error}")
        return None

async def auto_update_timer_status(game_id: str, context: CallbackContext):
    """Автоматически обновляет статус таймера каждые 10 секунд для всех игроков"""
    import asyncio
    from datetime import datetime, timedelta
    
    while True:
        await asyncio.sleep(10)  # Обновляем каждые 10 секунд
        
        game_data = games.get(game_id)
        if not game_data or game_data.get('state') != STATE_TIMER_WAITING:
            break  # Игра завершена или уже запущена
        
        # Считаем оставшееся время
        timer_started = game_data.get('timer_started_at')
        if isinstance(timer_started, str):
            try:
                timer_started = datetime.strptime(timer_started, "%Y-%m-%d %H:%M:%S")
            except:
                timer_started = datetime.now() - timedelta(minutes=1)
        
        elapsed_time = datetime.now() - timer_started
        remaining_time = timedelta(minutes=3) - elapsed_time
        
        if remaining_time.total_seconds() <= 0:
            break  # Время истекло
        
        remaining_minutes = int(remaining_time.total_seconds() // 60)
        remaining_seconds = int(remaining_time.total_seconds() % 60)
        time_text = f"{remaining_minutes}:{remaining_seconds:02d}"
        
        current_players = sum(1 for slot in game_data['players_slots'] if slot.get('user_id'))
        max_players = game_data.get('max_players', 20)
        
        # Обновляем сообщения игрокам (редактируем вместо спама)
        update_message = (
            f"⏰ Игра начнется через: {time_text}\n\n"
            f"👥 Игроков: {current_players}/{max_players}\n"
            f"🎯 Минимум: 4 игрока\n\n"
            f"📈 Автостарт по истечении времени!"
        )
        
        # Сохраняем ID сообщений для редактирования
        if not hasattr(auto_update_timer_status, 'message_ids'):
            auto_update_timer_status.message_ids = {}
        
        for slot in game_data['players_slots']:
            if slot.get('user_id'):
                user_id = slot['user_id']
                try:
                    if user_id in auto_update_timer_status.message_ids:
                        # Редактируем существующее сообщение
                        await context.bot.edit_message_text(
                            chat_id=user_id,
                            message_id=auto_update_timer_status.message_ids[user_id],
                            text=update_message
                        )
                    else:
                        # Отправляем новое сообщение
                        msg = await context.bot.send_message(user_id, update_message)
                        auto_update_timer_status.message_ids[user_id] = msg.message_id
                except Exception:
                    # Если редактирование не удалось, отправляем новое
                    try:
                        msg = await context.bot.send_message(user_id, update_message)
                        auto_update_timer_status.message_ids[user_id] = msg.message_id
                    except:
                        pass

async def start_timer_game_after_delay(game_id: str, context: CallbackContext):
    """Запускает игру через 3 минуты или когда все места заняты"""
    # Ждем 3 минуты (180 секунд)
    import asyncio
    
    # Уведомления через каждую минуту
    for remaining_minutes in [2, 1]:
        await asyncio.sleep(60)  # Ждем минуту
        
        game_data = games.get(game_id)
        if not game_data or game_data.get('state') != STATE_TIMER_WAITING:
            return  # Игра была удалена или уже запущена
        
        current_players = sum(1 for slot in game_data['players_slots'] if slot.get('user_id'))
        
        # Отправляем уведомление всем участникам
        for slot in game_data['players_slots']:
            if slot.get('user_id'):
                try:
                    await context.bot.send_message(
                        slot['user_id'],
                        f"⏰ До старта игры осталось {remaining_minutes} {get_minute_word(remaining_minutes)}!\n"
                        f"👥 Присоединилось игроков: {current_players}/{game_data['max_players']}"
                    )
                except:
                    pass
    
    # Последняя минута - ждем и запускаем
    await asyncio.sleep(60)
    
    game_data = games.get(game_id)
    if not game_data or game_data.get('state') != STATE_TIMER_WAITING:
        return  # Игра была удалена или уже запущена
    
    current_players = sum(1 for slot in game_data['players_slots'] if slot.get('user_id'))
    
    if current_players < 4:
        # Недостаточно игроков - отменяем игру и уведомляем создателя
        try:
            await context.bot.send_message(
                game_data['host_id'],
                f"❌ **Игра {game_id} отменена**\n\n"
                f"За 3 минуты присоединилось только {current_players} игроков из необходимых минимум 4."
            )
        except:
            pass
        
        # Удаляем игру
        if game_id in games:
            del games[game_id]
        return
    
    # Достаточно игроков - распределяем роли и запускаем игру
    filled_slots = [slot for slot in game_data['players_slots'] if slot.get('user_id')]
    actual_player_count = len(filled_slots)
    
    # ВАЖНО: Теперь распределяем роли на основе РЕАЛЬНОГО количества игроков
    if game_data.get('version') == 'free':
        roles_to_assign = await assign_roles_free(actual_player_count)
    else:
        roles_to_assign = await assign_roles_standard(actual_player_count)
    
    # Перемешиваем роли
    import random
    random.shuffle(roles_to_assign)
    
    # Назначаем роли только заполненным слотам
    for i, slot in enumerate(filled_slots):
        if i < len(roles_to_assign):
            slot['role'] = roles_to_assign[i]
    
    # Обрезаем слоты до количества присоединившихся игроков
    game_data['players_slots'] = filled_slots
    game_data['num_players'] = actual_player_count
    game_data['state'] = 'ready'
    
    # Уведомляем всех об автоматическом старте с ПОЛНОЙ информацией о ролях
    for slot in filled_slots:
        # Проверяем союзников мафии
        mafia_allies_text = ""
        if slot['role'] in ["Мафиози", "Дон Мафии"]:
            allies = []
            for other_slot in filled_slots:
                if (other_slot.get('user_id') and 
                    other_slot.get('user_id') != slot.get('user_id') and
                    other_slot.get('role') in ["Мафиози", "Дон Мафии"]):
                    allies.append(f"{other_slot['fictional_name']} ({other_slot.get('real_name', 'Неизвестно')})")
            
            if allies:
                mafia_allies_text = f"\n🤝 Ваши союзники в мафии:\n• " + "\n• ".join(allies) + "\n"
            else:
                mafia_allies_text = "\n👤 Вы единственная мафия в этой игре.\n"
        
        try:
            # ПОЛНОЕ сообщение с именем, ролью, личным делом и инструкциями
            full_message = (
                f"🎉 Время вышло! Игра начинается!\n\n"
                f"👥 Участников: {actual_player_count}\n\n"
                f"🎭 Ваше имя: {slot['fictional_name']}\n"
                f"📋 Ваша история: {slot['description']}\n\n"
                f"{get_role_description(slot['role'])}"
                f"{mafia_allies_text}\n"
                f"💬 Система чата: После начала игры вы сможете общаться с другими игроками, просто написав сообщение боту.\n\n"
                f"🤖 Бот-ведущий автоматически запускает игру..."
            )
            
            await context.bot.send_message(
                slot['user_id'],
                full_message
            )
        except Exception as e:
            logger.error(f"Error sending full game start info to player {slot['user_id']}: {e}")
    
    # Запускаем игру через бот-ведущего
    await start_bot_hosted_game(game_id, game_data, context)

async def button_callback_handler(update: Update, context: CallbackContext):
    """Обработчик нажатий на кнопки"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    user = query.from_user
    
    logger.info(f"Обработка callback данных: {data}")
    logger.info(f"Пользователь: {user.id} ({user.full_name})")
    
    if data == "create_game":
        # Показываем выбор типа игры
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🎮 Бесплатный режим", callback_data="game_type_free")],
            [InlineKeyboardButton("💎 Премиум режим", callback_data="game_type_premium")],
            [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
        ])
        await query.edit_message_text(
            "🎮 **Создание новой игры**\n\nВыберите тип игры:",
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN
        )
    
    elif data in ["game_type_free", "game_type_premium"]:
        is_premium = (data == "game_type_premium")
        logger.info(f"[DEBUG] Выбран тип игры: {'premium' if is_premium else 'free'}")
        
        # Сохраняем тип игры в состоянии пользователя
        context.user_data['game_type'] = 'premium' if is_premium else 'free'
        logger.info(f"[DEBUG] Состояние пользователя обновлено")
        
        # Показываем выбор режима набора игроков
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("👥 Точное количество игроков", 
                                callback_data=f"player_mode_exact_{'premium' if is_premium else 'free'}")],
            [InlineKeyboardButton("⏱️ Режим времени (3 минуты)", 
                                callback_data=f"player_mode_timer_{'premium' if is_premium else 'free'}")],
            [InlineKeyboardButton("🔙 Назад", callback_data="create_game")]
        ])
        
        game_type_name = "Премиум" if is_premium else "Бесплатный"
        max_players = "20" if is_premium else "8"
        
        await query.edit_message_text(
            f"🎮 **{game_type_name} режим**\n\n"
            f"Выберите режим набора игроков:\n\n"
            f"👥 **Точное количество** - укажите конкретное число игроков (4-{max_players})\n\n"
            f"⏱️ **Режим времени** - игра начнется через 3 минуты с теми, кто успеет присоединиться (минимум 4 игрока)",
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN
        )
    
    elif data.startswith("player_mode_"):
        # Обработка выбора режима набора игроков
        parts = data.split('_')
        mode = parts[2]  # exact или timer
        game_type = parts[3]  # premium или free
        is_premium = (game_type == "premium")
        
        logger.info(f"[DEBUG] Выбран режим: {mode}, тип игры: {game_type}")
        
        if mode == "timer":
            # Режим времени - создаем игру с максимальным количеством слотов
            max_players = 20 if is_premium else 8
            
            # Показываем выбор типа ведущего для режима времени
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("👤 Я ведущий", 
                                    callback_data=f"timer_host_human_{game_type}")],
                [InlineKeyboardButton("🤖 Бот-ведущий", 
                                    callback_data=f"timer_host_bot_{game_type}")],
                [InlineKeyboardButton("🔙 Назад", callback_data=f"game_type_{game_type}")]
            ])
            
            await query.edit_message_text(
                f"⏱️ **Режим времени (3 минуты)**\n\n"
                f"Максимум игроков: {max_players}\n"
                f"Минимум для старта: 4 игрока\n\n"
                f"Выберите тип ведущего:",
                reply_markup=keyboard,
                parse_mode=ParseMode.MARKDOWN
            )
        
        elif mode == "exact":
            # Точное количество - показываем ввод числа
            context.user_data['game_setup_state'] = 'waiting_player_count'
            context.user_data['game_type'] = game_type
            
            if is_premium:
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Назад", callback_data=f"game_type_{game_type}")]
                ])
                await query.edit_message_text(
                    "💎 **Премиум режим - Точное количество**\n\n"
                    "📝 **Напишите количество игроков (4-20):**\n\n"
                    "Просто отправьте сообщение с цифрой, например: `6`\n\n"
                    "💡 Доступны все роли и функции:\n"
                    "• Ведущий - вы или бот\n"
                    "• Все роли (Дон Мафии, Маньяк, Путана и др.)\n"
                    "• Ручная настройка ролей",
                    reply_markup=keyboard,
                    parse_mode=ParseMode.MARKDOWN
                )
            else:
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Назад", callback_data=f"game_type_{game_type}")]
                ])
                await query.edit_message_text(
                    "🎮 **Бесплатный режим - Точное количество**\n\n"
                    "📝 **Напишите количество игроков (4-8):**\n\n"
                    "Просто отправьте сообщение с цифрой, например: `5`\n\n"
                    "🎯 Особенности бесплатного режима:\n"
                    "• Базовые роли (Мафиози, Комиссар, Доктор, Мирный житель)\n"
                    "• Автоматическое распределение ролей",
                    reply_markup=keyboard,
                    parse_mode=ParseMode.MARKDOWN
                )
    
    elif data.startswith("timer_host_"):
        # Обработка выбора ведущего для режима времени
        parts = data.split('_')
        host_type = parts[2]  # human или bot
        game_type = parts[3]  # premium или free
        is_premium = (game_type == "premium")
        
        max_players = 20 if is_premium else 8
        
        # Создаем настройки для игры с таймером
        context.user_data['new_game_pending_settings'] = {
            'num_players': max_players,
            'game_mode': f'{host_type}_host_timer',
            'host_id': query.from_user.id,
            'host_name': query.from_user.full_name or 'Аноним',
            'version': 'premium' if is_premium else 'free',
            'role_setup_method': 'auto'
        }
        
        await query.answer("Создаю игру с таймером...")
        await create_timer_game_from_pending_settings(query, context, context.user_data['new_game_pending_settings'])
    
    elif data.startswith("game_mode_"):
        logger.info(f"[DEBUG] Обработка выбора режима игры: {data}")
        
        # Разбираем данные
        parts = data.split('_')
        num_players = int(parts[2])
        mode = parts[3]  # human, bot
        is_free = len(parts) > 4 and parts[4] == 'free'
        
        logger.info(f"[DEBUG] Обработанные параметры: {num_players} игроков, режим: {mode}, бесплатно: {is_free}")

        # Сохраняем параметры для создания игры
        context.user_data['new_game_pending_settings'] = {
            'num_players': num_players,
            'game_mode': f'{mode}_host',
            'host_id': query.from_user.id,
            'host_name': query.from_user.full_name or 'Аноним',
            'version': 'free' if is_free else 'paid'
        }

        # Показываем выбор способа распределения ролей
        callback_prefix = "ng_bh" if mode == 'bot' else "ng"
        
        # Для бесплатного режима только автоматическое распределение
        if is_free:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("⚙️ Автоматическое распределение", 
                                    callback_data=f"{callback_prefix}_roles_auto")]
            ])
            
            mode_text = 'Ведущий - Бот' if mode == 'bot' else 'Ведущий - Я'
            message_text = (
                f"🎮 **Настройка новой игры (Бесплатный режим)**\n\n"
                f"**Количество игроков:** {num_players}\n"
                f"**Режим:** {mode_text}\n"
                f"**Роли:** Мафиози, Комиссар, Доктор, Мирный житель\n\n"
                f"В бесплатном режиме доступно только автоматическое распределение ролей:"
            )
        else:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("⚙️ Автоматическое распределение", 
                                    callback_data=f"{callback_prefix}_roles_auto")],
                [InlineKeyboardButton("✍️ Ручная настройка ролей", 
                                    callback_data=f"{callback_prefix}_roles_manual")]
            ])
            
            mode_text = 'Ведущий - Бот' if mode == 'bot' else 'Ведущий - Я'
            message_text = (
                f"🎮 **Настройка новой игры (Премиум режим)**\n\n"
                f"**Количество игроков:** {num_players}\n"
                f"**Режим:** {mode_text}\n\n"
                f"Теперь выберите способ распределения ролей:"
            )
        
        await query.edit_message_text(
            message_text,
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN
        )
    
    elif data.startswith("ng_"):
        # Обработка выбора настройки ролей
        parts = data.split('_')
        pending_settings = context.user_data.get('new_game_pending_settings')
        if not pending_settings:
            await query.answer("Ошибка: настройки игры не найдены.", show_alert=True)
            return
        
        # Определяем действие
        if len(parts) == 3 and parts[1] == "roles" and parts[2] == "auto":
            # ng_roles_auto
            action = "roles_auto"
        elif len(parts) == 4 and parts[1] == "bh" and parts[2] == "roles" and parts[3] == "auto":
            # ng_bh_roles_auto
            action = "bh_roles_auto"
        elif len(parts) == 3 and parts[1] == "roles" and parts[2] == "manual":
            # ng_roles_manual
            action = "roles_manual"
        elif len(parts) == 4 and parts[1] == "bh" and parts[2] == "roles" and parts[3] == "manual":
            # ng_bh_roles_manual
            action = "bh_roles_manual"
        else:
            await query.answer("Неизвестное действие для новой игры.", show_alert=True)
            return
        
        if action == "roles_auto":
            pending_settings['role_setup_method'] = 'auto'
            await query.answer("Выбрано автоматическое распределение ролей.")
            await create_game_from_pending_settings(query, context, pending_settings)
            return
        
        elif action == "bh_roles_auto":
            if pending_settings.get('game_mode') != 'bot_host':
                await query.answer("Ошибка: неверный контекст для автоматического распределения (Бот-Ведущий).", show_alert=True)
                return
            pending_settings['role_setup_method'] = 'auto'
            await query.answer("Выбрано автоматическое распределение ролей для Бота-Ведущего.")
            await create_game_from_pending_settings(query, context, pending_settings)
            return
        
        elif action in ["roles_manual", "bh_roles_manual"]:
            # Переход к ручной настройке ролей
            await query.answer("Переход к ручной настройке ролей...")
            
            # Сохраняем настройки для ручной конфигурации
            context.user_data['pending_game_setup'] = {
                'host_id': pending_settings['host_id'],
                'total_players': pending_settings['num_players'],
                'current_roles': {role: 0 for role in ALL_CONFIGURABLE_ROLES},
                'game_version': pending_settings['version'],
                'game_mode': pending_settings['game_mode']
            }
            
            # Удаляем временные настройки
            if 'new_game_pending_settings' in context.user_data:
                del context.user_data['new_game_pending_settings']
            
            await send_role_config_message(query, context, is_edit=True)
            return
    
    elif data.startswith("join_game_"):
        game_id = data[10:]  # Убираем "join_game_"
        
        # Имитируем объект update для функции join_game
        class FakeUpdate:
            def __init__(self, user):
                self.effective_user = user
                self.message = query.message
        
        fake_update = FakeUpdate(user)
        await join_game(fake_update, context, game_id)
    
    elif data.startswith("copy_link_"):
        game_id = data[10:]  # Убираем "copy_link_"
        
        if game_id not in games:
            await query.answer("Игра не найдена", show_alert=True)
            return
            
        game = games[game_id]
        
        try:
            bot_info = await context.bot.get_me()
            original_bot_username = bot_info.username
            # Создаем новую переменную для гарантии
            bot_username = str(original_bot_username)
            logger.info(f"[DEBUG] copy_link: bot_info получен успешно")
            logger.info(f"[DEBUG] copy_link: original username = '{original_bot_username}'")
            logger.info(f"[DEBUG] copy_link: processed username = '{bot_username}'")
            logger.info(f"[DEBUG] copy_link: username equals Mafia_IRL_Bot: {bot_username == 'Mafia_IRL_Bot'}")
        except Exception as e:
            logger.error(f"[ERROR] Ошибка при получении ссылки в copy_link: {e}")
            # Используем правильное имя бота в качестве резерва
            bot_username = "Mafia_IRL_Bot"
            logger.info(f"[DEBUG] copy_link: Используется резервное имя бота: @{bot_username}")
            await query.answer("⚠️ Использована резервная ссылка", show_alert=False)
        
        # Явно создаем новые переменные для исключения проблем
        safe_bot_username = str(bot_username)
        telegram_link = f"https://t.me/{safe_bot_username}?start=join_{game_id}"
        
        logger.info(f"[DEBUG] copy_link: safe_bot_username = '{safe_bot_username}'")
        logger.info(f"[DEBUG] copy_link: Сформированная ссылка: {telegram_link}")
        
        # Определяем тип игры для красивого описания
        version = game.get('game_version', 'paid')
        game_mode = game.get('game_mode', 'human_host')
        host_name = game.get('host_name', 'Аноним')
        
        # Правильно определяем количество игроков
        if game.get('state') == STATE_TIMER_WAITING:
            # Для таймер-игр показываем текущее/максимальное
            current_players = sum(1 for slot in game['players_slots'] if slot.get('user_id'))
            max_players = game.get('max_players', 20)
            players_text = f"{current_players}/{max_players}"
        else:
            # Для обычных игр показываем максимальное количество
            num_players = game.get('num_players', 6)
            players_text = str(num_players)
        
        if version == 'free':
            game_type_emoji = "🆓"
            game_type_text = "Бесплатная игра"
            if game_mode in ['bot_host', 'bot_host_timer']:
                host_text = "🤖 Ведущий - Бот"
            else:
                host_text = "👤 Ведущий - Я"
        else:
            game_type_emoji = "💎"
            game_type_text = "Премиум игра"
            if game_mode in ['bot_host', 'bot_host_timer']:
                host_text = "🤖 Ведущий - Бот"
            else:
                host_text = "👤 Ведущий - Я"
        
        # Красивое сообщение для пересылки (упрощенное)
        share_message = (
            f"{game_type_emoji} {game_type_text} в Мафию!\n\n"
            f"🎭 Присоединяйтесь к игре!\n"
            f"👥 Игроков: {players_text}\n"
            f"👑 Создатель: {host_name}\n"
            f"{host_text}\n"
            f"🆔 ID игры: {game_id}\n\n"
            f"🔗 Ссылка для присоединения:\n"
            f"{telegram_link}\n\n"
            f"📤 Перешлите это сообщение друзьям для приглашения в игру"
        )
        
        logger.info(f"[DEBUG] Упрощенный текст сообщения для пересылки:")
        logger.info(f"[DEBUG] {share_message}")
        logger.info(f"[DEBUG] Используемая ссылка в сообщении: {telegram_link}")
        logger.info(f"[DEBUG] Используемое имя бота в тексте: @{safe_bot_username}")
        
        # Отправляем отдельное сообщение БЕЗ markdown форматирования
        await context.bot.send_message(
            query.from_user.id,
            share_message,
            parse_mode=None,  # Убираем markdown
            disable_web_page_preview=True  # Отключаем предпросмотр ссылок
        )
        
        await query.answer("✅ Сообщение для пересылки отправлено!")
    
    elif data.startswith("timer_status_"):
        game_id = data[13:]  # Убираем "timer_status_"
        
        if game_id not in games:
            await query.answer("Игра не найдена", show_alert=True)
            return
            
        game = games[game_id]
        
        if game.get('state') != STATE_TIMER_WAITING:
            await query.answer("Эта игра уже не в режиме ожидания таймера", show_alert=True)
            return
            
        current_players = sum(1 for slot in game['players_slots'] if slot.get('user_id'))
        max_players = game.get('max_players', 6)
        
        # Считаем оставшееся время
        from datetime import datetime, timedelta
        timer_started = game.get('timer_started_at')
        if isinstance(timer_started, str):
            # Если время сохранено как строка, парсим его
            try:
                timer_started = datetime.strptime(timer_started, "%Y-%m-%d %H:%M:%S")
            except:
                timer_started = datetime.now() - timedelta(minutes=1)  # Заглушка
        
        elapsed_time = datetime.now() - timer_started
        remaining_time = timedelta(minutes=3) - elapsed_time
        
        if remaining_time.total_seconds() <= 0:
            remaining_text = "Время истекло! Игра должна была начаться."
        else:
            remaining_minutes = int(remaining_time.total_seconds() // 60)
            remaining_seconds = int(remaining_time.total_seconds() % 60)
            remaining_text = f"{remaining_minutes}:{remaining_seconds:02d}"
        
        status_message = (
            f"⏰ Статус таймер-игры {game_id}\n\n"
            f"👥 Игроков присоединилось: {current_players}/{max_players}\n"
            f"⏱️ Оставшееся время: {remaining_text}\n"
            f"🎯 Минимум для старта: 4 игрока\n\n"
            f"📈 Игра начнется автоматически СТРОГО через 3 минуты независимо от количества игроков."
        )
        
        try:
            await query.edit_message_text(
                status_message,
                parse_mode=None,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Обновить", callback_data=f"timer_status_{game_id}")],
                    [InlineKeyboardButton("📋 Поделиться игрой", callback_data=f"copy_link_{game_id}")]
                ])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                await query.answer("⏰ Статус уже обновлен")
            else:
                logger.error(f"Ошибка при обновлении статуса таймера: {e}")
                await query.answer("❌ Ошибка обновления статуса")
    
    elif data == "rules":
        await show_roles_selection_menu(query)
    
    elif data == "show_all_roles":
        await show_all_roles_with_buttons(query)
    
    elif data.startswith("role_detail_"):
        role_name = data[12:]  # Убираем "role_detail_"
        await show_role_details(query, role_name)
    
    elif data == "show_full_rules":
        await show_full_rules_text_interface(query)
    
    elif data == "activate_demo":
        # Активация демо через кнопку
        user_id = query.from_user.id
        
        if not premium_db.can_activate_demo(user_id):
            is_premium, status = premium_db.check_premium_status(user_id)
            user_data = premium_db.get_user_info(user_id)
            
            if user_data and user_data.get("demo_used", False):
                await query.answer("❌ Вы уже использовали демо-версию", show_alert=True)
            elif is_premium:
                await query.answer("❌ У вас уже есть активная подписка", show_alert=True)
            return
        
        success, message = premium_db.activate_demo(user_id)
        
        if success:
            await query.edit_message_text(
                f"{message}\n\n"
                "🎮 **Доступные премиум-функции:**\n"
                "• Игры от 4 до 20 игроков (вместо 8)\n"
                "• Все роли (Дон Мафии, Маньяк, Путана и др.)\n"
                "• Ручная настройка ролей\n"
                "• Расширенная статистика\n"
                "• Приоритетная поддержка\n\n"
                "💡 **Попробуйте создать игру на 10+ игроков!**\n\n"
                "💎 Понравилось? Получите безлимитный доступ: /premium",
                parse_mode='Markdown',
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🎮 Создать премиум игру", callback_data="create_game"),
                    InlineKeyboardButton("💎 Купить Premium", callback_data="get_premium")
                ]])
            )
        else:
            await query.answer(f"❌ {message}", show_alert=True)
    
    elif data == "get_premium":
        # Показываем кнопку покупки премиума
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("💳 Купить премиум (299₽)", callback_data="buy_premium")],
            [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
        ])
        
        await query.edit_message_text(
            "💎 **Премиум функции:**\n\n"
            "• **🎭 Все роли** (Дон Мафии, Маньяк, Путана и др.)\n"
            "• **👥 До 20 игроков** в одной игре (вместо 8)\n"
            "• **⚙️ Ручная настройка ролей**\n"
            "• **📊 Расширенная статистика**\n\n"
            "💡 **Бот-ведущий доступен БЕСПЛАТНО!**\n\n"
            f"**Цена: {PREMIUM_PRICE_RUBLES}₽**",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=keyboard
        )
    
    elif data == "buy_premium":
        await handle_premium_purchase(update, context)
    
    elif data == "back_to_main":
        text, keyboard = get_start_message_text_and_keyboard()
        await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)
    
    elif data.startswith("leave_game_"):
        game_id = data[11:]  # Убираем "leave_game_"
        
        # Удаляем игрока из игры
        await remove_player_from_game(user.id, game_id, context)
        
        # Показываем подтверждение
        await query.edit_message_text(
            "✅ **Вы покинули игру!**\n\n"
            "Теперь вы можете создать новую игру или присоединиться к другой.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎮 Создать новую игру", callback_data="create_game")],
                [InlineKeyboardButton("🔙 Главное меню", callback_data="back_to_main")]
            ])
        )

    elif data.startswith("cfg_"):
        # Обработка ручной настройки ролей
        pending_setup = context.user_data.get('pending_game_setup')
        if not pending_setup or pending_setup.get('host_id') != user.id:
            await query.answer("Это не ваша сессия настройки игры или она истекла.", show_alert=True)
            return
        
        parts = data.split('_')
        action = parts[1]
        role_name = parts[2] if len(parts) > 2 else None
        
        current_roles = pending_setup.get('current_roles', {})
        total_players = pending_setup.get('total_players', 0)
        current_assigned = sum(current_roles.values())
        
        if action == "inc" and role_name:
            if current_assigned < total_players:
                current_roles[role_name] = current_roles.get(role_name, 0) + 1
                await query.answer(f"{role_name} +1")
            else:
                await query.answer(f"Уже выбрано максимальное количество ролей ({total_players})!", show_alert=True)
            await send_role_config_message(query, context, is_edit=True)
            return
        
        elif action == "dec" and role_name:
            if current_roles.get(role_name, 0) > 0:
                current_roles[role_name] = current_roles.get(role_name, 0) - 1
                await query.answer(f"{role_name} -1")
            else:
                await query.answer(f"Количество {role_name} уже 0.")
            await send_role_config_message(query, context, is_edit=True)
            return
        
        elif action == "reset":
            pending_setup['current_roles'] = {role: 0 for role in ALL_CONFIGURABLE_ROLES}
            await query.answer("Конфигурация ролей сброшена.")
            await send_role_config_message(query, context, is_edit=True)
            return
        
        elif action == "cancel":
            await query.answer("Создание игры отменено.")
            await query.edit_message_text("Создание игры отменено.", reply_markup=None)
            if 'pending_game_setup' in context.user_data: 
                del context.user_data['pending_game_setup']
            return
        
        elif action == "confirm":
            if current_assigned != total_players:
                await query.answer(f"Количество выбранных ролей ({current_assigned}) не совпадает с количеством игроков ({total_players})!", show_alert=True)
                return
            
            await query.answer("Подтверждено! Создаю игру...")
            
            # Создаем список ролей с гарантированной рандомизацией
            final_roles_list = []
            
            # Собираем все роли в список
            for role_name, count in current_roles.items():
                if count > 0:
                    final_roles_list.extend([role_name] * count)
            
            # Многократное перемешивание для гарантии случайности
            for _ in range(5):
                random.shuffle(final_roles_list)
            
            # Дополнительная рандомизация через random.sample
            final_roles_list = random.sample(final_roles_list, len(final_roles_list))
            
            logger.info(f"[DEBUG] Финальное распределение ролей (случайное): {final_roles_list}")
            
            # Создаем игру с ручной конфигурацией
            await create_game_with_manual_roles(query, context, pending_setup, final_roles_list)
            return
    
    elif data.startswith("role_info_"):
        # Показываем информацию о роли
        role_name = data[10:]  # Убираем "role_info_"
        role_data = ROLES_DATA.get(role_name, {})
        if role_data:
            # Сокращаем описание для избежания ошибки Message_too_long
            description = role_data.get('description', 'Н/Д')[:100]
            goal = role_data.get('goal', 'Н/Д')[:80]
            actions = role_data.get('actions', 'Н/Д')[:80]
            
            info_text = (
                f"{role_name}\n\n"
                f"Описание: {description}...\n\n"
                f"Цель: {goal}\n\n"
                f"Действия: {actions}"
            )
        else:
            info_text = f"{role_name}\n\nИнформация о роли недоступна."
        
        await query.answer(info_text, show_alert=True)
        return
    
    elif data == "ignore":
        # Игнорируем некоторые callback (например, информационные кнопки)
        await query.answer()
        return

    elif data.startswith("host_type_"):
        # Обработка выбора типа ведущего для премиум и бесплатного режима
        try:
            parts = data.split('_')
            host_type = parts[2]  # human, bot или timer
            num_players = int(parts[3])
            is_free = len(parts) > 4 and parts[4] == 'free'
            
            logger.info(f"[DEBUG] Обработка выбора типа ведущего: {host_type} для {num_players} игроков, free: {is_free}")
        except Exception as e:
            logger.error(f"[ERROR] Ошибка в host_type_ обработчике: {e}")
            await query.answer("❌ Ошибка обработки", show_alert=True)
            return
        
        # Для режима времени создаем игру особым способом
        if host_type == 'timer':
            context.user_data['new_game_pending_settings'] = {
                'num_players': num_players,
                'game_mode': 'bot_host_timer',
                'host_id': query.from_user.id,
                'host_name': query.from_user.full_name or 'Аноним',
                'version': 'free' if is_free else 'paid',
                'role_setup_method': 'auto'
            }
            
            # Сразу создаем игру и запускаем таймер
            await query.answer("Создаю игру с таймером...")
            await create_timer_game_from_pending_settings(query, context, context.user_data['new_game_pending_settings'])
            return
        
        # Сохраняем параметры для создания игры (обычные режимы)
        context.user_data['new_game_pending_settings'] = {
            'num_players': num_players,
            'game_mode': f'{host_type}_host',
            'host_id': query.from_user.id,
            'host_name': query.from_user.full_name or 'Аноним',
            'version': 'free' if is_free else 'paid'
        }

        # Для бесплатного режима только автоматическое распределение
        if is_free:
            context.user_data['new_game_pending_settings']['role_setup_method'] = 'auto'
            await query.answer("Создаю бесплатную игру...")
            await create_game_from_pending_settings(query, context, context.user_data['new_game_pending_settings'])
            return

        # Для премиум режима показываем выбор способа распределения ролей
        callback_prefix = "ng_bh" if host_type == 'bot' else "ng"
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("⚙️ Автоматическое распределение", 
                                callback_data=f"{callback_prefix}_roles_auto")],
            [InlineKeyboardButton("✍️ Ручная настройка ролей", 
                                callback_data=f"{callback_prefix}_roles_manual")]
        ])
        
        host_name = 'Бот' if host_type == 'bot' else 'Человек'
        message_text = (
            f"💎 **Премиум игра на {num_players} игроков**\n\n"
            f"**Ведущий:** {host_name}\n\n"
            f"Теперь выберите способ распределения ролей:"
        )
        
        await query.edit_message_text(
            message_text,
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN
        )

    # Обработка голосования в игре с ботом-ведущим
    elif data.startswith("vote_") and not data.startswith("vote_confirmed_"):
        parts = data.split("_")
        if len(parts) >= 3:
            if parts[1] == "skip":
                # Голосование за пропуск
                game_id = "_".join(parts[2:])
                await handle_vote_skip(query, context, game_id)
            else:
                # Голосование за конкретного игрока
                try:
                    game_id = "_".join(parts[1:-1])
                    player_index = int(parts[-1])
                    await handle_vote_player(query, context, game_id, player_index)
                except (ValueError, IndexError) as e:
                    await query.answer("❌ Ошибка в данных голосования", show_alert=True)
                    logger.error(f"Error parsing vote callback: {e}")

    # Обработка пропуска первого дня
    elif data.startswith("skip_first_day_"):
        game_id = data.replace("skip_first_day_", "")
        await handle_skip_first_day(query, context, game_id)

    # Обработка нажатия на кнопку "уже проголосовал за пропуск"
    elif data.startswith("already_voted_skip_"):
        await query.answer("✅ Вы уже проголосовали за пропуск дня", show_alert=False)

    # Обработка подтверждения голосования за игрока
    elif data.startswith("confirm_vote_"):
        parts = data.split("_")
        if len(parts) >= 3:
            try:
                player_index = int(parts[-1])
                game_id = "_".join(parts[2:-1])
                await handle_confirm_vote(query, context, game_id, player_index)
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных подтверждения голосования", show_alert=True)
                logger.error(f"Error parsing confirm vote callback: {e}")

    # Обработка подтверждения пропуска голосования
    elif data.startswith("confirm_skip_"):
        game_id = data.replace("confirm_skip_", "")
        await handle_confirm_skip(query, context, game_id)

    # Обработка возврата к интерфейсу голосования
    elif data.startswith("return_to_voting_"):
        game_id = data.replace("return_to_voting_", "")
        await handle_return_to_voting(query, context, game_id)

    # Обработка нажатия на кнопку "голос засчитан"
    elif data.startswith("vote_confirmed_"):
        await query.answer("✅ Ваш голос уже засчитан", show_alert=False)
    
    # === ОБРАБОТЧИКИ ДЛЯ УПРАВЛЕНИЯ ЧЕЛОВЕКОМ-ВЕДУЩИМ ===
    
    # Основные команды управления
    elif data.startswith("night_"):
        game_id = data.replace("night_", "")
        if game_id in games:
            await set_night_action(game_id, games[game_id], query, context)
    
    elif data.startswith("day_"):
        game_id = data.replace("day_", "")
        if game_id in games:
            await set_day_action(game_id, games[game_id], query, context)
    
    elif data.startswith("status_"):
        game_id = data.replace("status_", "")
        if game_id in games:
            await game_status_action(game_id, games[game_id], query, context)
    
    elif data.startswith("end_"):
        game_id = data.replace("end_", "")
        if game_id in games:
            await end_game_action(game_id, games[game_id], query, context)
    
    elif data.startswith("manage_"):
        game_id = data.replace("manage_", "")
        if game_id in games:
            await query.edit_message_text(f"Управление игрой {game_id}:", 
                                        reply_markup=get_main_control_keyboard(game_id))
    
    # Исключение игроков
    elif data.startswith("show_elim_list_"):
        game_id = data.replace("show_elim_list_", "")
        if game_id in games:
            await query.edit_message_text(f"Выберите игрока для исключения из игры {game_id}:", 
                                        reply_markup=get_player_elimination_keyboard(game_id, games[game_id]))
    
    elif data.startswith("elim_"):
        parts = data.split("_")
        if len(parts) >= 3:
            game_id = "_".join(parts[1:-1])
            player_num = int(parts[-1])
            if game_id in games:
                await eliminate_player_action(game_id, games[game_id], player_num, query, context)
    
    # Ночные действия
    elif data.startswith("night_role_turn_"):
        parts = data.replace("night_role_turn_", "").split("_", 1)
        if len(parts) == 2:
            game_id, role = parts
            if game_id in games:
                await query.edit_message_text(f"Выберите цель для роли {role}:", 
                                            reply_markup=get_player_selection_keyboard_for_night_action(game_id, games[game_id], role))
    
    elif data.startswith("night_action_"):
        parts = data.replace("night_action_", "").split("_")
        if len(parts) >= 3:
            game_id = "_".join(parts[:-2])
            role = parts[-2]
            target_num = int(parts[-1])
            if game_id in games:
                game_data = games[game_id]
                night_data = game_data.get("night_data", {})
                night_data["actions_taken_by_role"][role] = target_num
                night_data["acted_roles"].add(role)
                games[game_id] = game_data
                
                # Возвращаемся к ночному интерфейсу
                message = f"🌃 Ночь {game_data['current_night_number']} в игре {game_id}. Выберите роли для действий:"
                await query.edit_message_text(text=message, reply_markup=get_night_host_keyboard(game_id, game_data))
                await query.answer(f"{role} выбрал цель {target_num}")
    
    elif data.startswith("night_return_to_main_"):
        game_id = data.replace("night_return_to_main_", "")
        if game_id in games:
            game_data = games[game_id]
            message = f"🌃 Ночь {game_data['current_night_number']} в игре {game_id}. Выберите роли для действий:"
            await query.edit_message_text(text=message, reply_markup=get_night_host_keyboard(game_id, game_data))
    
    elif data.startswith("night_end_"):
        game_id = data.replace("night_end_", "")
        if game_id in games:
            game_data = games[game_id]
            await resolve_night_actions_and_announce_day(game_id, game_data, query, context)
    
    elif data.startswith("night_info_"):
        await query.answer("Действие уже выполнено", show_alert=False)
    
    # === ОБРАБОТКА МАТЕМАТИЧЕСКИХ ПРИМЕРОВ ===
    elif data.startswith("math_answer_"):
        # Разбираем callback: math_answer_{game_id}_{user_id}_{selected_answer}
        parts = data.split("_")
        if len(parts) >= 4:
            try:
                # Собираем game_id обратно (может содержать underscores)
                game_id_start_index = 2
                user_id_index = -2
                answer_index = -1
                
                user_id = int(parts[user_id_index])
                selected_answer = int(parts[answer_index])
                game_id = "_".join(parts[game_id_start_index:user_id_index])
                
                await handle_math_button_answer(query, context, game_id, user_id, selected_answer)
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных математического примера", show_alert=True)
                logger.error(f"Error parsing math answer callback: {e}")
    
    # === ОБРАБОТКА ВЫБОРА ЖЕРТВЫ МАФИЕЙ ===
    elif data.startswith("mafia_target_"):
        # Разбираем callback: mafia_target_{game_id}_{target_index}
        parts = data.split("_")
        if len(parts) >= 3:
            try:
                target_index = int(parts[-1])
                game_id = "_".join(parts[2:-1])
                
                await handle_mafia_target_selection(query, context, game_id, target_index)
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных выбора цели", show_alert=True)
                logger.error(f"Error parsing mafia target callback: {e}")
    
    # === ОБРАБОТКА ВЫБОРА ЦЕЛИ ДОКТОРА ===
    elif data.startswith("doctor_target_"):
        parts = data.split("_")
        if len(parts) >= 3:
            try:
                target_index = int(parts[-1])
                game_id = "_".join(parts[2:-1])
                
                await handle_doctor_target_selection(query, context, game_id, target_index)
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных выбора цели", show_alert=True)
                logger.error(f"Error parsing doctor target callback: {e}")
    
    # === ОБРАБОТКА ПОДТВЕРЖДЕНИЯ ВЫБОРА ДОКТОРА ===
    elif data.startswith("confirm_doctor_"):
        parts = data.split("_")
        if len(parts) >= 3:
            try:
                target_index = int(parts[-1])
                game_id = "_".join(parts[2:-1])
                await handle_confirm_doctor(query, context, game_id, target_index)
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных подтверждения", show_alert=True)
                logger.error(f"Error parsing confirm doctor callback: {e}")
    
    # === ОБРАБОТКА ВОЗВРАТА К ВЫБОРУ ДОКТОРА ===
    elif data.startswith("return_doctor_"):
        game_id = data.replace("return_doctor_", "")
        await handle_return_doctor(query, context, game_id)
    
    # === ОБРАБОТКА ВЫБОРА ЦЕЛИ КОМИССАРА ===
    elif data.startswith("commissioner_target_"):
        parts = data.split("_")
        if len(parts) >= 3:
            try:
                target_index = int(parts[-1])
                game_id = "_".join(parts[2:-1])
                
                await handle_commissioner_target_selection(query, context, game_id, target_index)
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных выбора цели", show_alert=True)
                logger.error(f"Error parsing commissioner target callback: {e}")
    
    # === ОБРАБОТКА ВЫБОРА ЦЕЛИ МАНЬЯКА ===
    elif data.startswith("maniac_target_"):
        parts = data.split("_")
        if len(parts) >= 3:
            try:
                target_index = int(parts[-1])
                game_id = "_".join(parts[2:-1])
                
                await handle_maniac_target_selection(query, context, game_id, target_index)
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных выбора цели", show_alert=True)
                logger.error(f"Error parsing maniac target callback: {e}")
    
    # === ОБРАБОТКА ВЫБОРА ЦЕЛИ ПУТАНЫ ===
    elif data.startswith("prostitute_target_"):
        parts = data.split("_")
        if len(parts) >= 3:
            try:
                target_index = int(parts[-1])
                game_id = "_".join(parts[2:-1])
                
                await handle_prostitute_target_selection(query, context, game_id, target_index)
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных выбора цели", show_alert=True)
                logger.error(f"Error parsing prostitute target callback: {e}")
    
    # === ОБРАБОТКА ПРОПУСКА ХОДА ДОКТОРА ===
    elif data.startswith("doctor_skip_"):
        game_id = data[12:]  # Убираем "doctor_skip_"
        await handle_doctor_skip(query, context, game_id)
    
    # === ОБРАБОТКА ПРОПУСКА ХОДА МАНЬЯКА ===
    elif data.startswith("maniac_skip_"):
        game_id = data[12:]  # Убираем "maniac_skip_"
        await handle_maniac_skip(query, context, game_id)
    
    # === ОБРАБОТКА ПРОПУСКА ХОДА ПУТАНЫ ===
    elif data.startswith("prostitute_skip_"):
        game_id = data[16:]  # Убираем "prostitute_skip_"
        await handle_prostitute_skip(query, context, game_id)
    
    # === ОБРАБОТКА РАСКРЫТИЯ РОЛИ УБИТЫМИ ===
    elif data.startswith("reveal_role_") or data.startswith("hide_role_"):
        # Разбираем callback: reveal_role_{game_id}_{user_id} или hide_role_{game_id}_{user_id}
        parts = data.split("_")
        if len(parts) >= 3:
            try:
                action = parts[0]  # reveal или hide
                user_id = int(parts[-1])
                game_id = "_".join(parts[2:-1])
                
                await handle_role_reveal_choice(query, context, game_id, user_id, action == "reveal")
            except (ValueError, IndexError) as e:
                await query.answer("❌ Ошибка в данных раскрытия роли", show_alert=True)
                logger.error(f"Error parsing role reveal callback: {e}")
    
    # === ОБРАБОТЧИКИ КОНФЛИКТОВ ИГР ===
    
    elif data.startswith("leave_games_and_join_"):
        # Пользователь решил покинуть текущие игры и присоединиться к новой
        target_game_id = data.replace("leave_games_and_join_", "")
        user_id = query.from_user.id
        
        # Находим все активные игры пользователя
        active_sessions = await find_all_player_game_sessions(user_id)
        
        # Удаляем пользователя из всех текущих игр
        left_games = []
        for session_game_id, _, _ in active_sessions:
            if session_game_id != target_game_id:  # Не удаляем из целевой игры
                if await remove_player_from_game(user_id, session_game_id, context):
                    left_games.append(session_game_id)
        
        if left_games:
            left_game = left_games[0]  # Обычно должна быть только одна игра
            await query.edit_message_text(
                f"✅ Вы покинули игру: **{left_game}**\n\n"
                f"🎭 Теперь присоединяемся к игре **{target_game_id}**..."
            )
        
        # Теперь присоединяемся к новой игре
        class FakeUpdate:
            def __init__(self, user):
                self.effective_user = user
                self.message = query.message
        
        fake_update = FakeUpdate(query.from_user)
        await join_game(fake_update, context, target_game_id)
    
    elif data == "cancel_join":
        # Пользователь решил остаться в текущей игре
        await query.edit_message_text(
            "✅ Вы остались в текущей игре.\n\n"
            "🎮 Для присоединения к новой игре сначала завершите участие в текущей."
        )
    
    # === КОНЕЦ ОБРАБОТЧИКОВ ===
    
    else:
        await query.answer("Неизвестная команда")

async def handle_vote_player(query, context: CallbackContext, game_id: str, player_index: int):
    """Показывает предварительный выбор игрока с подтверждением"""
    game_data = games.get(game_id)
    if not game_data or not game_data.get("voting_active"):
        await query.answer("Голосование не активно", show_alert=True)
        return
    
    voter_id = query.from_user.id
    
    # Проверяем, что голосующий участвует в игре
    voter_found = False
    voter_slot_index = None
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("user_id") == voter_id and slot.get("status") == STATUS_ACTIVE:
            voter_found = True
            voter_slot_index = i
            break
    
    if not voter_found:
        await query.answer("Вы не участвуете в этой игре", show_alert=True)
        return

    # Проверяем права голосования ТОЛЬКО в режиме бот-ведущего
    game_mode = game_data.get("game_mode", "human_host")
    if game_mode == "bot_host":
        voting_rights = game_data.get("day_voting_rights", {})
        player_key = f"player_{voter_slot_index}"
        has_voting_rights = voting_rights.get(player_key, True)
        
        if not has_voting_rights:
            await query.answer("У вас нет права голоса из-за неправильного ответа на ночное задание", show_alert=True)
            return

    # Проверяем, что игрок еще не голосовал
    if voter_id in game_data.get("votes", {}):
        await query.answer("Вы уже проголосовали", show_alert=True)
        return

    # Получаем имя игрока за которого хотят проголосовать
    target_player_name = game_data["players_slots"][player_index]["fictional_name"]
    
    # Подсчитываем текущие голоса для отображения статистики
    current_votes = game_data.get("votes", {})
    vote_counts = {}
    for voted_for in current_votes.values():
        if voted_for == "skip":
            vote_counts["skip"] = vote_counts.get("skip", 0) + 1
        else:
            player_name = game_data["players_slots"][voted_for]["fictional_name"]
            vote_counts[player_name] = vote_counts.get(player_name, 0) + 1
    
    # Создаем клавиатуру для подтверждения
    confirmation_keyboard = [
        [InlineKeyboardButton("✅ Подтвердить голосование", callback_data=f"confirm_vote_{game_id}_{player_index}")],
        [InlineKeyboardButton("🔙 Вернуться к выбору", callback_data=f"return_to_voting_{game_id}")]
    ]
    reply_markup = InlineKeyboardMarkup(confirmation_keyboard)
    
    # Формируем сообщение с подтверждением
    confirmation_message = (
        f"🗳️ **Подтверждение голосования**\n\n"
        f"🎯 Вы выбрали: **{target_player_name}**\n\n"
        f"📊 **Текущие голоса:**\n"
    )
    
    if vote_counts:
        for candidate, votes in vote_counts.items():
            confirmation_message += f"• {candidate}: {votes} голос(ов)\n"
    else:
        confirmation_message += "• Пока никто не голосовал\n"
    
    confirmation_message += f"\n❓ Подтвердить свой выбор?"
    
    try:
        await query.edit_message_text(
            confirmation_message,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error showing confirmation message: {e}")
        await query.answer("Ошибка при отображении подтверждения")

async def handle_confirm_vote(query, context: CallbackContext, game_id: str, player_index: int):
    """Обрабатывает подтвержденное голосование за конкретного игрока"""
    game_data = games.get(game_id)
    if not game_data or not game_data.get("voting_active"):
        await query.answer("Голосование не активно", show_alert=True)
        return
    
    voter_id = query.from_user.id
    
    # Проверяем, что игрок еще не голосовал
    if voter_id in game_data.get("votes", {}):
        await query.answer("Вы уже проголосовали", show_alert=True)
        return

    # Записываем голос
    if "votes" not in game_data:
        game_data["votes"] = {}
    game_data["votes"][voter_id] = player_index
    
    # Сохраняем message_id для последующего обновления
    if "voted_messages" not in game_data:
        game_data["voted_messages"] = {}
    game_data["voted_messages"][voter_id] = query.message.message_id
    
    games[game_id] = game_data
    
    # Получаем имя игрока за которого проголосовали
    voted_player_name = game_data["players_slots"][player_index]["fictional_name"]
    
    # Создаем обновленную статистику голосования
    current_votes = game_data.get("votes", {})
    voting_status = []
    
    # Создаем список всех голосов для отображения
    for v_id, v_for in current_votes.items():
        # Находим имя голосующего
        v_name = "Неизвестный"
        for slot in game_data["players_slots"]:
            if slot.get("user_id") == v_id:
                v_name = get_player_display_name(slot, context)
                break
        
        # Находим за кого проголосовали  
        if v_for == "skip":
            v_for_name = "Пропуск"
        else:
            v_for_name = game_data["players_slots"][v_for]["fictional_name"]
        
        voting_status.append(f"• {v_name} → {v_for_name}")
    
    # Обновляем сообщение с подтверждением голоса
    voted_keyboard = [[InlineKeyboardButton("✅ Голос засчитан", callback_data=f"vote_confirmed_{game_id}")]]
    voted_reply_markup = InlineKeyboardMarkup(voted_keyboard)
    
    final_message = (
        f"✅ **Ваш голос засчитан!**\n\n"
        f"🎯 Вы проголосовали за: **{voted_player_name}**\n\n"
        f"📊 **Текущие голоса:**\n" + "\n".join(voting_status) + "\n\n"
        f"⏱️ Ожидаем голосов остальных игроков..."
    )
    
    try:
        await query.edit_message_text(
            final_message,
            reply_markup=voted_reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating voted message: {e}")
    
    await query.answer(f"✅ Ваш голос за {voted_player_name} засчитан!")
    logger.info(f"Player {voter_id} voted for player {player_index} ({voted_player_name}) in game {game_id}")
    
    # Обновляем сообщения "Голос засчитан" для ВСЕХ проголосовавших игроков
    await update_all_voted_messages(game_id, game_data, context)
    
    # Проверяем, проголосовали ли все игроки с правом голоса
    await check_if_all_voted_and_finish(game_id, game_data, context)

async def show_current_voting_status(user_id: int, game_id: str, game_data: dict, context: CallbackContext):
    """Показывает текущий статус голосования проголосовавшему игроку"""
    current_votes = game_data.get("votes", {})
    active_players = [slot for slot in game_data["players_slots"] if slot.get("status") == STATUS_ACTIVE]
    
    # Подсчитываем голоса
    vote_counts = {}
    skip_votes = 0
    
    for voted_for in current_votes.values():
        if voted_for == "skip":
            skip_votes += 1
        else:
            player_name = game_data["players_slots"][voted_for]["fictional_name"]
            vote_counts[player_name] = vote_counts.get(player_name, 0) + 1
    
    # Формируем сообщение со статусом
    status_message = (
        f"📊 **Текущий статус голосования:**\n\n"
    )
    
    if vote_counts or skip_votes > 0:
        status_message += "🗳️ **Распределение голосов:**\n"
        
        # Сортируем по количеству голосов
        sorted_votes = sorted(vote_counts.items(), key=lambda x: x[1], reverse=True)
        for player_name, votes in sorted_votes:
            status_message += f"• {player_name}: {votes} голос(ов)\n"
        
        if skip_votes > 0:
            status_message += f"• Пропуск: {skip_votes} голос(ов)\n"
    else:
        status_message += "• Пока никто больше не голосовал\n"
    
    total_voted = len(current_votes)
    total_players = len(active_players)
    status_message += f"\n👥 Проголосовало: {total_voted}/{total_players} игроков"
    
    try:
        await context.bot.send_message(
            user_id,
            status_message,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error sending voting status to player {user_id}: {e}")

async def handle_return_to_voting(query, context: CallbackContext, game_id: str):
    """Возвращает игрока к интерфейсу голосования"""
    game_data = games.get(game_id)
    if not game_data or not game_data.get("voting_active"):
        await query.answer("Голосование не активно", show_alert=True)
        return
    
    # Получаем обновленную клавиатуру голосования
    active_players = []
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("status") == STATUS_ACTIVE:
            active_players.append((i, slot["fictional_name"]))

    # Создаем кнопки для голосования с отображением текущих голосов
    current_votes = game_data.get("votes", {})
    vote_counts = {}
    for voted_for in current_votes.values():
        if voted_for != "skip":
            vote_counts[voted_for] = vote_counts.get(voted_for, 0) + 1
    
    keyboard = []
    for i, name in active_players:
        vote_count = vote_counts.get(i, 0)
        button_text = f"🗳️ {name}" + (f" ({vote_count})" if vote_count > 0 else "")
        keyboard.append([InlineKeyboardButton(button_text, callback_data=f"vote_{game_id}_{i}")])
    
    # Подсчитываем голоса за пропуск
    skip_votes = list(current_votes.values()).count("skip")
    skip_text = f"⭕ Пропустить голосование" + (f" ({skip_votes})" if skip_votes > 0 else "")
    keyboard.append([InlineKeyboardButton(skip_text, callback_data=f"vote_skip_{game_id}")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)

    voting_message = (
        f"🗳️ **Дневное голосование**\n\n"
        f"Обсуждение окончено. Время выбрать, кого изгнать из города!\n"
        f"У каждого есть 3 минуты на голосование."
    )
    
    try:
        await query.edit_message_text(
            voting_message,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error returning to voting interface: {e}")

async def check_if_all_voted_and_finish(game_id: str, game_data: dict, context: CallbackContext):
    """Проверяет, проголосовали ли все игроки с правом голоса, и завершает голосование"""
    if not game_data.get("voting_active"):
        return
    
    # Получаем список игроков с правом голоса
    active_players_with_rights = []
    game_mode = game_data.get("game_mode", "human_host")
    voting_rights = game_data.get("day_voting_rights", {})
    
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("status") == STATUS_ACTIVE:
            player_key = f"player_{i}"
            # Проверяем права голосования только в режиме бот-ведущего
            if game_mode == "bot_host":
                has_voting_rights = voting_rights.get(player_key, True)
            else:
                has_voting_rights = True  # В режиме человек-ведущего все имеют право голоса
            
            if has_voting_rights and slot.get("user_id"):
                active_players_with_rights.append(slot.get("user_id"))
    
    # Проверяем голоса
    current_votes = game_data.get("votes", {})
    voted_players = set(current_votes.keys())
    players_with_rights_ids = set(active_players_with_rights)
    
    # Если все игроки с правом голоса проголосовали - завершаем голосование
    if players_with_rights_ids.issubset(voted_players):
        logger.info(f"All players with voting rights have voted in game {game_id}, ending voting early")
        await process_voting_results(game_id, game_data, context)

async def update_all_voted_messages(game_id: str, game_data: dict, context: CallbackContext):
    """Обновляет сообщения 'Голос засчитан' для всех проголосовавших игроков с актуальной статистикой"""
    current_votes = game_data.get("votes", {})
    voted_messages = game_data.get("voted_messages", {})
    
    if not current_votes:
        return
    
    # Создаем общую статистику голосования
    voting_status = []
    for v_id, v_for in current_votes.items():
        # Находим имя голосующего
        v_name = "Неизвестный"
        for slot in game_data["players_slots"]:
            if slot.get("user_id") == v_id:
                v_name = get_player_display_name(slot, context)
                break
        
        # Находим за кого проголосовали  
        if v_for == "skip":
            v_for_name = "Пропуск"
        else:
            v_for_name = game_data["players_slots"][v_for]["fictional_name"]
        
        voting_status.append(f"• {v_name} → {v_for_name}")
    
    # Обновляем сообщения для каждого проголосовавшего игрока
    for voter_id, vote_for in current_votes.items():
        message_id = voted_messages.get(voter_id)
        if not message_id:
            continue
            
        # Получаем имя кандидата за которого голосовал этот игрок
        if vote_for == "skip":
            voted_for_name = "Пропуск голосования"
        else:
            voted_for_name = game_data["players_slots"][vote_for]["fictional_name"]
        
        # Формируем обновленное сообщение
        voted_keyboard = [[InlineKeyboardButton("✅ Голос засчитан", callback_data=f"vote_confirmed_{game_id}")]]
        voted_reply_markup = InlineKeyboardMarkup(voted_keyboard)
        
        updated_message = (
            f"✅ **Ваш голос засчитан!**\n\n"
            f"🎯 Вы проголосовали за: **{voted_for_name}**\n\n"
            f"📊 **Текущие голоса:**\n" + "\n".join(voting_status) + "\n\n"
            f"⏱️ Ожидаем голосов остальных игроков..."
        )
        
        try:
            await context.bot.edit_message_text(
                text=updated_message,
                chat_id=voter_id,
                message_id=message_id,
                reply_markup=voted_reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"Error updating voted message for player {voter_id}: {e}")

async def update_voting_status_for_other_players(game_id: str, game_data: dict, context: CallbackContext, exclude_user_id: int):
    """Обновляет статистику голосования у игроков, кроме указанного (который только что проголосовал)"""
    current_votes = game_data.get("votes", {})
    active_players = []
    players_with_voting_rights = []
    voting_rights = game_data.get("day_voting_rights", {})
    game_mode = game_data.get("game_mode", "human_host")
    
    # Собираем данные об активных игроках
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("status") == STATUS_ACTIVE:
            player_key = f"player_{i}"
            # Проверяем права голосования только в режиме бот-ведущего
            if game_mode == "bot_host":
                has_voting_rights = voting_rights.get(player_key, True)
            else:
                has_voting_rights = True
            
            display_name = get_player_display_name(slot, context)
            active_players.append((i, display_name))
            if has_voting_rights:
                players_with_voting_rights.append((i, display_name, slot.get("user_id")))
    
    # Подсчитываем голоса
    vote_counts = {}
    skip_votes = 0
    
    for voted_for in current_votes.values():
        if voted_for == "skip":
            skip_votes += 1
        else:
            player_name = game_data["players_slots"][voted_for]["fictional_name"]
            vote_counts[player_name] = vote_counts.get(player_name, 0) + 1
    
    # Формируем статистику
    status_message = (
        f"📊 **Текущий статус голосования:**\n\n"
    )
    
    if vote_counts or skip_votes > 0:
        status_message += "🗳️ **Распределение голосов:**\n"
        
        # Сортируем по количеству голосов
        sorted_votes = sorted(vote_counts.items(), key=lambda x: x[1], reverse=True)
        for player_name, votes in sorted_votes:
            status_message += f"• {player_name}: {votes} голос(ов)\n"
        
        if skip_votes > 0:
            status_message += f"• Пропуск: {skip_votes} голос(ов)\n"
    else:
        status_message += "• Пока никто не голосовал\n"
    
    total_voted = len(current_votes)
    total_players = len([slot for slot in game_data["players_slots"] if slot.get("status") == STATUS_ACTIVE])
    status_message += f"\n👥 Проголосовало: {total_voted}/{total_players} игроков"
    
    # Отправляем обновление всем игрокам кроме того, кто только что проголосовал
    for i, display_name, user_id in players_with_voting_rights:
        if user_id and user_id != exclude_user_id and user_id not in current_votes:
            try:
                await context.bot.send_message(
                    user_id,
                    status_message,
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending voting status update to player {user_id}: {e}")

async def update_voting_interface_for_all_players(game_id: str, game_data: dict, context: CallbackContext):
    """Обновляет интерфейс голосования для всех игроков, показывая текущие голоса"""
    current_votes = game_data.get("votes", {})
    active_players = []
    players_with_voting_rights = []
    voting_rights = game_data.get("day_voting_rights", {})
    game_mode = game_data.get("game_mode", "human_host")
    
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("status") == STATUS_ACTIVE:
            player_key = f"player_{i}"
            # Проверяем права голосования только в режиме бот-ведущего
            if game_mode == "bot_host":
                has_voting_rights = voting_rights.get(player_key, True)
            else:
                has_voting_rights = True
            
            display_name = get_player_display_name(slot, context)
            active_players.append((i, display_name))
            if has_voting_rights:
                players_with_voting_rights.append((i, display_name, slot.get("user_id")))

    # Подсчитываем голоса
    vote_counts = {}
    skip_votes = 0
    for voted_for in current_votes.values():
        if voted_for == "skip":
            skip_votes += 1
        else:
            vote_counts[voted_for] = vote_counts.get(voted_for, 0) + 1

    # Создаём обновлённое сообщение о статусе голосования
    player_list = []
    for i, name in active_players:
        vote_count = vote_counts.get(i, 0)
        player_list.append(f"• {name} - {vote_count} голос(ов)")
    
    status_message = (
        f"📊 **Обновление голосования**\n\n"
        f"👥 **Текущее распределение голосов:**\n" + "\n".join(player_list) + "\n"
        f"⭕ Пропустить голосование - {skip_votes} голос(ов)\n\n"
        f"📊 **Проголосовало:** {len(current_votes)}/{len(players_with_voting_rights)} игроков"
    )

    # Отправляем обновление всем игрокам с правом голоса, которые ещё НЕ голосовали
    for _, _, user_id in players_with_voting_rights:
        if user_id not in current_votes:  # Только тем, кто ещё не голосовал
            try:
                await context.bot.send_message(
                    user_id,
                    status_message,
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending voting update to player {user_id}: {e}")

async def handle_vote_skip(query, context: CallbackContext, game_id: str):
    """Обрабатывает голосование за пропуск с подтверждением"""
    game_data = games.get(game_id)
    if not game_data or not game_data.get("voting_active"):
        await query.answer("Голосование не активно", show_alert=True)
        return
    
    voter_id = query.from_user.id
    
    # Проверяем, что голосующий участвует в игре
    voter_found = False
    voter_slot_index = None
    for i, slot in enumerate(game_data["players_slots"]):
        if slot.get("user_id") == voter_id and slot.get("status") == STATUS_ACTIVE:
            voter_found = True
            voter_slot_index = i
            break
    
    if not voter_found:
        await query.answer("Вы не участвуете в этой игре", show_alert=True)
        return
    
    # Проверяем права голосования ТОЛЬКО в режиме бот-ведущего
    game_mode = game_data.get("game_mode", "human_host")
    if game_mode == "bot_host":
        voting_rights = game_data.get("day_voting_rights", {})
        player_key = f"player_{voter_slot_index}"
        has_voting_rights = voting_rights.get(player_key, True)
        
        if not has_voting_rights:
            await query.answer("У вас нет права голоса из-за неправильного ответа на ночное задание", show_alert=True)
            return
        
    # Проверяем, что игрок еще не голосовал
    if voter_id in game_data.get("votes", {}):
        await query.answer("Вы уже проголосовали", show_alert=True)
        return

    # Подсчитываем текущие голоса для отображения статистики
    current_votes = game_data.get("votes", {})
    vote_counts = {}
    for voted_for in current_votes.values():
        if voted_for == "skip":
            vote_counts["skip"] = vote_counts.get("skip", 0) + 1
        else:
            player_name = game_data["players_slots"][voted_for]["fictional_name"]
            vote_counts[player_name] = vote_counts.get(player_name, 0) + 1
    
    # Создаем клавиатуру для подтверждения пропуска
    confirmation_keyboard = [
        [InlineKeyboardButton("✅ Подтвердить пропуск", callback_data=f"confirm_skip_{game_id}")],
        [InlineKeyboardButton("🔙 Вернуться к выбору", callback_data=f"return_to_voting_{game_id}")]
    ]
    reply_markup = InlineKeyboardMarkup(confirmation_keyboard)
    
    # Формируем сообщение с подтверждением
    confirmation_message = (
        f"🗳️ **Подтверждение голосования**\n\n"
        f"⭕ Вы выбрали: **Пропустить голосование**\n\n"
        f"📊 **Текущие голоса:**\n"
    )
    
    if vote_counts:
        for candidate, votes in vote_counts.items():
            confirmation_message += f"• {candidate}: {votes} голос(ов)\n"
    else:
        confirmation_message += "• Пока никто не голосовал\n"
    
    confirmation_message += f"\n❓ Подтвердить пропуск голосования?"
    
    try:
        await query.edit_message_text(
            confirmation_message,
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error showing skip confirmation message: {e}")
        await query.answer("Ошибка при отображении подтверждения")

async def handle_confirm_skip(query, context: CallbackContext, game_id: str):
    """Обрабатывает подтвержденное голосование за пропуск"""
    game_data = games.get(game_id)
    if not game_data or not game_data.get("voting_active"):
        await query.answer("Голосование не активно", show_alert=True)
        return
    
    voter_id = query.from_user.id
    
    # Проверяем, что игрок еще не голосовал
    if voter_id in game_data.get("votes", {}):
        await query.answer("Вы уже проголосовали", show_alert=True)
        return

    # Записываем голос за пропуск
    if "votes" not in game_data:
        game_data["votes"] = {}
    game_data["votes"][voter_id] = "skip"
    
    # Сохраняем message_id для последующего обновления
    if "voted_messages" not in game_data:
        game_data["voted_messages"] = {}
    game_data["voted_messages"][voter_id] = query.message.message_id
    
    games[game_id] = game_data
    
    # Создаем обновленную статистику голосования
    current_votes = game_data.get("votes", {})
    voting_status = []
    
    # Создаем список всех голосов для отображения
    for v_id, v_for in current_votes.items():
        # Находим имя голосующего
        v_name = "Неизвестный"
        for slot in game_data["players_slots"]:
            if slot.get("user_id") == v_id:
                v_name = get_player_display_name(slot, context)
                break
        
        # Находим за кого проголосовали  
        if v_for == "skip":
            v_for_name = "Пропуск"
        else:
            v_for_name = game_data["players_slots"][v_for]["fictional_name"]
        
        voting_status.append(f"• {v_name} → {v_for_name}")
    
    # Обновляем сообщение с подтверждением голоса
    voted_keyboard = [[InlineKeyboardButton("✅ Голос засчитан", callback_data=f"vote_confirmed_{game_id}")]]
    voted_reply_markup = InlineKeyboardMarkup(voted_keyboard)
    
    final_message = (
        f"✅ **Ваш голос засчитан!**\n\n"
        f"⭕ Вы проголосовали за: **Пропуск голосования**\n\n"
        f"📊 **Текущие голоса:**\n" + "\n".join(voting_status) + "\n\n"
        f"⏱️ Ожидаем голосов остальных игроков..."
    )
    
    try:
        await query.edit_message_text(
            final_message,
            reply_markup=voted_reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating skip voted message: {e}")
    
    await query.answer("✅ Ваш голос за пропуск засчитан!")
    logger.info(f"Player {voter_id} voted to skip in game {game_id}")
    
    # НЕ отправляем отдельное сообщение, информация уже есть в обновленном сообщении выше
    
    # Проверяем, проголосовали ли все игроки с правом голоса
    await check_if_all_voted_and_finish(game_id, game_data, context)

async def handle_skip_first_day(query, context: CallbackContext, game_id: str):
    """Обрабатывает голосование за пропуск первого дня"""
    game_data = games.get(game_id)
    if not game_data:
        await query.answer("Игра не найдена", show_alert=True)
        return
    
    if game_data.get("state") != STATE_DAY or game_data.get("current_day_number") != 1:
        await query.answer("Сейчас не первый день", show_alert=True)
        return
    
    voter_id = query.from_user.id
    
    # Проверяем, что голосующий участвует в игре
    voter_found = False
    voter_name = None
    for slot in game_data["players_slots"]:
        if slot.get("user_id") == voter_id and slot.get("status") == STATUS_ACTIVE:
            voter_found = True
            voter_name = get_player_display_name(slot, context)
            break
    
    if not voter_found:
        await query.answer("Вы не участвуете в этой игре", show_alert=True)
        return
    
    # Добавляем голос за пропуск первого дня
    if "first_day_skip_votes" not in game_data:
        game_data["first_day_skip_votes"] = set()
    
    if voter_id in game_data["first_day_skip_votes"]:
        await query.answer("Вы уже проголосовали за пропуск", show_alert=True)
        return
    
    game_data["first_day_skip_votes"].add(voter_id)
    games[game_id] = game_data
    
    # Считаем общее количество активных игроков
    total_players = len([slot for slot in game_data["players_slots"] if slot.get("status") == STATUS_ACTIVE])
    skip_votes = len(game_data["first_day_skip_votes"])
    remaining_votes = total_players - skip_votes
    
    # Создаем обновленную клавиатуру с зеленой галочкой
    voted_keyboard = [[InlineKeyboardButton("✅ Проголосовал за пропуск", callback_data=f"already_voted_skip_{game_id}")]]
    voted_reply_markup = InlineKeyboardMarkup(voted_keyboard)
    
    # Обновляем сообщение игрока
    updated_message = (
        f"✅ **Ваш голос засчитан!**\n\n"
        f"🗳️ Проголосовали: {skip_votes}/{total_players}\n"
        f"⏳ Осталось голосов: {remaining_votes}\n\n"
        f"{'🎉 Все проголосовали! Переходим к ночи...' if remaining_votes == 0 else '⏱️ Ожидаем остальных игроков...'}"
    )
    
    try:
        await query.edit_message_text(
            updated_message, 
            reply_markup=voted_reply_markup,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error updating skip vote message: {e}")
        await query.answer(f"✅ Голос засчитан! ({skip_votes}/{total_players})")
    
    # Уведомляем всех остальных игроков об изменении статуса голосования
    await update_skip_vote_status_for_all_players(game_id, game_data, context, voter_name, skip_votes, total_players)
    
    # Если все проголосовали за пропуск - сразу переходим к ночи
    if skip_votes >= total_players:
        logger.info(f"All participants voted to skip first day in game {game_id}")
        
        # Отправляем финальное уведомление всем
        final_message = "🎉 **Все игроки проголосовали за пропуск первого дня!**\n\n🌙 Наступает первая ночь..."
        for slot in game_data["players_slots"]:
            if slot.get("status") == STATUS_ACTIVE and slot.get("user_id") and slot.get("user_id") != voter_id:
                try:
                    await context.bot.send_message(
                        slot["user_id"],
                        final_message,
                        parse_mode=ParseMode.MARKDOWN
                    )
                except Exception as e:
                    logger.error(f"Error sending final skip message to player {slot.get('user_id')}: {e}")
        
        await start_first_night(game_id, game_data, context)

async def update_skip_vote_status_for_all_players(game_id: str, game_data: dict, context: CallbackContext, voter_name: str, skip_votes: int, total_players: int):
    """Обновляет статус голосования за пропуск дня для всех игроков"""
    remaining_votes = total_players - skip_votes
    
    # Создаем обновленную клавиатуру для НЕ проголосовавших игроков
    keyboard = [[InlineKeyboardButton("⭕ Пропустить первый день", callback_data=f"skip_first_day_{game_id}")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Обновленное сообщение для остальных игроков
    updated_message = (
        f"🌞 Доброе утро, город! Начинается первый день игры.\n\n"
        f"Сейчас у вас есть 10 минут, чтобы познакомиться и обсудить стратегию.\n"
        f"Вы можете пропустить первый день, если все игроки готовы начать игру немедленно.\n\n"
        f"📊 **Статус голосования:**\n"
        f"🗳️ Проголосовали: {skip_votes}/{total_players}\n"
        f"⏳ Осталось голосов: {remaining_votes}\n"
        f"👤 Последний голос: {voter_name}"
    )
    
    # Проверяем, есть ли сохраненные сообщения для обновления
    if "first_day_messages" in game_data:
        # Создаем клавиатуру для уже проголосовавших
        voted_keyboard = [[InlineKeyboardButton("✅ Проголосовал за пропуск", callback_data=f"already_voted_skip_{game_id}")]]
        voted_reply_markup = InlineKeyboardMarkup(voted_keyboard)
        
        for msg_info in game_data["first_day_messages"]:
            try:
                # Определяем кто является владельцем этого сообщения
                chat_id = msg_info["chat_id"]
                
                # Проверяем, проголосовал ли владелец чата
                user_voted = False
                for slot in game_data["players_slots"]:
                    if slot.get("user_id") == chat_id and slot.get("user_id") in game_data["first_day_skip_votes"]:
                        user_voted = True
                        break
                
                # Выбираем правильную клавиатуру
                message_reply_markup = voted_reply_markup if user_voted else reply_markup
                
                await context.bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=msg_info["message_id"],
                    text=updated_message,
                    reply_markup=message_reply_markup,
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error updating first day message for chat {msg_info['chat_id']}: {e}")
    else:
        # Если нет сохраненных сообщений, отправляем новые уведомления
        for slot in game_data["players_slots"]:
            if slot.get("status") == STATUS_ACTIVE and slot.get("user_id"):
                voter_id_from_slot = None
                for vote_user_id in game_data.get("first_day_skip_votes", set()):
                    if slot.get("user_id") == vote_user_id:
                        voter_id_from_slot = vote_user_id
                        break
                
                # Не отправляем уведомление тому, кто только что проголосовал
                if voter_id_from_slot:
                    continue
                    
                try:
                    await context.bot.send_message(
                        slot["user_id"],
                        f"📊 **Обновление голосования:**\n"
                        f"👤 {voter_name} проголосовал за пропуск дня\n"
                        f"🗳️ Проголосовали: {skip_votes}/{total_players}\n"
                        f"⏳ Осталось голосов: {remaining_votes}",
                        parse_mode=ParseMode.MARKDOWN
                    )
                except Exception as e:
                    logger.error(f"Error sending vote update to player {slot.get('user_id')}: {e}")

def get_role_description(role_name: str) -> str:
    """Возвращает описание роли для игрока"""
    role_data = ROLES_DATA.get(role_name, {})
    if not role_data:
        return "Неизвестная роль"
    
    return (
        f"**{role_name}**\n\n"
        f"📝 **Описание:** {role_data.get('description', 'Описание отсутствует')}\n\n"
        f"🎯 **Цель:** {role_data.get('goal', 'Цель не указана')}\n\n"
        f"⚡ **Действия:** {role_data.get('actions', 'Действия не указаны')}"
    )

def get_full_rules_text() -> str:
    """Возвращает полные правила игры с описанием всех ролей"""
    rules = (
        "📖 **ПРАВИЛА ИГРЫ МАФИЯ**\n\n"
        
        "🎯 **ОБЩАЯ ЦЕЛЬ ИГРЫ:**\n"
        "• **Мирные жители:** найти и исключить всех мафиози\n"
        "• **Мафия:** захватить город, став равной или превышающей по числу мирных\n"
        "• **Маньяк:** остаться последним выжившим (если присутствует)\n\n"
        
        "🕐 **ФАЗЫ ИГРЫ:**\n\n"
        
        "🌙 **НОЧНАЯ ФАЗА:**\n"
        "• Все роли с ночными способностями действуют тайно\n"
        "• Мафия выбирает жертву для убийства\n"
        "• Доктор может спасти одного игрока\n"
        "• Комиссар проверяет одного игрока\n"
        "• Маньяк убивает выбранную жертву\n"
        "• Путана блокирует способности игрока\n"
        "• 💬 **Чат мафии активен** во время их хода\n\n"
        
        "☀️ **ДНЕВНАЯ ФАЗА:**\n"
        "• Объявляются результаты ночи\n"
        "• Открытые обсуждения между всеми игроками\n"
        "• Голосование за исключение подозреваемого\n"
        "• Игрок с наибольшим количеством голосов исключается\n"
        "• 💬 **Общий чат активен** для всех живых игроков\n\n"
        
        "💬 **СИСТЕМА ЧАТА:**\n"
        "• Просто напишите сообщение боту - оно дойдет до нужных игроков\n"
        "• **День:** Все живые игроки видят ваши сообщения\n"
        "• **Ночь:** Только мафия может общаться во время своего хода\n"
        "• Формат: \"Игровое имя | Telegram имя: ваш текст\"\n\n"
        
        "👥 **РОЛИ И ИХ СПОСОБНОСТИ:**\n\n"
    )
    
    # Добавляем описание каждой роли
    for role_name, role_data in ROLES_DATA.items():
        rules += (
            f"**{role_name}:**\n"
            f"{role_data['description']}\n"
            f"*Цель:* {role_data['goal']}\n"
            f"*Действия:* {role_data['actions']}\n\n"
        )
    
    rules += (
        "🏆 **УСЛОВИЯ ПОБЕДЫ:**\n\n"
        "**Мирные побеждают, если:**\n"
        "• Все мафиози исключены из игры\n"
        "• Маньяк исключен (если присутствует)\n\n"
        
        "**Мафия побеждает, если:**\n"
        "• Количество мафиози ≥ количества мирных\n\n"
        
        "**Маньяк побеждает, если:**\n"
        "• Остается последним выжившим\n\n"
        
        "🎮 **РЕЖИМЫ ИГРЫ:**\n\n"
        "**🆓 Бесплатный режим:**\n"
        "• До 8 игроков\n"
        "• Ведущий - вы или бот\n"
        "• Базовые роли\n\n"
        
        "**💎 Премиум режим:**\n"
        "• До 20 игроков\n"
        "• Ведущий - вы или бот\n"
        "• Все роли доступны\n"
        "• Ручная настройка ролей"
    )
    
    return rules

# Роли, доступные в бесплатном режиме
FREE_ROLES = ["Мирный житель", "Мафиози", "Комиссар", "Доктор"]

async def show_roles_selection_menu(query):
    """Показывает главное меню выбора ролей"""
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("👥 Список доступных ролей", callback_data="show_all_roles")],
        [InlineKeyboardButton("📖 Полные правила игры", callback_data="show_full_rules")],
        [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ])
    
    await query.edit_message_text(
        "📚 **ПРАВИЛА И РОЛИ**\n\n"
        "Нажмите на название роли, чтобы увидеть её описание",
        reply_markup=keyboard,
        parse_mode=ParseMode.MARKDOWN
    )

async def show_all_roles_with_buttons(query):
    """Показывает все роли в виде кнопок"""
    keyboard_rows = []
    
    # Создаем кнопки для каждой роли
    for role_name in ROLES_DATA.keys():
        # Добавляем эмодзи для роли
        if role_name == "Мирный житель":
            emoji = "👨‍💼"
        elif role_name == "Мафиози":
            emoji = "🕴️"
        elif role_name == "Дон Мафии":
            emoji = "👑"
        elif role_name == "Комиссар":
            emoji = "🕵️"
        elif role_name == "Доктор":
            emoji = "👨‍⚕️"
        elif role_name == "Маньяк":
            emoji = "🔪"
        elif role_name == "Путана":
            emoji = "💃"
        else:
            emoji = "🎭"
            
        keyboard_rows.append([InlineKeyboardButton(
            f"{emoji} {role_name}", 
            callback_data=f"role_detail_{role_name}"
        )])
    
    # Добавляем кнопку назад
    keyboard_rows.append([InlineKeyboardButton("🔙 Назад к правилам", callback_data="rules")])
    
    keyboard = InlineKeyboardMarkup(keyboard_rows)
    
    await query.edit_message_text(
        "👥 **СПИСОК ДОСТУПНЫХ РОЛЕЙ**\n\n"
        "Нажмите на название роли, чтобы увидеть её описание\n\n"
        "🔹 **Базовые роли** (доступны в бесплатном режиме):\n"
        "👨‍💼 Мирный житель, 🕴️ Мафиози, 🕵️ Комиссар, 👨‍⚕️ Доктор\n\n"
        "🔸 **Дополнительные роли** (только в премиум режиме):\n"
        "👑 Дон Мафии, 🔪 Маньяк, 💃 Путана",
        reply_markup=keyboard,
        parse_mode=ParseMode.MARKDOWN
    )

async def show_role_details(query, role_name):
    """Показывает детальное описание роли"""
    role_data = ROLES_DATA.get(role_name, {})
    
    if not role_data:
        await query.answer("❌ Информация о роли не найдена", show_alert=True)
        return
    
    # Определяем доступность роли
    availability = "🆓 Доступна в бесплатном режиме" if role_name in FREE_ROLES else "💎 Только в премиум режиме"
    
    # Добавляем эмодзи для роли
    if role_name == "Мирный житель":
        emoji = "👨‍💼"
    elif role_name == "Мафиози":
        emoji = "🕴️"
    elif role_name == "Дон Мафии":
        emoji = "👑"
    elif role_name == "Комиссар":
        emoji = "🕵️"
    elif role_name == "Доктор":
        emoji = "👨‍⚕️"
    elif role_name == "Маньяк":
        emoji = "🔪"
    elif role_name == "Путана":
        emoji = "💃"
    else:
        emoji = "🎭"
    
    message_text = (
        f"{emoji} **{role_name}**\n\n"
        f"{availability}\n\n"
        f"📝 **Описание:**\n{role_data['description']}\n\n"
        f"🎯 **Цель:**\n{role_data['goal']}\n\n"
        f"⚡ **Действия:**\n{role_data['actions']}"
    )
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 К списку ролей", callback_data="show_all_roles")]
    ])
    
    await query.edit_message_text(
        message_text,
        reply_markup=keyboard,
        parse_mode=ParseMode.MARKDOWN
    )

async def show_full_rules_text_interface(query):
    """Показывает полные правила игры"""
    rules_text = get_full_rules_text()
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Назад к правилам", callback_data="rules")]
    ])
    
    await query.edit_message_text(
        rules_text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=keyboard
    )

def get_role_config_keyboard(pending_setup: dict) -> InlineKeyboardMarkup:
    """Создает клавиатуру для ручной настройки ролей"""
    current_roles = pending_setup.get('current_roles', {})
    total_players = pending_setup.get('total_players', 0)
    current_assigned = sum(current_roles.values())
    
    # Сокращенные названия для интерфейса
    role_short_names = {
        "Мирный житель": "Мирный",
        "Мафиози": "Мафиози", 
        "Дон Мафии": "Дон",
        "Комиссар": "Комиссар",
        "Доктор": "Доктор",
        "Маньяк": "Маньяк",
        "Путана": "Путана"
    }
    
    buttons = []
    
    # Заголовок с информацией
    for role in ALL_CONFIGURABLE_ROLES:
        count = current_roles.get(role, 0)
        short_name = role_short_names.get(role, role)
        # Кнопки уменьшения и увеличения для каждой роли
        role_row = [
            InlineKeyboardButton("-", callback_data=f"cfg_dec_{role}"),
            InlineKeyboardButton(f"{short_name}: {count}", callback_data=f"role_info_{role}"),
            InlineKeyboardButton("+", callback_data=f"cfg_inc_{role}")
        ]
        buttons.append(role_row)
    
    # Информация о текущем состоянии
    buttons.append([InlineKeyboardButton(f"📊 Выбрано: {current_assigned}/{total_players}", callback_data="ignore")])
    
    # Кнопки управления
    control_buttons = [
        [InlineKeyboardButton("🔄 Сбросить", callback_data="cfg_reset")],
        [InlineKeyboardButton("❌ Отмена", callback_data="cfg_cancel")]
    ]
    
    # Кнопка подтверждения (если все роли назначены)
    if current_assigned == total_players and total_players > 0:
        control_buttons.insert(0, [InlineKeyboardButton("✅ Подтвердить", callback_data="cfg_confirm")])
    
    buttons.extend(control_buttons)
    
    return InlineKeyboardMarkup(buttons)

async def send_role_config_message(query_or_update, context: CallbackContext, is_edit: bool = False):
    """Отправляет или редактирует сообщение настройки ролей"""
    pending_setup = context.user_data.get('pending_game_setup')
    if not pending_setup:
        return
    
    current_roles = pending_setup.get('current_roles', {})
    total_players = pending_setup.get('total_players', 0)
    current_assigned = sum(current_roles.values())
    
    message_text = (
        f"⚙️ **Ручная настройка ролей**\n\n"
        f"👥 **Общее количество игроков:** {total_players}\n"
        f"🎯 **Назначено ролей:** {current_assigned}/{total_players}\n\n"
        f"📝 **Текущий состав:**\n"
    )
    
    # Показываем текущий состав ролей
    for role in ALL_CONFIGURABLE_ROLES:
        count = current_roles.get(role, 0)
        if count > 0:
            message_text += f"• {role}: {count}\n"
    
    if current_assigned == 0:
        message_text += "*Роли не назначены*\n"
    
    message_text += (
        f"\n💡 **Используйте кнопки + и - для настройки количества каждой роли.**\n"
        f"📋 Нажмите на название роли для получения подробной информации."
    )
    
    keyboard = get_role_config_keyboard(pending_setup)
    
    if is_edit and hasattr(query_or_update, 'edit_message_text'):
        await query_or_update.edit_message_text(
            message_text,
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        if hasattr(query_or_update, 'message'):
            await query_or_update.message.reply_text(
                message_text,
                reply_markup=keyboard,
                parse_mode=ParseMode.MARKDOWN
            )
        else:
            await query_or_update.reply_text(
                message_text,
                reply_markup=keyboard,
                parse_mode=ParseMode.MARKDOWN
            )

async def create_game_with_manual_roles(query, context: CallbackContext, setup_data: dict, roles_list: list):
    """Создает игру с ручной настройкой ролей"""
    try:
        user = query.from_user
        
        # Генерируем ID игры
        game_id = "mafia_" + generate_id(6)
        
        # Подготавливаем имена и дела
        available_fictional_names = fictional_names_list.copy()
        random.shuffle(available_fictional_names)
        available_personal_cases = personal_cases.copy()
        random.shuffle(available_personal_cases)
        
        # Создаем слоты для игроков (роли уже перемешаны в roles_list)
        players_slots = []
        for i in range(len(roles_list)):
            player_role = roles_list[i]  # Роли уже в случайном порядке
            player_name = available_fictional_names[i % len(available_fictional_names)]
            player_case = available_personal_cases[i % len(available_personal_cases)]
            
            slot = {
                "role": player_role,
                "description": player_case,
                "fictional_name": player_name,
                "user_id": None,
                "_user_first_name": None,
                "status": STATUS_ACTIVE,
                "original_slot_index": i
            }
            players_slots.append(slot)
        
        # Создаем объект игры
        game_data = {
            'host_id': user.id,
            'host_name': user.full_name or "Аноним",
            'state': STATE_ROLES_DISTRIBUTED,
            'players_slots': players_slots,
            'num_players': len(roles_list),
            'game_mode': setup_data.get('game_mode', 'human_host'),
            'game_version': setup_data.get('game_version', 'paid'),
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'current_night_number': 0,
            'current_day_number': 0,
            'roles_manually_configured': True
        }
        
        # Сохраняем игру
        games[game_id] = game_data
        
        # Получаем имя бота для ссылки
        try:
            bot_info = await context.bot.get_me()
            bot_username = bot_info.username
            logger.info(f"[DEBUG] Получено имя бота из API для ручной игры: @{bot_username}")
        except Exception as e:
            logger.error(f"[ERROR] Ошибка при получении информации о боте для ручной игры: {e}")
            bot_username = "Mafia_IRL_Bot"
            logger.info(f"[DEBUG] Используется резервное имя бота для ручной игры: @{bot_username}")

        join_game_link = f"https://t.me/{bot_username}?start=join_{game_id}"
        
        # Определяем описание типа игры
        version = setup_data.get('game_version', 'paid')
        game_mode = setup_data.get('game_mode', 'human_host')
        
        if version == 'free':
            game_type_description = "🆓 Бесплатная игра"
        else:
            if game_mode == 'human_host':
                game_type_description = "💎 Платная игра (Ведущий - Я)"
            else:
                game_type_description = "🤖💎 Платная игра (Ведущий - Бот)"
        
        # Формируем сообщение для ведущего
        roles_summary = {}
        for role in roles_list:
            roles_summary[role] = roles_summary.get(role, 0) + 1
        
        roles_text = "\n".join([f"• {role}: {count}" for role, count in roles_summary.items()])
        
        message_text = (
            f"🎲 **Новая игра в Мафию создана!**\n\n"
            f"🆔 **ID игры:** `{game_id}`\n"
            f"🎮 **Тип игры:** {game_type_description}\n"
            f"👤 **Ведущий:** {user.first_name}\n"
            f"👥 **Количество игроков:** {len(roles_list)}\n"
            f"⚙️ **Настройка ролей:** Ручная\n\n"
            f"🎭 **Состав ролей:**\n{roles_text}\n\n"
            f"🔗 **ССЫЛКА ДЛЯ ИГРОКОВ:**\n"
            f"`{join_game_link}`\n\n"
            f"📤 Разошлите эту ссылку всем участникам.\n"
            f"🎭 Игроки получат роли автоматически."
        )
        
        # Создаем кнопки
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🎮 Присоединиться", callback_data=f"join_game_{game_id}")],
            [InlineKeyboardButton("📤 Поделиться игрой", callback_data=f"copy_link_{game_id}")]
        ])
        
        await query.edit_message_text(
            message_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=keyboard
        )
        
        # Отправляем детали ролей ведущему (если не бот-ведущий)
        if game_mode != 'bot_host':
            roles_details = ["🕵️ **Подготовленные роли и персонажи:**"]
            for i, slot in enumerate(players_slots):
                roles_details.append(
                    f"**Слот {i+1}:** {slot['fictional_name']} - {slot['role']} *(Ожидает игрока)*"
                )
            
            await context.bot.send_message(
                user.id,
                "\n".join(roles_details),
                parse_mode=ParseMode.MARKDOWN
            )
        
        # Очищаем настройки
        if 'pending_game_setup' in context.user_data:
            del context.user_data['pending_game_setup']
        
        logger.info(f"[DEBUG] Игра с ручной настройкой ролей создана с ID: {game_id}")
        return game_id
        
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        logger.error(f"Ошибка при создании игры с ручной настройкой: {str(e)}\n{error_details}")
        await query.edit_message_text(
            f"❌ **Произошла ошибка при создании игры.**\n\n"
            f"**Сообщение:** {str(e)}",
            parse_mode=ParseMode.MARKDOWN
        )
        # Очищаем настройки в случае ошибки
        if 'pending_game_setup' in context.user_data:
            del context.user_data['pending_game_setup']
        return None

async def handle_player_count_input(update: Update, context: CallbackContext):
    """Обработчик ввода количества игроков и ответов на математические примеры"""
    
    # Сначала проверяем, является ли это ответом на математический пример
    if await handle_math_answer(update, context):
        return  # Это был ответ на математический пример, обработка завершена
    
    user = update.effective_user
    message_text = update.message.text.strip()
    
    # Проверяем, ожидаем ли мы ввод количества игроков
    if context.user_data.get('game_setup_state') != 'waiting_player_count':
        return  # Игнорируем, если не в режиме ввода
    
    try:
        num_players = int(message_text)
    except ValueError:
        await update.message.reply_text(
            "❌ Пожалуйста, введите корректное число игроков.\n"
            "Например: `6`",
            parse_mode=ParseMode.MARKDOWN
        )
        return

    game_type = context.user_data.get('game_type', 'free')
    
    # Валидация количества игроков
    if game_type == 'free':
        if not (4 <= num_players <= 8):
            await update.message.reply_text(
                f"❌ В бесплатном режиме доступно от 4 до 8 игроков.\n"
                f"Вы ввели: {num_players}\n\n"
                f"Пожалуйста, введите число от 4 до 8."
            )
            return
        
        # Для бесплатного режима показываем выбор типа ведущего
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(f"👤 Я ведущий", 
                                callback_data=f"host_type_human_{num_players}_free")],
            [InlineKeyboardButton(f"🤖 Бот-ведущий", 
                                callback_data=f"host_type_bot_{num_players}_free")],

            [InlineKeyboardButton("🔙 Назад", callback_data="game_type_free")]
        ])
        
        # Очищаем состояние ввода
        context.user_data['game_setup_state'] = None
        
        await update.message.reply_text(
            f"🆓 **Бесплатная игра на {num_players} игроков**\n\n"
            f"Выберите тип ведущего:\n\n"
            f"🔹 **Базовые роли:** Мафиози, Комиссар, Доктор, Мирный житель\n"
            f"🔹 **Автоматическое распределение ролей**",
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN
        )
            
    elif game_type == 'premium':
        if not (4 <= num_players <= 20):
            await update.message.reply_text(
                f"❌ В премиум режиме доступно от 4 до 20 игроков.\n"
                f"Вы ввели: {num_players}\n\n"
                f"Пожалуйста, введите число от 4 до 20."
            )
            return
        
        # Для премиум режима показываем выбор типа ведущего
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(f"👤 Я ведущий", 
                                callback_data=f"host_type_human_{num_players}")],
            [InlineKeyboardButton(f"🤖 Бот-ведущий", 
                                callback_data=f"host_type_bot_{num_players}")],
            [InlineKeyboardButton("🔙 Назад", callback_data="game_type_premium")]
        ])
        
        # Очищаем состояние ввода
        context.user_data['game_setup_state'] = None
        
        await update.message.reply_text(
            f"💎 **Премиум игра на {num_players} игроков**\n\n"
            f"Выберите тип ведущего:",
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN
        )
            
    else:
        await update.message.reply_text("❌ Ошибка: неизвестный тип игры")
        context.user_data['game_setup_state'] = None

# === СИСТЕМА ВНУТРИИГРОВОГО ЧАТА ===

async def find_player_game_session(user_id: int) -> tuple:
    """Находит активную игровую сессию пользователя"""
    for game_id, game_data in games.items():
        if game_data.get('state') == 'finished':
            continue
            
        # Проверяем, участвует ли пользователь в этой игре
        for slot in game_data.get('players_slots', []):
            if slot.get('user_id') == user_id:
                return game_id, game_data, slot
    
    return None, None, None

async def find_all_player_game_sessions(user_id: int) -> list:
    """Находит ВСЕ активные игровые сессии пользователя"""
    active_sessions = []
    for game_id, game_data in games.items():
        if game_data.get('state') == 'finished':
            continue
            
        # Проверяем, участвует ли пользователь в этой игре
        for slot in game_data.get('players_slots', []):
            if slot.get('user_id') == user_id:
                active_sessions.append((game_id, game_data, slot))
                break
    
    return active_sessions

async def remove_player_from_game(user_id: int, game_id: str, context: CallbackContext):
    """Удаляет игрока из игры"""
    if game_id not in games:
        return False
    
    game_data = games[game_id]
    player_removed = False
    
    # Находим и удаляем игрока
    for slot in game_data.get('players_slots', []):
        if slot.get('user_id') == user_id:
            slot['user_id'] = None
            slot['_user_first_name'] = None
            slot['real_name'] = None
            player_removed = True
            break
    
    if player_removed:
        # Уведомляем хоста (если это режим human_host)
        if game_data.get('game_mode') == 'human_host':
            try:
                await context.bot.send_message(
                    game_data['host_id'],
                    f"⚠️ Игрок покинул игру {game_id}\n"
                    f"Освободился слот для нового игрока."
                )
            except:
                pass
    
    return player_removed

def can_player_send_message(game_data: dict, player_slot: dict) -> tuple:
    """Проверяет, может ли игрок отправлять сообщения в чат"""
    # Мертвые игроки не могут писать, но могут видеть чат
    if player_slot.get('status') != STATUS_ACTIVE:
        return False, "💀 Мертвые игроки не могут писать в чат, но могут наблюдать"
    
    game_state = game_data.get('state')
    player_role = player_slot.get('role')
    
    # Дневная фаза - все живые могут писать
    if game_state == STATE_DAY:
        return True, None
    
    # Ночная фаза - только мафия может писать
    if game_state == STATE_NIGHT:
        # Проверяем, является ли игрок мафией
        if player_role not in [ROLE_MAFIA_DON, ROLE_MAFIA]:
            return False, "🌙 Ночью могут общаться только члены мафии"
        
        # Мафия может общаться всю ночь (не привязываемся к конкретному ходу)
        return True, None
    
    # Другие состояния игры
    if game_state in [STATE_ROLES_DISTRIBUTED]:
        return False, "⏳ Чат будет доступен после начала игры"
    
    return False, "❌ Чат недоступен в текущем состоянии игры"

def format_chat_message(player_slot: dict, user: object, message_text: str) -> str:
    """Форматирует сообщение для отображения в чате"""
    fictional_name = player_slot.get('fictional_name', 'Неизвестный')
    telegram_name = user.first_name
    if user.last_name:
        telegram_name += f" {user.last_name}"
    
    # Добавляем username если есть
    username_part = f" (@{user.username})" if user.username else ""
    
    # Убираем markdown чтобы избежать ошибок парсинга
    return f"💬 {fictional_name} | {telegram_name}{username_part}:\n{message_text}"

async def send_message_to_game_participants(game_id: str, game_data: dict, formatted_message: str, sender_user_id: int, context: CallbackContext):
    """Отправляет сообщение всем участникам игры"""
    game_state = game_data.get('state')
    sender_role = None
    
    # Находим роль отправителя
    for slot in game_data.get('players_slots', []):
        if slot.get('user_id') == sender_user_id:
            sender_role = slot.get('role')
            break
    
    recipients = []
    
    # Определяем получателей в зависимости от фазы игры
    if game_state == STATE_DAY:
        # День - все игроки (живые + мертвые наблюдатели)
        recipients = [slot for slot in game_data.get('players_slots', []) 
                     if slot.get('user_id')]
    
    elif game_state == STATE_NIGHT and sender_role in [ROLE_MAFIA_DON, ROLE_MAFIA]:
        # Ночь - только члены мафии
        recipients = [slot for slot in game_data.get('players_slots', []) 
                     if (slot.get('user_id') and 
                         slot.get('status') == STATUS_ACTIVE and 
                         slot.get('role') in [ROLE_MAFIA_DON, ROLE_MAFIA])]
    
    # Отправляем сообщение всем получателям (кроме отправителя)
    for slot in recipients:
        user_id = slot.get('user_id')
        if user_id != sender_user_id:  # Не отправляем сообщение самому себе
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=formatted_message,
                    parse_mode=None  # Убираем markdown парсинг для избежания ошибок
                )
            except Exception as e:
                print(f"❌ Ошибка отправки сообщения пользователю {user_id}: {e}")

async def handle_game_chat_message(update: Update, context: CallbackContext):
    """Обработчик сообщений в игровом чате"""
    user_id = update.effective_user.id
    message_text = update.message.text
    
    # Находим игровую сессию пользователя
    game_id, game_data, player_slot = await find_player_game_session(user_id)
    
    if not game_data:
        # Если пользователь не в игре, возможно это ввод количества игроков
        await handle_player_count_input(update, context)
        return
        
    # Проверяем, если пользователь в таймер-игре (ожидает старта)
    if game_data.get('state') == STATE_TIMER_WAITING:
        await update.message.reply_text(
            "⏰ Вы находитесь в режиме ожидания таймер-игры!\n\n"
            "Чтобы создать новую игру, сначала покиньте текущую.\n"
            "Используйте команду /start и выберите 'Покинуть игру'."
        )
        return
    
    # Проверяем, может ли игрок отправлять сообщения
    can_send, error_message = can_player_send_message(game_data, player_slot)
    
    # Особая логика для мертвых игроков - проверяем предсмертную записку
    if not can_send and player_slot.get('status') != STATUS_ACTIVE:
        # Проверяем, не оставлял ли игрок уже предсмертную записку
        if not player_slot.get('death_note_sent', False):
            # Отправляем предсмертную записку
            player_slot['death_note_sent'] = True
            games[game_id] = game_data
            
            # Форматируем сообщение
            fictional_name = player_slot.get('fictional_name', 'Неизвестный')
            telegram_name = update.effective_user.first_name
            if update.effective_user.last_name:
                telegram_name += f" {update.effective_user.last_name}"
            username_part = f" (@{update.effective_user.username})" if update.effective_user.username else ""
            
            death_note_message = (
                f"💀📜 **ПРЕДСМЕРТНАЯ ЗАПИСКА**\n\n"
                f"От: {fictional_name} | {telegram_name}{username_part}\n\n"
                f"'{message_text}'\n\n"
                f"🕊️ _Последние слова из загробного мира..._"
            )
            
            # Отправляем всем живым игрокам
            for slot in game_data.get('players_slots', []):
                if (slot.get('user_id') and 
                    slot.get('status') == STATUS_ACTIVE and 
                    slot.get('user_id') != user_id):
                    try:
                        await context.bot.send_message(
                            slot['user_id'],
                            death_note_message,
                            parse_mode=ParseMode.MARKDOWN
                        )
                    except Exception as e:
                        logger.error(f"Error sending death note to player {slot['user_id']}: {e}")
            
            # Подтверждаем отправку
            await update.message.reply_text(
                "📜 **Предсмертная записка отправлена!**\n\n"
                "Ваше последнее сообщение доставлено всем живым игрокам.\n"
                "Теперь вы можете только наблюдать за игрой."
            )
            return
        else:
            await update.message.reply_text(
                "💀 Вы уже оставили предсмертную записку.\n"
                "Мертвые могут только наблюдать за игрой."
            )
            return
    
    if not can_send:
        await update.message.reply_text(error_message)
        return
    
    # Форматируем сообщение
    formatted_message = format_chat_message(player_slot, update.effective_user, message_text)
    
    # Отправляем сообщение участникам (без фазового индикатора)
    await send_message_to_game_participants(game_id, game_data, formatted_message, user_id, context)
    
    # Подтверждаем отправку отправителю
    game_state = game_data.get('state')
    if game_state == STATE_DAY:
        confirmation_text = "✅ Сообщение отправлено всем живым игрокам"
    elif game_state == STATE_NIGHT:
        confirmation_text = "✅ Сообщение отправлено членам мафии"
    else:
        confirmation_text = "✅ Сообщение отправлено"
    
    # Отправляем подтверждение и удаляем его через 2 секунды
    confirmation_message = await update.message.reply_text(confirmation_text)
    
    # Планируем удаление сообщения через 2 секунды
    async def delete_confirmation():
        import asyncio
        await asyncio.sleep(2)
        try:
            await context.bot.delete_message(
                chat_id=confirmation_message.chat_id,
                message_id=confirmation_message.message_id
            )
        except:
            pass  # Игнорируем ошибки удаления (сообщение уже могло быть удалено)
    
    # Запускаем удаление в фоне
    import asyncio
    asyncio.create_task(delete_confirmation())

def main():
    """Запуск бота"""
    print("🚀 Запускаем Telegram-бота Мафия...")
    print("✅ Токен настроен, начинаем инициализацию...")
    
    # Инициализация приложения с поддержкой прокси
    # Если нужен прокси, раскомментируйте и настройте следующие строки:
    # proxy_url = "http://your-proxy-server:port"  # Замените на ваш прокси
    # application = ApplicationBuilder().token(TOKEN).proxy_url(proxy_url).build()
    
    # Инициализация приложения без прокси (по умолчанию)
    application = ApplicationBuilder().token(TOKEN).build()
    
    # Регистрация обработчиков
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("manage", manage_game_command))
    application.add_handler(CommandHandler("premium", premium_command))
    application.add_handler(CommandHandler("premium_admin", premium_admin_command))
    application.add_handler(CommandHandler("demo", activate_demo_command))
    application.add_handler(CallbackQueryHandler(button_callback_handler))
    
    # ВАЖНО: Обработчик игрового чата должен быть ДО обработчика ввода количества игроков
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_game_chat_message))
    
    # Добавляем обработчики платежей
    application.add_handler(PreCheckoutQueryHandler(precheckout_callback))
    application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment_callback))
    
    # Запуск бота
    print("🎭 Бот Мафия успешно запущен и готов к работе!")
    print("💬 Система внутриигрового чата активна!")
    application.run_polling()

async def check_bot_info():
    """Проверяет информацию о боте по токену"""
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            url = f"https://api.telegram.org/bot{TOKEN}/getMe"
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    bot_info = data.get('result', {})
                    print(f"🤖 Информация о боте:")
                    print(f"   ID: {bot_info.get('id')}")
                    print(f"   Имя: {bot_info.get('first_name')}")
                    print(f"   Username: @{bot_info.get('username')}")
                    print(f"   Это бот: {bot_info.get('is_bot')}")
                    return bot_info.get('username')
                else:
                    print(f"❌ Ошибка API: {response.status}")
                    return None
    except Exception as e:
        print(f"❌ Ошибка при проверке бота: {e}")
        return None

# === СИСТЕМА УПРАВЛЕНИЯ ДЛЯ ЧЕЛОВЕКА-ВЕДУЩЕГО ===

def get_main_control_keyboard(game_id: str) -> InlineKeyboardMarkup:
    """Основная клавиатура управления игрой для ведущего"""
    keyboard = [
        [InlineKeyboardButton("🌃 Объявить Ночь", callback_data=f"night_{game_id}"),
         InlineKeyboardButton("☀️ Объявить День", callback_data=f"day_{game_id}")],
        [InlineKeyboardButton("🔪 Исключить Игрока", callback_data=f"show_elim_list_{game_id}")],
        [InlineKeyboardButton("📊 Статус Игры", callback_data=f"status_{game_id}"),
         InlineKeyboardButton("🛑 Завершить Игру", callback_data=f"end_{game_id}")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_player_elimination_keyboard(game_id: str, game_data: dict) -> InlineKeyboardMarkup:
    """Клавиатура для выбора игрока для исключения"""
    active_players = [slot for slot in game_data.get('players_slots', []) 
                     if slot.get('user_id') and slot.get('status') == STATUS_ACTIVE]
    
    buttons = []
    for slot in sorted(active_players, key=lambda x: x.get('player_number_for_host', 0)):
        player_num = slot.get('player_number_for_host', 0)
        name = get_player_display_name(slot)
        buttons.append(InlineKeyboardButton(f"{player_num}. {name}", 
                                          callback_data=f"elim_{game_id}_{player_num}"))
    
    # Группируем кнопки по 2 в ряду
    keyboard_rows = []
    for i in range(0, len(buttons), 2):
        keyboard_rows.append(buttons[i:i+2])
    
    keyboard_rows.append([InlineKeyboardButton("🔙 Назад к управлению", callback_data=f"manage_{game_id}")])
    return InlineKeyboardMarkup(keyboard_rows)

def get_night_host_keyboard(game_id: str, game_data: dict) -> InlineKeyboardMarkup:
    """Клавиатура для управления ночными действиями"""
    keyboard_rows = []
    night_data = game_data.get("night_data", {})
    roles_to_act = night_data.get("roles_to_act", [])
    acted_roles = night_data.get("acted_roles", set())
    actions_taken = night_data.get("actions_taken_by_role", {})

    role_display_names = {
        "Мафия": "Мафия", "Доктор": "Доктор", "Комиссар": "Комиссар", 
        "Маньяк": "Маньяк", "Путана": "Путана"
    }

    buttons_for_roles = []
    for role_key in roles_to_act:
        display_name = role_display_names.get(role_key, role_key)
        if role_key in acted_roles:
            target_num = actions_taken.get(role_key)
            target_name = ""
            if target_num is not None:
                for slot in game_data.get("players_slots", []):
                    if slot.get("player_number_for_host") == target_num:
                        target_name = f" ({slot.get('fictional_name', '')})"
                        break
            buttons_for_roles.append(
                InlineKeyboardButton(f"✅ {display_name} (выбрал {target_num}{target_name})", 
                                   callback_data=f"night_info_{game_id}_{role_key}")
            )
        else:
            buttons_for_roles.append(
                InlineKeyboardButton(f"➡️ Ход: {display_name}", 
                                   callback_data=f"night_role_turn_{game_id}_{role_key}")
            )

    # Группируем кнопки по 2 в ряду
    for i in range(0, len(buttons_for_roles), 2):
        keyboard_rows.append(buttons_for_roles[i:i+2])

    keyboard_rows.append([InlineKeyboardButton("☀️ Завершить ночь и начать день", callback_data=f"night_end_{game_id}")])
    return InlineKeyboardMarkup(keyboard_rows)

def get_player_selection_keyboard_for_night_action(game_id: str, game_data: dict, acting_role_key: str) -> InlineKeyboardMarkup:
    """Клавиатура для выбора цели ночного действия"""
    keyboard_rows = []
    
    # Получаем активных игроков
    active_players = [slot for slot in game_data.get('players_slots', []) 
                     if slot.get('user_id') and slot.get('status') == STATUS_ACTIVE]
    
    # Находим действующего игрока (для проверки самовыбора)
    acting_player = None
    for slot in active_players:
        if acting_role_key == "Мафия" and slot.get('role') in ["Дон Мафии", "Мафиози"]:
            acting_player = slot
            break
        elif slot.get('role') == acting_role_key:
            acting_player = slot
            break
    
    buttons = []
    for slot in sorted(active_players, key=lambda x: x.get('player_number_for_host', 0)):
        player_num = slot.get('player_number_for_host', 0)
        name = get_player_display_name(slot)
        
        # Некоторые роли не могут выбирать себя
        if (acting_player and 
            player_num == acting_player.get('player_number_for_host') and 
            acting_role_key in ["Мафия", "Путана", "Маньяк"]):
            continue
            
        buttons.append(InlineKeyboardButton(f"{player_num}. {name}", 
                                          callback_data=f"night_action_{game_id}_{acting_role_key}_{player_num}"))
    
    # Группируем кнопки по 2 в ряду
    for i in range(0, len(buttons), 2):
        keyboard_rows.append(buttons[i:i+2])
    
    keyboard_rows.append([InlineKeyboardButton("🔙 Назад к выбору роли", callback_data=f"night_return_to_main_{game_id}")])
    return InlineKeyboardMarkup(keyboard_rows)

async def manage_game_command(update: Update, context: CallbackContext):
    """Команда /manage для управления игрой"""
    user_id = update.effective_user.id
    game_id_arg = context.args[0] if context.args else None
    
    # Ищем игру пользователя
    host_games = [gid for gid, gdata in games.items() 
                  if gdata.get('host_id') == user_id and gdata.get('state') != 'finished']
    
    if not host_games:
        await update.message.reply_text("У вас нет активных игр. Создайте новую игру через главное меню.")
        return
    
    if len(host_games) > 1 and not game_id_arg:
        games_list = "\n".join([f"• {gid}" for gid in host_games])
        await update.message.reply_text(f"У вас несколько активных игр:\n{games_list}\n\nУкажите ID: /manage <ID_игры>")
        return
    
    game_id = game_id_arg or host_games[0]
    
    if game_id not in games:
        await update.message.reply_text(f"Игра {game_id} не найдена.")
        return
    
    game_data = games[game_id]
    
    if game_data.get('host_id') != user_id:
        await update.message.reply_text("Вы не являетесь ведущим этой игры.")
        return
    
    # Проверяем режим игры
    if game_data.get('game_mode') == 'bot_host':
        await update.message.reply_text("❌ В режиме 'Бот-ведущий' управление происходит автоматически.")
        return
    
    await update.message.reply_text(f"Управление игрой {game_id}:", 
                                  reply_markup=get_main_control_keyboard(game_id))

async def set_night_action(game_id: str, game_data: dict, query, context: CallbackContext):
    """Переключение в ночную фазу"""
    game_data["current_night_number"] = game_data.get("current_night_number", 0) + 1
    game_data["state"] = STATE_NIGHT
    
    # Инициализация ночных данных
    active_roles = set()
    for slot in game_data.get("players_slots", []):
        if slot.get("user_id") and slot.get("status") == STATUS_ACTIVE:
            role = slot["role"]
            if role in ["Дон Мафии", "Мафиози"]:
                active_roles.add("Мафия")
            elif role in ["Доктор", "Комиссар", "Маньяк", "Путана"]:
                active_roles.add(role)
    
    game_data["night_data"] = {
        "actions_taken_by_role": {},
        "roles_to_act": list(active_roles),
        "acted_roles": set(),
        "commissioner_check_result": None,
    }
    
    games[game_id] = game_data
    
    message = f"🌃 Ночь {game_data['current_night_number']} в игре {game_id}. Выберите роли для действий:"
    await query.edit_message_text(text=message, reply_markup=get_night_host_keyboard(game_id, game_data))

async def set_day_action(game_id: str, game_data: dict, query, context: CallbackContext):
    """Переключение в дневную фазу"""
    if game_data.get('state') == STATE_DAY:
        await query.answer('Игра уже в дневной фазе.', show_alert=True)
        return
    
    game_data['state'] = STATE_DAY
    game_data["current_day_number"] = game_data.get("current_day_number", 0) + 1
    games[game_id] = game_data
    
    await query.edit_message_text(f'☀️ День {game_data["current_day_number"]} объявлен в игре {game_id}.', 
                                reply_markup=get_main_control_keyboard(game_id))
    await query.answer('День объявлен.')

async def eliminate_player_action(game_id: str, game_data: dict, player_number: int, query, context: CallbackContext):
    """Исключение игрока"""
    for slot in game_data.get("players_slots", []):
        if slot.get("player_number_for_host") == player_number and slot.get("user_id"):
            if slot.get("status") == STATUS_ELIMINATED:
                await query.answer(f"Игрок {player_number} уже исключен.", show_alert=True)
                return False
            
            slot["status"] = STATUS_ELIMINATED
            name = slot.get('fictional_name', f'Игрок {player_number}')
            role = slot.get('role', 'Неизвестно')
            
            # Уведомляем о исключении
            elimination_message = f"🔪 {name} (роль: {role}) исключен из игры {game_id}."
            await context.bot.send_message(chat_id=query.message.chat.id, text=elimination_message)
            
            games[game_id] = game_data
            
            # Возвращаемся к управлению
            await query.edit_message_text(f"Управление игрой {game_id}:", 
                                        reply_markup=get_main_control_keyboard(game_id))
            return True
    
    await query.answer("Игрок не найден.", show_alert=True)
    return False

async def game_status_action(game_id: str, game_data: dict, query, context: CallbackContext):
    """Показ статуса игры"""
    active_count = len([s for s in game_data.get('players_slots', []) 
                       if s.get('user_id') and s.get('status') == STATUS_ACTIVE])
    total_count = game_data.get('num_players', 0)
    
    status_message = (f"📊 Статус игры {game_id}\n"
                     f"Состояние: {game_data.get('state', 'Неизвестно')}\n"
                     f"День: {game_data.get('current_day_number', 0)}\n"
                     f"Ночь: {game_data.get('current_night_number', 0)}\n"
                     f"Активных игроков: {active_count}/{total_count}\n\n"
                     f"Игроки:\n")
    
    for slot in sorted(game_data.get('players_slots', []), 
                      key=lambda x: x.get('player_number_for_host', 0)):
        if slot.get('user_id'):
            num = slot.get('player_number_for_host', 0)
            name = slot.get('fictional_name', f'Игрок {num}')
            role = slot.get('role', 'Неизвестно')
            status = "🟢" if slot.get('status') == STATUS_ACTIVE else "🔴"
            status_message += f"{status} {num}. {name} - {role}\n"
    
    await query.answer(status_message, show_alert=True)

async def end_game_action(game_id: str, game_data: dict, query, context: CallbackContext):
    """Завершение игры"""
    game_data['state'] = 'finished'
    games[game_id] = game_data
    
    await query.edit_message_text(f"🛑 Игра {game_id} завершена ведущим.")
    await query.answer("Игра завершена.")

async def get_detailed_night_summary_for_host(game_id: str, game_data: dict, actions: dict) -> str:
    """Формирует красивую атмосферную сводку ночных действий для ведущего"""
    night_number = game_data.get("current_night_number", 0)
    summary = f"🌃 **НОЧНАЯ ХРОНИКА #{night_number}**\n\n"
    
    # Функция для получения имени игрока по номеру
    def get_player_name_by_number(player_num):
        for slot in game_data.get("players_slots", []):
            if slot.get("player_number_for_host") == player_num:
                return slot.get('fictional_name', f'Игрок {player_num}')
        return f"Игрок {player_num}"
    
    # Функция для получения роли игрока по номеру
    def get_player_role_by_number(player_num):
        for slot in game_data.get("players_slots", []):
            if slot.get("player_number_for_host") == player_num:
                return slot.get('role', 'Неизвестно')
        return "Неизвестно"
    
    night_events = []
    
    # Действия Мафии - драматично
    if "Мафия" in actions:
        target_num = actions["Мафия"]
        target_name = get_player_name_by_number(target_num)
        night_events.append(
            f"🔪 **В темных переулках города раздались тихие шаги...**\n"
            f"   Мафия выбрала свою жертву: **{target_name}** (#{target_num})\n"
            f"   *Холодный металл блеснул в лунном свете...*"
        )
    
    # Действия Доктора - героично
    if "Доктор" in actions:
        target_num = actions["Доктор"]
        target_name = get_player_name_by_number(target_num)
        night_events.append(
            f"🏥 **Сквозь ночную тишину прокрались спасительные шаги...**\n"
            f"   Доктор защитил: **{target_name}** (#{target_num})\n"
            f"   *Медицинская сумка тихо звякнула в темноте...*"
        )
    
    # Действия Комиссара - детективно
    if "Комиссар" in actions:
        target_num = actions["Комиссар"]
        target_name = get_player_name_by_number(target_num)
        target_role = get_player_role_by_number(target_num)
        is_mafia = target_role in ["Дон Мафии", "Мафиози"]
        result = "🔴 МАФИЯ" if is_mafia else "🟢 МИРНЫЙ ЖИТЕЛЬ"
        night_events.append(
            f"🕵️ **Детектив вел свое расследование в ночной тени...**\n"
            f"   Комиссар проверил: **{target_name}** (#{target_num})\n"
            f"   *Результат расследования: {result}*\n"
            f"   *Блокнот детектива пополнился новой записью...*"
        )
    
    # Действия Маньяка - зловеще
    if "Маньяк" in actions:
        target_num = actions["Маньяк"]
        target_name = get_player_name_by_number(target_num)
        night_events.append(
            f"🔥 **Безумный смех прозвучал в ночной тишине...**\n"
            f"   Маньяк выбрал свою жертву: **{target_name}** (#{target_num})\n"
            f"   *Хаос и безумие воцарились в темных улицах...*"
        )
    
    # Действия Путаны - загадочно
    if "Путана" in actions:
        target_num = actions["Путана"]
        target_name = get_player_name_by_number(target_num)
        target_role = get_player_role_by_number(target_num)
        night_events.append(
            f"🚫 **Чарующий силуэт скользнул по ночным улицам...**\n"
            f"   Путана очаровала: **{target_name}** (#{target_num})\n"
            f"   *Роль жертвы: {target_role}*\n"
            f"   *Магические чары на эту ночь лишили цель способностей...*"
        )
    
    if night_events:
        summary += "\n\n".join(night_events)
        summary += "\n\n" + "─" * 30
        summary += "\n\n🎭 **ДЛЯ ЗАЧИТЫВАНИЯ ИГРОКАМ:**\n"
        summary += "*Используйте эту информацию для создания атмосферы*"
    else:
        summary += "🌙 **Ночь окутала город покровом тишины...**\n"
        summary += "😴 *Никто не решился нарушить мирный сон жителей.*\n\n"
        summary += "🎭 **ДЛЯ ЗАЧИТЫВАНИЯ:** 'Ночь прошла спокойно...'"
    
    summary += "\n\n📋 **Эта информация предназначена только для вас как ведущего.**"
    
    return summary

async def resolve_night_actions_and_announce_day(game_id: str, game_data: dict, query, context: CallbackContext):
    """Обработка результатов ночи и переход к дню в режиме человека-ведущего"""
    night_data = game_data.get("night_data", {})
    actions = night_data.get("actions_taken_by_role", {})
    
    # СНАЧАЛА отправляем подробную сводку ведущему
    try:
        detailed_summary = await get_detailed_night_summary_for_host(game_id, game_data, actions)
        await context.bot.send_message(
            chat_id=query.from_user.id,
            text=detailed_summary,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error sending detailed night summary to host: {e}")
    
    # Обрабатываем действия
    killed_players = []
    saved_players = []
    commissioner_result = ""
    
    # Убийства (Мафия, Маньяк)
    if "Мафия" in actions:
        killed_players.append(actions["Мафия"])
    if "Маньяк" in actions:
        killed_players.append(actions["Маньяк"])
    
    # Спасение доктором
    if "Доктор" in actions:
        doctor_target = actions["Доктор"]
        if doctor_target in killed_players:
            killed_players.remove(doctor_target)
            saved_players.append(doctor_target)
    
    # Проверка комиссара
    if "Комиссар" in actions:
        commissioner_target = actions["Комиссар"]
        target_slot = None
        for slot in game_data.get("players_slots", []):
            if slot.get("player_number_for_host") == commissioner_target:
                target_slot = slot
                break
        
        if target_slot:
            target_name = target_slot.get('fictional_name', f'Игрок {commissioner_target}')
            target_role = target_slot.get('role', '')
            is_mafia = target_role in ["Дон Мафии", "Мафиози"]
            commissioner_result = f"Комиссар проверил {target_name}: {'Мафия' if is_mafia else 'Мирный житель'}"
    
    # Блокировка путаной (не влияет на результаты, только информация)
    blocked_info = ""
    if "Путана" in actions:
        blocked_target = actions["Путана"]
        for slot in game_data.get("players_slots", []):
            if slot.get("player_number_for_host") == blocked_target:
                blocked_name = slot.get('fictional_name', f'Игрок {blocked_target}')
                blocked_info = f"Путана заблокировала {blocked_name}"
                break
    
    # Применяем убийства
    for player_num in killed_players:
        for slot in game_data.get("players_slots", []):
            if slot.get("player_number_for_host") == player_num:
                slot["status"] = STATUS_ELIMINATED
                break
    
    # Переходим к дню
    game_data["state"] = STATE_DAY
    game_data["current_day_number"] = game_data.get("current_day_number", 0) + 1
    
    # Очищаем ночные данные
    if "night_data" in game_data:
        del game_data["night_data"]
    
    games[game_id] = game_data
    
    # Формируем сообщение о результатах ночи
    results_message = f"☀️ Наступил день {game_data['current_day_number']} в игре {game_id}!\n\n"
    
    if killed_players:
        results_message += "💀 Этой ночью погибли:\n"
        for player_num in killed_players:
            for slot in game_data.get("players_slots", []):
                if slot.get("player_number_for_host") == player_num:
                    name = slot.get('fictional_name', f'Игрок {player_num}')
                    role = slot.get('role', 'Неизвестно')
                    results_message += f"• {name} (роль: {role})\n"
        results_message += "\n"
    else:
        results_message += "🛡️ Этой ночью никто не погиб.\n\n"
    
    if saved_players:
        results_message += "🏥 Доктор спас игрока от смерти!\n\n"
    
    if commissioner_result:
        results_message += f"🕵️ {commissioner_result}\n\n"
    
    if blocked_info:
        results_message += f"🚫 {blocked_info}\n\n"
    
    # Отправляем результаты ведущему
    await query.edit_message_text(results_message + "Управление игрой:", 
                                reply_markup=get_main_control_keyboard(game_id))
    
    # Уведомляем всех игроков о наступлении дня (ОБЕЗЛИЧЕННЫЕ СООБЩЕНИЯ)
    public_message = f"☀️ Наступил день {game_data['current_day_number']}!\n\n"
    
    if killed_players:
        # Обезличенное сообщение об убийствах
        death_count = len(killed_players)
        if death_count == 1:
            public_message += "💀 Этой ночью кто-то был жестоко убит...\n"
            public_message += "🔍 Жители города обнаружили тело на рассвете."
        else:
            public_message += f"💀 Этой ночью {death_count} человека погибли...\n"
            public_message += "😱 Город охватил ужас от множественных убийств."
    elif saved_players:
        # Если доктор спас, но никто не умер
        public_message += "🌅 Ночь прошла относительно спокойно...\n"
        public_message += "🏥 Кто-то слышал шаги врача в темноте."
    else:
        # Никто не умер и никого не спасали
        mysterious_messages = [
            "🌙 Ночь прошла в тревожном молчании...",
            "😴 Город спал беспокойным сном...", 
            "🌫️ В тумане ночи ничего не произошло...",
            "🦉 Только совы были свидетелями тайн этой ночи...",
            "⭐ Звезды хранят секреты прошедшей ночи..."
        ]
        import random
        public_message += random.choice(mysterious_messages)
    
    # Отправляем всем игрокам
    for slot in game_data.get("players_slots", []):
        if slot.get("user_id"):
            try:
                await context.bot.send_message(slot["user_id"], public_message)
            except:
                pass

    # Запускаем дневное голосование через 2 минуты
    import asyncio
    asyncio.create_task(start_day_voting_after_delay(game_id, context))

    games[game_id] = game_data

# === КОНЕЦ СИСТЕМЫ УПРАВЛЕНИЯ ===

async def handle_premium_purchase(update: Update, context: CallbackContext):
    """Обработчик покупки премиум доступа"""
    user = update.effective_user
    query = update.callback_query if update.callback_query else None
    
    # Создаем инвойс для покупки премиума
    title = "💎 Премиум доступ к боту Мафия"
    description = (
        "🎮 До 20 игроков\n"
        "🤖 Ведущий-бот\n" 
        "🎭 Все роли\n"
        "⚙️ Ручная настройка\n"
        "📊 Статистика"
    )
    
    payload = f"premium_user_{user.id}"
    currency = "RUB"
    prices = [LabeledPrice("Премиум доступ", PREMIUM_PRICE_KOPECKS)]
    
    try:
        await context.bot.send_invoice(
            chat_id=user.id,
            title=title,
            description=description,
            payload=payload,
            provider_token=PAYMENT_PROVIDER_TOKEN,
            currency=currency,
            prices=prices,
            start_parameter="premium_purchase",
            # Убираем проблемные параметры изображения
            need_email=False,
            need_phone_number=False,
            need_shipping_address=False,
            send_phone_number_to_provider=False,
            send_email_to_provider=False,
            is_flexible=False
        )
        
        if query:
            await query.answer("Инвойс отправлен в личные сообщения!")
            
    except Exception as e:
        logger.error(f"Error sending invoice: {e}")
        if query:
            await query.answer("Ошибка при создании платежа", show_alert=True)

async def precheckout_callback(update: Update, context: CallbackContext):
    """Обработчик предварительной проверки платежа"""
    query = update.pre_checkout_query
    
    # Проверяем payload
    if query.invoice_payload.startswith("premium_user_"):
        # Подтверждаем платеж
        await query.answer(ok=True)
        logger.info(f"Pre-checkout approved for user {query.from_user.id}")
    else:
        # Отклоняем платеж
        await query.answer(ok=False, error_message="Неверный payload платежа")
        logger.error(f"Invalid payload in pre-checkout: {query.invoice_payload}")

async def successful_payment_callback(update: Update, context: CallbackContext):
    """Обработчик успешного платежа"""
    user = update.effective_user
    payment = update.message.successful_payment
    
    logger.info(f"Successful payment from user {user.id}: {payment.total_amount} {payment.currency}")
    
    # Активируем премиум для пользователя (30 дней)
    success = premium_db.add_premium_user(
        user.id, 
        transaction_id=payment.telegram_payment_charge_id,
        duration_days=30
    )
    
    if success:
        # Получаем информацию о подписке
        user_info = premium_db.get_user_info(user.id)
        expire_date = user_info.get("expires_at", "")
        if expire_date:
            from datetime import datetime
            try:
                expire_dt = datetime.fromisoformat(expire_date)
                expire_str = expire_dt.strftime("%d.%m.%Y")
            except:
                expire_str = "30 дней"
        else:
            expire_str = "30 дней"
        
        # Отправляем подтверждение
        await update.message.reply_text(
            f"🎉 **Поздравляем с покупкой премиума!**\n\n"
            f"💎 Теперь вам доступны все возможности:\n"
            f"• 🎮 Игры до 20 игроков\n"
            f"• 🤖 Ведущий-бот\n" 
            f"• 🎭 Все роли\n"
            f"• ⚙️ Ручная настройка ролей\n\n"
            f"📅 **Действительно до**: {expire_str}\n"
            f"📄 **Чек платежа**: `{payment.telegram_payment_charge_id}`",
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        await update.message.reply_text(
            "❌ **Ошибка активации премиума**\n\n"
            "Платеж получен, но произошла ошибка при активации подписки. "
            "Обратитесь в поддержку для решения проблемы.",
            parse_mode=ParseMode.MARKDOWN
        )

# Импортируем новую систему управления премиум-подписками
from premium_database import premium_db

def check_premium_status(user_id: int):
    """Проверяет премиум статус пользователя (используя новую базу данных)"""
    return premium_db.check_premium_status(user_id)

async def activate_demo_command(update: Update, context: CallbackContext):
    """Команда активации 14-дневной демо-версии"""
    user_id = update.effective_user.id
    
    # Проверяем, может ли пользователь активировать демо
    if not premium_db.can_activate_demo(user_id):
        is_premium, status = premium_db.check_premium_status(user_id)
        user_data = premium_db.get_user_info(user_id)
        
        if user_data and user_data.get("demo_used", False):
            await update.message.reply_text(
                "❌ **Вы уже использовали демо-версию ранее**\n\n"
                "💎 Для получения полного доступа к премиум-функциям воспользуйтесь командой /premium",
                parse_mode='Markdown'
            )
        elif is_premium:
            if status == "demo":
                expire_str = user_data.get("expires_at") if user_data else None
                if expire_str:
                    try:
                        from datetime import datetime
                        expire_time = datetime.fromisoformat(expire_str)
                        await update.message.reply_text(
                            f"🎯 **У вас уже активна демо-версия**\n\n"
                            f"⏰ Действует до: {expire_time.strftime('%d.%m.%Y в %H:%M')}\n\n"
                            f"💎 Для безлимитного доступа используйте /premium",
                            parse_mode='Markdown'
                        )
                    except ValueError:
                        await update.message.reply_text("❌ У вас уже активна демо-версия")
                else:
                    await update.message.reply_text("❌ У вас уже активна демо-версия")
            else:
                await update.message.reply_text("💎 **У вас уже есть премиум-подписка!**")
        return
    
    # Активируем демо
    success, message = premium_db.activate_demo(user_id)
    
    if success:
        await update.message.reply_text(
            f"{message}\n\n"
            "🎮 **Доступные премиум-функции:**\n"
            "• Игры от 4 до 20 игроков\n"
            "• Все роли (Маньяк, Комиссар, Проститутка и др.)\n"
            "• Расширенная статистика\n"
            "• Приоритетная поддержка\n\n"
            "💡 **Совет:** Попробуйте создать игру на 10+ игроков с полным набором ролей!\n\n"
            "💎 Понравилось? Получите безлимитный доступ: /premium",
            parse_mode='Markdown'
        )
    else:
        await update.message.reply_text(message)

async def premium_admin_command(update: Update, context: CallbackContext):
    """Команда администрирования премиум-подписок"""
    user_id = update.effective_user.id
    
    # Список администраторов (замените на ваши ID)
    ADMIN_IDS = [627786969]  # Замените на ваш Telegram ID
    
    if user_id not in ADMIN_IDS:
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды")
        return
    
    args = context.args
    if not args:
        # Показываем статистику
        stats = premium_db.get_stats()
        
        message = (
            f"📊 **Статистика подписок**\n\n"
            f"👥 Всего пользователей: **{stats['total_users']}**\n"
            f"💎 Активные премиум: **{stats['active_premium']}**\n"
            f"🎯 Активные демо: **{stats['active_demo']}**\n"
            f"🧪 Использовали демо: **{stats['demo_used_total']}**\n"
            f"⏰ Истекшие: **{stats['expired_premium']}**\n"
            f"🆓 Бесплатные: **{stats['free_users']}**\n\n"
            f"**Команды:**\n"
            f"`/premium_admin add USER_ID DAYS` - добавить подписку\n"
            f"`/premium_admin demo USER_ID` - активировать демо\n"
            f"`/premium_admin extend USER_ID DAYS` - продлить подписку\n"
            f"`/premium_admin check USER_ID` - проверить статус\n"
            f"`/premium_admin cleanup` - очистить истекшие\n"
            f"`/premium_admin stats` - показать статистику"
        )
        
        await update.message.reply_text(message, parse_mode=ParseMode.MARKDOWN)
        return
    
    command = args[0].lower()
    
    if command == "add" and len(args) >= 3:
        try:
            target_user_id = int(args[1])
            days = int(args[2])
            success = premium_db.add_premium_user(target_user_id, duration_days=days)
            
            if success:
                await update.message.reply_text(f"✅ Добавлена премиум-подписка для пользователя {target_user_id} на {days} дней")
            else:
                await update.message.reply_text(f"❌ Ошибка добавления подписки для пользователя {target_user_id}")
        except ValueError:
            await update.message.reply_text("❌ Неверный формат команды. Используйте: /premium_admin add USER_ID DAYS")
    
    elif command == "demo" and len(args) >= 2:
        try:
            target_user_id = int(args[1])
            success, message = premium_db.activate_demo(target_user_id)
            
            if success:
                await update.message.reply_text(f"✅ Демо активировано для {target_user_id}\n{message}")
            else:
                await update.message.reply_text(f"❌ Ошибка активации демо: {message}")
        except ValueError:
            await update.message.reply_text("❌ Неверный ID пользователя")
    
    elif command == "extend" and len(args) >= 3:
        try:
            target_user_id = int(args[1])
            days = int(args[2])
            success = premium_db.extend_premium(target_user_id, days)
            
            if success:
                await update.message.reply_text(f"✅ Продлена премиум-подписка для пользователя {target_user_id} на {days} дней")
            else:
                await update.message.reply_text(f"❌ Ошибка продления подписки для пользователя {target_user_id}")
        except ValueError:
            await update.message.reply_text("❌ Неверный формат команды. Используйте: /premium_admin extend USER_ID DAYS")
    
    elif command == "check" and len(args) >= 2:
        try:
            target_user_id = int(args[1])
            user_info = premium_db.get_user_info(target_user_id)
            
            if user_info:
                is_premium, status = premium_db.check_premium_status(target_user_id)
                expire_date = user_info.get("expires_at", "")
                activated_date = user_info.get("activated_at", "")
                transaction_id = user_info.get("transaction_id", "N/A")
                demo_used = user_info.get("demo_used", False)
                is_demo = user_info.get("is_demo", False)
                
                status_text = {
                    "premium": "💎 Премиум",
                    "demo": "🎯 Демо-версия", 
                    "free": "🆓 Бесплатный",
                    "expired": "⏰ Истёк"
                }.get(status, "❓ Неизвестный")
                
                message = (
                    f"👤 **Информация о пользователе {target_user_id}**\n\n"
                    f"🔸 Статус: **{status_text}**\n"
                    f"🔸 Использовал демо: **{'Да' if demo_used else 'Нет'}**\n"
                    f"📅 Активирован: **{activated_date.split('T')[0] if activated_date else 'N/A'}**\n"
                    f"⏰ Истекает: **{expire_date.split('T')[0] if expire_date else 'N/A'}**\n"
                    f"🧾 Транзакция: **{transaction_id}**"
                )
                
                await update.message.reply_text(message, parse_mode=ParseMode.MARKDOWN)
            else:
                await update.message.reply_text(f"❌ Пользователь {target_user_id} не найден в базе данных")
        except ValueError:
            await update.message.reply_text("❌ Неверный формат команды. Используйте: /premium_admin check USER_ID")
    
    elif command == "cleanup":
        cleaned = premium_db.cleanup_expired()
        await update.message.reply_text(f"🧹 Очищено {cleaned} истекших подписок")
    
    elif command == "stats":
        stats = premium_db.get_stats()
        total_active = stats['active_premium'] + stats['active_demo']
        conversion_rate = total_active / max(stats['total_users'], 1) * 100
        demo_to_premium = stats['active_premium'] / max(stats['demo_used_total'], 1) * 100 if stats['demo_used_total'] > 0 else 0
        
        message = (
            f"📊 **Детальная статистика**\n\n"
            f"👥 Всего записей: **{stats['total_users']}**\n"
            f"💎 Активные премиум: **{stats['active_premium']}**\n"
            f"🎯 Активные демо: **{stats['active_demo']}**\n"
            f"🧪 Всего использовали демо: **{stats['demo_used_total']}**\n"
            f"⏰ Истекшие: **{stats['expired_premium']}**\n"
            f"🆓 Бесплатные: **{stats['free_users']}**\n\n"
            f"📈 **Аналитика:**\n"
            f"💰 Общая конверсия: **{conversion_rate:.1f}%**\n"
            f"🎯 Конверсия демо→премиум: **{demo_to_premium:.1f}%**"
        )
        await update.message.reply_text(message, parse_mode=ParseMode.MARKDOWN)
    
    else:
        await update.message.reply_text("❌ Неизвестная команда или недостаточно параметров")

async def premium_command(update: Update, context: CallbackContext):
    """Команда /premium - показывает информацию о премиуме и кнопку покупки"""
    user_id = update.effective_user.id
    
    # Проверяем статус пользователя
    is_premium, status = premium_db.check_premium_status(user_id)
    
    if is_premium:
        user_data = premium_db.get_user_info(user_id)
        expire_str = user_data.get("expires_at") if user_data else None
        
        if status == "demo":
            if expire_str:
                try:
                    from datetime import datetime
                    expire_time = datetime.fromisoformat(expire_str)
                    await update.message.reply_text(
                        f"🎯 **У вас активна демо-версия**\n\n"
                        f"⏰ Действует до: {expire_time.strftime('%d.%m.%Y в %H:%M')}\n\n"
                        f"💎 Хотите безлимитный доступ? Купите полную версию!",
                        parse_mode='Markdown',
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("💳 Купить премиум (299₽)", callback_data="buy_premium")],
                            [InlineKeyboardButton("🔙 Главное меню", callback_data="back_to_main")]
                        ])
                    )
                except ValueError:
                    await update.message.reply_text("❌ Ошибка получения данных о демо-версии")
            else:
                await update.message.reply_text("❌ Ошибка получения данных о демо-версии")
        else:  # full premium
            if expire_str:
                try:
                    from datetime import datetime
                    expire_time = datetime.fromisoformat(expire_str)
                    await update.message.reply_text(
                        f"💎 **У вас есть премиум-подписка!**\n\n"
                        f"⏰ Действует до: {expire_time.strftime('%d.%m.%Y в %H:%M')}\n\n"
                        f"🎮 Наслаждайтесь всеми возможностями!",
                        parse_mode='Markdown',
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("🎮 Создать игру", callback_data="create_game")],
                            [InlineKeyboardButton("🔙 Главное меню", callback_data="back_to_main")]
                        ])
                    )
                except ValueError:
                    await update.message.reply_text("💎 **У вас есть премиум-подписка!**")
            else:
                await update.message.reply_text("💎 **У вас есть премиум-подписка!**")
    else:
        # Пользователь без премиума
        await update.message.reply_text(
            "💎 **Премиум функции:**\n\n"
            "• **🎭 Все роли** (Дон Мафии, Маньяк, Путана и др.)\n"
            "• **👥 До 20 игроков** в одной игре (вместо 8)\n"
            "• **⚙️ Ручная настройка ролей**\n"
            "• **📊 Расширенная статистика**\n\n"
            "💡 **Бот-ведущий доступен БЕСПЛАТНО!**\n\n"
            f"**Цена: {PREMIUM_PRICE_RUBLES}₽**",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💳 Купить премиум (299₽)", callback_data="buy_premium")],
                [InlineKeyboardButton("🎯 Попробовать демо (14 дней)", callback_data="activate_demo")],
                [InlineKeyboardButton("🔙 Главное меню", callback_data="back_to_main")]
            ])
        )

if __name__ == '__main__':
    main() 