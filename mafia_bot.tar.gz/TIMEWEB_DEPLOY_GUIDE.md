# 🚀 Инструкция по загрузке бота на Timeweb Cloud

## 📋 Что нужно подготовить:

1. **Доступ к серверу Timeweb Cloud** (VDS/VPS)
2. **SSH-клиент** (встроенный в Windows PowerShell или PuTTY)
3. **Данные для подключения** от Timeweb

---

## 🖥️ Шаг 1: Подключение к серверу

### Команды для ввода в терминал:

```bash
# Подключитесь к вашему серверу (замените на ваши данные)
ssh root@ВАШ_IP_АДРЕС_СЕРВЕРА
```

**Пример:**
```bash
ssh root@185.104.111.222
```

Введите пароль когда система запросит.

---

## 📦 Шаг 2: Подготовка сервера

### Обновляем систему:
```bash
apt update && apt upgrade -y
```

### Устанавливаем Python и необходимые пакеты:
```bash
apt install python3 python3-pip python3-venv git nano -y
```

### Создаем папку для проекта:
```bash
mkdir -p /home/mafia_bot
cd /home/mafia_bot
```

---

## 📤 Шаг 3: Загрузка файлов проекта

### Вариант А: Через Git (рекомендуется)

```bash
# Если у вас есть Git репозиторий
git clone ВАША_ССЫЛКА_НА_РЕПОЗИТОРИЙ .
```

### Вариант Б: Загрузка файлов вручную

**На вашем компьютере (Windows PowerShell):**

```powershell
# Создайте архив проекта
tar -czf mafia_bot.tar.gz *.py *.txt *.json *.md Procfile

# Загрузите архив на сервер (замените на ваши данные)
scp mafia_bot.tar.gz root@ВАШ_IP_АДРЕС:/home/mafia_bot/
```

**На сервере:**
```bash
# Распакуйте архив
cd /home/mafia_bot
tar -xzf mafia_bot.tar.gz
rm mafia_bot.tar.gz
```

---

## ⚙️ Шаг 4: Настройка окружения

### Создаем виртуальное окружение:
```bash
cd /home/mafia_bot
python3 -m venv venv
source venv/bin/activate
```

### Устанавливаем зависимости:
```bash
pip install -r requirements.txt
```

### Создаем файл с токенами:
```bash
cp env_example.txt .env
nano .env
```

**В редакторе nano введите ваши токены:**
```env
TELEGRAM_BOT_TOKEN=ВАШ_ТОКЕН_БОТА
YOOKASSA_SHOP_ID=390540012
YOOKASSA_SECRET_KEY=390540012:LIVE:71581
DEBUG=False
ENVIRONMENT=production
```

**Для сохранения в nano:** `Ctrl+X`, затем `Y`, затем `Enter`

---

## 🔄 Шаг 5: Запуск бота

### Тестовый запуск:
```bash
python3 mafia_bot.py
```

**Если все работает, остановите бота:** `Ctrl+C`

### Запуск в фоновом режиме:
```bash
# Устанавливаем screen для фонового запуска
apt install screen -y

# Создаем сессию screen
screen -S mafia_bot

# В сессии screen запускаем бота
cd /home/mafia_bot
source venv/bin/activate
python3 mafia_bot.py
```

**Выход из screen с сохранением сессии:** `Ctrl+A`, затем `D`

---

## 🛠️ Шаг 6: Автозапуск (опционально)

### Создаем systemd сервис:
```bash
nano /etc/systemd/system/mafia-bot.service
```

**Содержимое файла:**
```ini
[Unit]
Description=Mafia Telegram Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/home/mafia_bot
Environment=PATH=/home/mafia_bot/venv/bin
ExecStart=/home/mafia_bot/venv/bin/python /home/mafia_bot/mafia_bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### Активируем сервис:
```bash
systemctl daemon-reload
systemctl enable mafia-bot.service
systemctl start mafia-bot.service
```

### Проверяем статус:
```bash
systemctl status mafia-bot.service
```

---

## 📊 Полезные команды для управления

### Проверка логов:
```bash
# Если запущено через screen
screen -r mafia_bot

# Если запущено через systemd
journalctl -u mafia-bot.service -f
```

### Остановка/запуск бота:
```bash
# Через systemd
systemctl stop mafia-bot.service
systemctl start mafia-bot.service
systemctl restart mafia-bot.service

# Через screen
screen -r mafia_bot
# Затем Ctrl+C для остановки
```

### Обновление кода:
```bash
cd /home/mafia_bot
systemctl stop mafia-bot.service  # Останавливаем бота
git pull  # Обновляем код (если используете Git)
systemctl start mafia-bot.service  # Запускаем снова
```

---

## 🔍 Устранение проблем

### Если бот не запускается:
```bash
# Проверьте логи
journalctl -u mafia-bot.service --no-pager

# Проверьте файл .env
cat .env

# Проверьте зависимости
pip list
```

### Если проблемы с сетью:
```bash
# Проверьте интернет
ping google.com

# Проверьте DNS
nslookup api.telegram.org
```

---

## ✅ Готово!

Ваш бот мафии теперь работает на сервере Timeweb Cloud 24/7!

**Для проверки:** Найдите вашего бота в Telegram и отправьте команду `/start` 